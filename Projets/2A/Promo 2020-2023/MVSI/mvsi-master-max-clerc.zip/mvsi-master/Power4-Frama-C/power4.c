#include <stdio.h>
#include <limits.h>

/*
  @ensures (\result >= 0&&p==\result*\result*\result*\result&&\result >=p);
  @ensures \result<=INT_MAX;
*/
int tp(int p)
{
	int az, z, aa, a, at, t, ay, y, ax, x, aw, w, av, v, au, u, i = 0;
	z = 0;
	a = 12;
	t = 6;
	y = 4;
	x = 0;
	w = 1;
	v = 0;
	u = 0;
	z = 0;
	az = z;
	aa = a;
	at = t;
	ay = y;
	ax = x;
	aw = w;
	av = v;
	au = u;
	az = z;
	i = 0;
	 /*@ loop invariant i >= 0 && i <= p;
    */	
	while (i < p)
	{
		printf(" z=%d ; v=%d ; t=%d ; w = %d ; a = %d ; y = %d ; x = %d ; u = %d;\n ",z,v,t,w,a,y,x,u);
		z = az + au + av + aw;
		v = av + at;
		t = at + 12;
		w = aw + 4;
		a = aa + 24;
		y = ay + 12;
		x = ax + aa;
		u = au + ax + ay;
		az = z;
		aa = a;
		at = t;
		ay = y;
		ax = x;
		aw = w;
		av = v;
		au = u;
		az = z;
		i = i + 1;
	}

	return (z);
}
/*@ensures (\result >= 0&&p==\result*\result*\result*\result&&\result >=p);
@ensures \result<=INT_MAX;
*/
int tt(int p)
{
	int az, z, aa, a, at, t, ay, y, ax, x, aw, w, av, v, au, u, i = 0;
	z = 0;
	a = 12;
	t = 6;
	y = 4;
	x = 0;
	w = 1;
	v = 0;
	u = 0;
	z = 0;
	i = 0;
	/*@ loop invariant i >= 0 && i <= p;
	
	*/
	while (i < p)
	{
		printf(" z=%d ; v=%d ; t=%d ; w = %d ; a = %d ; y = %d ; x = %d ; u = %d; \n ",z,v,t,w,a,y,x,u);
		z = z + u + v + w;
		v = v + t;
		t = t + 12;
		w = w + 4;
		u = u + x + y;
		x = x + a;
		a = a + 24;
		y = y + 12;
		i = i + 1;
	}

	return (z);
}

/*
@ensures \result==0;
*/
int main()
	{
		int v;
		printf(" Entrez la va leur 8 pour v \n ");
		scanf("%d ",&v);
		int res = tt(v);
		//@ assert res == v*v*v*v;
		int res2 = tp(v);
		//@ assert res2 == v*v*v*v;
		printf(" voici la réponse de votr esolution % d−− > % d \n ",v,res) ;
			return 0;
		}
