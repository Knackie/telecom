int tp(int p)
{
  int az;
  int z;
  int aa;
  int a;
  int at;
  int t;
  int ay;
  int y;
  int ax;
  int x;
  int aw;
  int w;
  int av;
  int v;
  int au;
  int u;
  int i = 0;
  z = 0;
  a = 12;
  t = 6;
  y = 4;
  x = 0;
  w = 1;
  v = 0;
  u = 0;
  z = 0;
  az = z;
  aa = a;
  at = t;
  ay = y;
  ax = x;
  aw = w;
  av = v;
  au = u;
  az = z;
  i = 0;
  /*@ loop invariant i ≥ 0 ∧ i ≤ p; */
  while (i < p) {
    printf(" z=%d ; v=%d ; t=%d ; w = %d ; a = %d ; y = %d ; x = %d ; u = %d;\n ",
           z,v,t,w,a,y,x,u); /* printf_va_1 */
    /*@ assert rte: signed_overflow: -2147483648 ≤ az + au; */
    /*@ assert rte: signed_overflow: az + au ≤ 2147483647; */
    /*@ assert rte: signed_overflow: -2147483648 ≤ (int)(az + au) + av; */
    /*@ assert rte: signed_overflow: (int)(az + au) + av ≤ 2147483647; */
    /*@ assert
        rte: signed_overflow: -2147483648 ≤ (int)((int)(az + au) + av) + aw;
    */
    /*@ assert
        rte: signed_overflow: (int)((int)(az + au) + av) + aw ≤ 2147483647;
    */
    z = ((az + au) + av) + aw;
    /*@ assert rte: signed_overflow: -2147483648 ≤ av + at; */
    /*@ assert rte: signed_overflow: av + at ≤ 2147483647; */
    v = av + at;
    /*@ assert rte: signed_overflow: at + 12 ≤ 2147483647; */
    t = at + 12;
    /*@ assert rte: signed_overflow: aw + 4 ≤ 2147483647; */
    w = aw + 4;
    /*@ assert rte: signed_overflow: aa + 24 ≤ 2147483647; */
    a = aa + 24;
    /*@ assert rte: signed_overflow: ay + 12 ≤ 2147483647; */
    y = ay + 12;
    /*@ assert rte: signed_overflow: -2147483648 ≤ ax + aa; */
    /*@ assert rte: signed_overflow: ax + aa ≤ 2147483647; */
    x = ax + aa;
    /*@ assert rte: signed_overflow: -2147483648 ≤ au + ax; */
    /*@ assert rte: signed_overflow: au + ax ≤ 2147483647; */
    /*@ assert rte: signed_overflow: -2147483648 ≤ (int)(au + ax) + ay; */
    /*@ assert rte: signed_overflow: (int)(au + ax) + ay ≤ 2147483647; */
    u = (au + ax) + ay;
    az = z;
    aa = a;
    at = t;
    ay = y;
    ax = x;
    aw = w;
    av = v;
    au = u;
    az = z;
    /*@ assert rte: signed_overflow: i + 1 ≤ 2147483647; */
    i ++;
  }
  return z;
}

/*@ ensures
      \result ≥ 0 ∧
      \old(p) ≡ ((\result * \result) * \result) * \result ∧
      \result ≥ \old(p);
    ensures \result ≤ 2147483647;
 */
int tt(int p)
{
  int az;
  int z;
  int aa;
  int a;
  int at;
  int t;
  int ay;
  int y;
  int ax;
  int x;
  int aw;
  int w;
  int av;
  int v;
  int au;
  int u;
  int i = 0;
  z = 0;
  a = 12;
  t = 6;
  y = 4;
  x = 0;
  w = 1;
  v = 0;
  u = 0;
  z = 0;
  i = 0;
  /*@ loop invariant i ≥ 0 ∧ i ≤ p; */
  while (i < p) {
    printf(" z=%d ; v=%d ; t=%d ; w = %d ; a = %d ; y = %d ; x = %d ; u = %d; \n ",
           z,v,t,w,a,y,x,u); /* printf_va_2 */
    /*@ assert rte: signed_overflow: -2147483648 ≤ z + u; */
    /*@ assert rte: signed_overflow: z + u ≤ 2147483647; */
    /*@ assert rte: signed_overflow: -2147483648 ≤ (int)(z + u) + v; */
    /*@ assert rte: signed_overflow: (int)(z + u) + v ≤ 2147483647; */
    /*@ assert
        rte: signed_overflow: -2147483648 ≤ (int)((int)(z + u) + v) + w;
    */
    /*@ assert
        rte: signed_overflow: (int)((int)(z + u) + v) + w ≤ 2147483647;
    */
    z = ((z + u) + v) + w;
    /*@ assert rte: signed_overflow: -2147483648 ≤ v + t; */
    /*@ assert rte: signed_overflow: v + t ≤ 2147483647; */
    v += t;
    /*@ assert rte: signed_overflow: t + 12 ≤ 2147483647; */
    t += 12;
    /*@ assert rte: signed_overflow: w + 4 ≤ 2147483647; */
    w += 4;
    /*@ assert rte: signed_overflow: -2147483648 ≤ u + x; */
    /*@ assert rte: signed_overflow: u + x ≤ 2147483647; */
    /*@ assert rte: signed_overflow: -2147483648 ≤ (int)(u + x) + y; */
    /*@ assert rte: signed_overflow: (int)(u + x) + y ≤ 2147483647; */
    u = (u + x) + y;
    /*@ assert rte: signed_overflow: -2147483648 ≤ x + a; */
    /*@ assert rte: signed_overflow: x + a ≤ 2147483647; */
    x += a;
    /*@ assert rte: signed_overflow: a + 24 ≤ 2147483647; */
    a += 24;
    /*@ assert rte: signed_overflow: y + 12 ≤ 2147483647; */
    y += 12;
    /*@ assert rte: signed_overflow: i + 1 ≤ 2147483647; */
    i ++;
  }
  return z;
}

int main(void)
{
  int __retres;
  int v;
  printf(" Entrez la va leur 8 pour v \n "); /* printf_va_3 */
  /* preconditions of scanf_va_1:
     requires valid_read_string("%d ");
     requires \valid(&v); */
  scanf("%d ",& v); /* scanf_va_1 */
  int res = tt(v);
  /*@ assert res ≡ ((v * v) * v) * v; */ ;
  int res2 = tp(v);
  /*@ assert res2 ≡ ((v * v) * v) * v; */ ;
  printf(" voici la r\303\251ponse de votr esolution % d\342\210\222\342\210\222 > % d \n ",
         v,res); /* printf_va_4 */
  __retres = 0;
  return __retres;
}

