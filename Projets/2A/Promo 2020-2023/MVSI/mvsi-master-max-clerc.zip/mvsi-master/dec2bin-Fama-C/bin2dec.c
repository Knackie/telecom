#include <math.h>
#include <stdio.h>

int convert(long long n);
/*
@ensures \result==0;
*/
int main()
{
	long long n;
	printf(" Enter a b inary number : ");
	scanf("%l l d ", &n);
	printf("%l l d in b inary = %d in decimal ", n, convert(n));
	return 0;
}

int convert(long long n)
{
	int dec = 0, i = 0, rem;
	while (n != 0)
	{
		
		rem = n % 10;
		/* @assert rem==n%10; */
		n /= 10;
		/* @assert n== \old(n) /10; */
		dec += rem*(1<<i);//Equivalent a pow(2,i)
		/* @assert dec==\old(dec)+(rem*pow(2,i)); */
		++i;
		/* @assert i==\old(i)+1; */
	}

	return dec;
}
