int convert(long long n);

int main(void)
{
  int __retres;
  long long n;
  int tmp;
  printf(" Enter a b inary number : "); /* printf_va_1 */
  {
    long long *__va_arg0 = & n;
    void *__va_args[1] = {& __va_arg0};
    scanf("%l l d ",(void * const *)(__va_args));
  }
  { /* sequence */
    /*@ assert Eva: initialization: \initialized(&n); */
    tmp = convert(n);
    ;
  }
  {
    long long __va_arg0_6 = n;
    int __va_arg1 = tmp;
    void *__va_args_9[2] = {& __va_arg0_6, & __va_arg1};
    printf("%l l d in b inary = %d in decimal ",(void * const *)(__va_args_9));
  }
  __retres = 0;
  return __retres;
}

int convert(long long n)
{
  int rem;
  int dec = 0;
  int i = 0;
  while (n != (long long)0) {
    rem = (int)(n % (long long)10);
    n /= (long long)10;
    /*@ assert rte: shift: 0 ≤ i < 32; */
    /*@ assert rte: signed_overflow: 1 << i ≤ 2147483647; */
    /*@ assert rte: signed_overflow: -2147483648 ≤ rem * (int)(1 << i); */
    /*@ assert rte: signed_overflow: rem * (int)(1 << i) ≤ 2147483647; */
    /*@ assert
        rte: signed_overflow: -2147483648 ≤ dec + (int)(rem * (int)(1 << i));
    */
    /*@ assert
        rte: signed_overflow: dec + (int)(rem * (int)(1 << i)) ≤ 2147483647;
    */
    dec += rem * (1 << i);
    /*@ assert rte: signed_overflow: i + 1 ≤ 2147483647; */
    i ++;
  }
  return dec;
}

