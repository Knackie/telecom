/*@ requires \valid(a+ (0..size - 1));
  @ ensures \forall int k; 0 <= k <= size - 2 ==> *(a + k) <= *(a + k + 1);
*/
void shell_sort(int *a, unsigned int size) {
    int i, j, inc, tmp;
    // --------------------
    inc = 3;
    while (inc > 0) {
        for (i = 0; i < size; i++) {
            j = i;
            tmp = a[i];
            while ((j >= inc) && (a[j - inc] > tmp)) {
                a[j] = a[j - inc];
                j = j - inc;
            }
            a[j] = tmp;
        }
        if (inc / 2 != 0) {
            inc = inc / 2;
        } else if (inc == 1) {
            inc = 0;
        } else {
            inc = 1;
        }
    }
}
