# TP Projet compilation des langages - Partie 2 : Ecriture d'un AST

## 1 - Introduction 

Dans le TP précédent, nous avons construit une grammaire d'expression arithmétique (expr.g). Grâce à Antlr, nous pouvons utiliser cette grammaire pour transformer un texte en arbre syntaxique. Cependant, un arbre syntaxique possède beaucoup de noeuds inutiles que nous voudrions éliminer pour simplifier notre futur travail. Prenons par exemple l'expression ```a=3+4*5;``` . Avec notre parser actuel, nous obtiendrons l'arbre suivant : 

![syntaxTree](./images/syntaxTree.png) 

Cette forme ne parait pas pratique car elle contient de nombreux noeuds unaire ```value``` qui ne sont pas utiles pour comprendre la signification du code. De plus, certaines feuilles sont inutiles pour la compréhension comme le ```;``` à la deuxième ligne de l'arbre. Enfin, l'opérateur utilisé dans les règles ```plus``` et ```mult``` se situe au même niveau que les nombres auxquels il se rapporte. Cela n'est pas très pratique car on ne sait pas immédiatement quel opérateur appliquer depuis les noeuds ```mult``` et ```plus```. Dans l'idéal, nous voudrions transformer cet arbre pour le plus simple à comprendre. Une meilleure représentation serait par exemple :

![ast-intro](images/intro-affect.svg)

Cette arbre retranscrit de façon plus précise la sémantique du texte analysé. Il s'agit d'un Arbre Syntaxique Abstrait (un __AST__). L'objectif de ce TP est de construire un AST a partir de l'arbre syntaxique produit dans le TP précédent.

## 2 - La notion de visiteur

Le visiteur est un patron de conception qui permet le parcours de structures arborescentes. Il permet de différencier la classe qui parcourt la structure arborescente de la structure elle-même, ce qui réduit le couplage (cf. cours de MOCI).

Pour mettre en oeuvre ce pattern, on définit tout d'abord une classe ```Visitor``` qui implémente une méthode ```visit``` pour chaque classe de notre structure arborescente. Par exemple, supposons que nous voulions visiter l'AST de la partie précédente. Dans notre visiteur, nous devons définir une méthode de visite pour les noeuds ```Affect```, ```Mult```, ```Plus```, ```Int``` et ```Var```. On définit donc le visiteur suivant :

```Java
public class Visitor {
    public void visit(Affect affect){
        ...
    }
    public void visit(Mult mult){
        ...
    }
    public void visit(Plus plus){
        ...
    }
    public void visit(Int value){
        ...
    }
    public void visit(Var value){
        ...
    }
}
 ```
On demande également aux classes visitées d'implémenter une méthode ```accept``` qui prend un visiteur en argument. Cette méthode permet au compilateur de décider du type du noeud en entrée et d'appeler la bonne méthode ```visit```.

```Java
public class Affect implements Visitable {

    public void accept(Visitor visitor){
        visitor.visit(this);
    }

}
 ```

L'idée qui se cache dèrrière cette méthode est que le visiteur ne connait pas à l'avance le type de noeud sur lequel il est appelé. Par contre, un objet connait son propre type. Lorsque l'on appelle la méthode ```accept``` depuis l'objet sur le visiteur, l'appel de la méthode ```visitor.visit(this)``` fonctionne car l'objet connait son type. Cela permet au visiteur de choisir la méthode ```visit``` qu'il doit appeler.


## 3 - Parcours de l'arbre syntaxique

Sur __Linux__, utilisez la commande :
```bash
make parser
 ```

Sur __Windows__, utilisez la commande : 
```bash
java -jar ./lib/antlr-4.9.2-complete.jar expr.g4 -no-listener -visitor -o ./src/parser
 ```

Dans le dossier ```src/parser```, vous venez de générer 4 fichiers java : ```exprBaseVisitor```, ```exprLexer```, ```exprParser``` et ```exprVisitor```.


Ouvrez la classe ```exprBaseVisitor```. Elle contient un ensemble de méthodes de la forme :

```java
T visit[Noeud]([Noeud]Context ctx);
 ```

Ces méthodes sont une surcouche du pattern visiteur expliqué plus tôt. Elles permettent de parcourir simplement chaque noeud de l'arbre syntaxique. L'objet ```ctx``` passé en argument représente le noeud de l'arbre syntaxique, ```T``` représente le type de retour du visiteur. Ce type générique permet de créer simplement plusieurs visiteurs avec des types de retour différents. Dans la suite, nous allons utiliser un visiteur pour créer l'AST.

Dans le dossier ```src/ast```, nous avons écrit l'ensemble des classes nécessaire pour construire l'AST de la grammaire Expr. Elles sont regroupées sous l'interface ```Ast```. Il y a également un objet ```AstCreator``` qui étend la classe ```exprBaseVisitor<Ast>```. 

L'objectif de ce TP sera de remplir ce visiteur et ces classes pour créer l'AST correspondant à notre grammaire.


#### a - L'utilisation des Labels 

Observons la règle ```if_litteral``` de la grammaire ```expr.g4```. On peut constater qu'elle est découpée en deux sous-règles pour différencier le cas où le ```else``` est présent. En effet, Antlr permet d'écrire des grammaires LL(k). Il n'y a donc aucune obligation de régler les ambiguités du type A -> BC | BD. Cela nous permet de traiter différemment ces deux alternatives. Nous n'aurons pas besoin de tester si le token ```else``` est présent ou non puisque ces deux alternatives seront traitées avec des méthodes différentes.

Cependant, dans le fichier ```ExprBaseVisitor```, on constate qu'il n'existe qu'une seule méthode pour traiter la règle ```if_litteral```. Antlr ne semble pas faire la différence entre les deux alternatives de cette règle. Pour lui indiquer qu'il faut les traiter séparément, nous allons utiliser des **labels**. Les labels sont des annotations que l'on place après une alternative dans une règle pour demander à Antlr de générer une méthode spécifiquement pour cette alternative.

La syntaxe est la suivante :
```antlr
regle :
   alternative_1 #Label1
 | alternative_2 #Label2
 ....
 | alternative_n #Labeln
;
 ```

Pour la règle ```if_litteral```, on peut utiliser les labels suivants (cf. la grammaire):
```antlr
if_litteral : 
      'if' '('expr')' '{'instr_list'}' 'else' '{'instr_list'}'    #IfThenElse
    | 'if' '('expr')' '{'instr_list'}'                            #IfThen
    ;
 ```

En recompilant, on constate que ```ExprBaseVisitor``` implémente deux méthodes ```visitIfThen``` et ```visitIfThenElse```.

Avant de continuer le TP, ajoutez des labels ```Integer```, ```Identifier``` et ```Parenthesis``` pour les alternatives de la règles ```value``` (ne vous trompez pas d'orthographe, sinon rien ne va compiler à la fin).

 Il est important d'écrire les labels avant de commencer le code du visiteur. En effet, à chaque fois que vous ajoutez un label, il faut recompiler la grammaire. Si vous ajoutez les labels au fur et à mesure, vous devrez modifier le code que vous avez déjà écrit pour ajouter les nouvelles méthodes générées. Ce travail peut rapidement devenir fastidieux.

 Après avoir ajouté ces labels, __recompilez__ la grammaire.


#### b - Affectation des variables

Dans un premier temps, nous allons écrire le noeud de l'arbre pour l'affectation de variables. Pour cela, nous allons modifier la méthode ```visitAffect``` et les classes ```Affect``` et ```IDF```. Pour cela, nous utilisons l'argument ```ctx``` passé au visiteur. On peut récupérer les noeuds fils en utilisant la méthode ```getChild(i)``` qui permet de récupérer le i-ème fils du noeud.

La règle ```affect``` possède 4 noeuds fils :
- IDF
- '='
- expr
- ';'

Les informations sémantiques (qui décrivent le contenu de l'expression) sont ```Idf``` et ```expr``` (les tokens ```=``` et ```;``` sont inutiles pour la compréhension). Pour construire le noeud ```affect```, nous avons en effet besoin d'un identifiant et de l'expression qui lui est affectée. 

Antlr traite les noeuds terminaux différemment des non-terminaux. On ne peut pas visiter les noeuds terminaux.
Pour récupérer la valeur du terminal ```Idf```, on appelle simplement la méthode ```toString``` sur ce noeud.

Cela donne le code suivant :
```java 
String idfString = ctx.getChild(0).toString();
 ```

Pour ce qui est du noeud expression, nous voulons récupérer l'AST correspondant à ce noeud. Pour cela, il va falloir le générer en utilisant notre visiteur. Pour cela, on utilise la méthode ```accept``` du noeud expression :
```java 
ast expr = ctx.getChild(2).accept(this);
 ```

Enfin, nous devons modifier les classes ```Idf``` et ```Affect``` pour pouvoir leur passer ces deux variables :
```java
public class Idf {
    public String name;

    public Idf(String name){
        this.name = name;
    }
}
 ```

```java
public class Affect {

    public <T> T accept(AstVisitor<T> visitor){
        return visitor.visit(this);
    }

    public Ast idf;
    public Ast expression;

    public Affect(Ast idf, Ast expr){
        this.idf = idf;
        this.expression = expr;
    }
}
 ```

et la méthode ```visitAffect```:

```java
public Ast visitAffect(AffectContext ctx){

    //Récupération des noeuds fils
    Ast expr = ctx.getChild(2).accept(this);
    String idfString = ctx.getChild(0).toString();

    //Création des sous AST
    Idf idf = new Idf(idfString);

    return new Affect(idf,expr);

}
 ```

Et voila !!! Nous venons d'écrire le code qui traduit le noeud ```Affect``` de l'arbre syntaxique en AST. Dans la suite du TP, nous allons écrire l'ensemble de ces règles de transformation. 


#### d - Traitement de la règle ```instr``` 

La règle ```instr``` a la forme suivante : 

```
instr : 
      affect           
    | if_litteral       
    | print_litteral
    ;
 ```

Posons-nous la question suivante : est-ce que cette règle doit déclencher la création d'un noeud de l'AST ?  Dans ce cas, on obtiendrait l'AST suivant (mettre l'image de l'AST). 

La question est de savoir s'il est utile d'avoir un noeud unaire __instr__. Dans le cas contraire, nous ne sommes pas obligé de créer un noeud à cette étape et nous pouvons simplement retourner l'AST produit par le noeud fils de cette règle (peu importe son type) avec le code suivant :
```java
return ctx.getChild(0).accept(this);
 ```

Le principe à retenir est qu'un noeud de l'arbre syntaxique ne correspond pas forcément à un noeud dans l'AST.

En vous appuyant sur ces réflexions, complétez la méthode ```visitInstr```.


#### e - Liste d'instructions

La règle ```instr_list``` permet d'écrire une liste d'au moins une instruction. Complétez la classe ```instrList``` ainsi que la méthode ```visitInstr_list``` pour générer le noeud d'AST correspondant.

Il doit avoir cette forme :

![instr-list](images/1e-instrList.svg)

On constate qu'il doit donc contenir une liste de sous-AST. Pour cela, il faut visiter chaque noeud fils de la règle ```instr_list```.



#### f - Construction des autres noeuds

Les parties précédentes nous ont permis de nous familiariser avec la construction d'un AST. Dans la suite, nous allons vous demander de construire tous les autres noeuds de l'AST. Nous vous donnons une représentation graphique de chaque morceau d'AST que vous devez implémenter.

Le principe général est toujours le même : il faut construire les AST correspondant aux noeuds fils en les visitant et les utiliser pour construire l'AST du noeud parent.

##### i - Règle ```if_litteral```

Complétez les classes ```IfThen``` et ```IfThenElse```, ainsi que les méthodes ```visitIfThen``` et ```visitIfThenElse``` pour construire l'arbre correspondant.

Il doivent avoir la forme suivante :
![if-then-else](images/1f-ifThenElse.svg)



#### ii - Règle ```print```

Compléter la classe ```Print``` et la méthode ```visitPrint``` pour construire leur AST. Il doit avoir la forme suivante : 
![print](images/1f-print.svg)



#### iii - Règle ```program```
Compléter la classe ```Program``` et la méthode ```visitProgram``` pour construire leur AST. Il doit avoir la forme suivante : 
![instr-list](images/1f-program.svg)


### iv - Règle ```expr```

La règle ```expr``` ne produit pas d'arbre car elle est constituée uniquement du non-terminal ```plus```. Complétez la méthode ```visitExpr``` en ce sens.

### v - Règle ```value```:

La règle ```value``` se décompose en 3 sous-règles que nous vous avons demandé de labéliser dans la partie précédente :
* ```#Identifier``` qui correspond à un identifiant. Nous avons déjà écrit le code du noeud ```Idf``` au point b. de cette partie.
* ```#Integer``` qui produit un entier. Son code est très similaire à celui des identifiants.
* ```#Parenthesis``` qui permet d'écrire des parenthèses dans les opérations arithmétiques. Nous nous en occuperons dans la partie suivante.

Complétez la classe ```IntNode``` ainsi que les méthodes ```visitInteger``` et ```visitIdentifier``` pour générer les noeuds correspondants. Ils doivent avoir la forme suivante : 



### 2 - Opérateurs arithmétiques 


#### a - Addition et multiplication

L'objectif de cette partie est de construire l'arbre correspondant aux opérateurs arithmétiques. Essayons d'analyser l'arbre syntaxique produit par le parser pour l'expression  ```1+2*3+4```:

![image](./images/arbre_arithmetique.png)

On peut constater que cette expression est 'aplatie' : toutes les opérations additives se situent sur la même ligne, et il en est de même pour les opérations multiplicatives. Notre but va être de construire un arbre de la forme :
![instr-list](images/2a-addmult.svg)


On remarque que chaque opération produit un noeud binaire. Pour créer l'AST correspondant, nous allons devoir parcourir les noeuds fils de ```plus``` et ```mult``` de gauche à droite, deux par deux. A chaque fois que nous "voyons" une nouvelle opération, nous devons créer un nouveau noeud. Nous allons donc procéder de la façon suivante :

1. On génère le noeud associé au premier élément (car il existe toujours) et on le stocke dans une variable ```noeudTemporaire```:
```java
Ast noeudTemporaire = ctx.getChild(0).accept(this);
 ```

Dans notre exemple, on crée le noeud entier de valeur 1.

2. On regarde les deux fils suivants (ici ce sera le charactère '+' et le noeud mult '2*3' ). On stocke le premier dans une variable ```operation``` et le second dans une variable ```right```:
```java 
String operation = ctx.getChild(1).toString();
Ast right = ctx.getChild(2).accept(this);
 ```

3. On crée un nouveau noeud de type ```Plus``` ou ```Minus``` en fonction de la valeur de ```operation```
ayant pour fils gauche la variable ```noeudTemporaire``` et pour fils droit la variable ```right```.
```java
switch (operation) {
    case "+" : 
        noeudTemporaire = new Plus(noeudTemporaire,right);
        break;
    case "-" : 
        noeudTemporaire = new Minus(noeudTemporaire,right);
        break;
    default:
        //TODO : manage error
        break;
}
```

4. On recommence à l'étape 2 jusqu'à ce qu'il n'y ait plus de fils à traiter.

Le code final doit ressembler à ça :

```java
public Node visitPlus(PlusContext ctx) {
  
        Ast noeudTemporaire = ctx.getChild(0).accept(this);


        for (int i=0;2*i<ctx.getChildCount()-1;i++){
            
            String operation = ctx.getChild(2*i+1).toString();
            Ast right = ctx.getChild(2*(i+1)).accept(this);

            switch (operation) {
                case "-":
                    noeudTemporaire = new Minus(noeudTemporaire,right);
                    break;
                case "+":
                    noeudTemporaire = new Plus(noeudTemporaire,right);
                    break;
                default:
                    break;
            }


        }    

        return noeudTemporaire;

    }
```

Implémentez le même principe pour la règle ```mult``` en complétant la méthode ```visitMult```. N'oubliez pas qu'il faut également compléter les classes ```Plus```, ```Minus```, ```Mult``` et ```Divide```.



#### b - Gestion des parenthèses

Est-ce utile d'avoir un noeud nommé "parenthèses" dans l'AST ? Prenons par exemple l'expression ```3*(4+5)```.
Quel AST vous semble le plus adapté entre les deux suivants :
![instr-list](images/2b-parenthesis.svg)



En fonction de ce choix, complétez la méthode ```visitParenthesis```.


## 4. Représentation graphique 

Nous avons terminé la construction de notre AST, ce serait pas mal de l'afficher maintenant, non ?
#### a1. Préparation (Linux)

 Avant de commencer, compilez votre code en utilisant les commandes de la dernière fois. Pour les utilisateurs de __Linux__, nous avons mis à disposition un Makefile qui permet de compiler simplement la grammaire et le code java.


Pour compiler le Main :
```bash 
make compile
 ```

Pour exécuter le main sur un fichier donné :
```bash 
make run target=[path_du_fichier]
 ```

 Nous vous demandons d'éxécuter la seconde commande pour le moment.

#### a2. Préparation (Windows - PowerShell)

Pour les utilisateurs de __Windows__, nous ne sommes pas en mesure de fournir un Makefile sans vous faire installer plein de packages supplémentaires. Nous vous invitons à utiliser les commandes du TP précédent.

Pour compiler le Main :
```bash 
javac  -cp "./lib/antlr-4.9.2-complete.jar;./src" ./src/Main.java -d ./bin
 ```

Pour exécuter le main sur un fichier donné :
```bash 
java -cp "./lib/antlr-4.9.2-complete.jar;./bin" Main [nom_du_fichier]
 ```

 Nous vous demandons d'exécuter la seconde commande pour le moment.

#### b - Représentation graphique

Pour représenter l'arbre graphiquement, nous allons utiliser ... un visiteur (oui encore un). Dans le package ast, nous avons défini une interface ```AstVisitor``` qui permet de visiter les noeuds de type ```Ast```. De plus, l'interface ```Ast``` implémente déjà la méthode ```accept``` sur ce visiteur. 

Dans le cadre de ce TP, nous n'avons pas le temps de vous faire implémenter le visiteur qui affiche l'AST. Nous l'avons donc déjà écrit dans la classe ```graphViz.GraphVizVisitor```. Nous vous invitons fortement à regarder son code et à poser des questions dessus pour bien comprendre son fonctionnement (lors du projet compilation, il vous sera demander de produire une représentation graphique de l'AST lors de la première soutenance intermédiaire).


Nous utilisons la librairie [GraphViz](https://graphviz.org/). Cette librairie permet de simplement représenter des diagrammes en boite (diagramme UML, graphe de dépendance...). Pour l'installer, utiliser le [lien suivant](https://graphviz.org/download/) et suivez les instructions selon votre système d'exploitation.

Nous utilisons la syntaxe dot de graphViz pour générer l'arbre. Un noeud de l'arbre est représenté par le code :
```
NOM_DU_NOEUD [label="UN_LABEL", shape="box"];
 ```

Une transition est représentée par le code  :

```
NOEUD_DE_DEPART -> NOEUD_D_ARRIVEE;
 ```

On peut bien entendu modifier les formes, le sens des liens et la position des éléments dans le graphe. Si vous voulez découvrir l'outil, le plus simple est de lire la [documentation](https://graphviz.org/doc/info/lang.html) qui est très fournie.

Dans notre cas, la classe ```GraphVizVisitor``` va tout faire puisqu'elle génère un fichier .dot valide représentant l'AST passé en argument et l'enregistre dans le fichier ```out/tree.dot```.

Pour visualiser le fichier, on exécute simplement la commande :
```dot -Tsvg ./out/tree.dot -o ./out/tree.svg```

Ceci crée un fichier svg que nous pouvons visualiser avec n'importe quelle visionneuse d'images.


 


