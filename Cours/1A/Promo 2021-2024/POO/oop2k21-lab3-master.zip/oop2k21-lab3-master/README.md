# Labs #3 - Héritage, classes abstraites, interface et tests unitaires

## Objectifs

- Concevoir et créer ses propres classes
  - interface, constructeurs, variable d'instances, méthodes
  - composition et délégation
  - tableaux (*dynamiques*) à taille variable
  - héritage, classe abstraites
  - liaison dynamique
  - appel de constructeurs en cascade
- Savoir compiler/exécuter un programme Java
  - notion basique de *package*
  - notion basique de *classpath*
- Savoir *refactoriser* du code existant
- Savoir exécuter des tests unitaires

## Préliminaires

Vous réaliserez ce travail dans un dépôt Git local. Il vous est demandé de committer régulièrement vos contributions et de *pousser* celles-ci sur la plateforme GitLab (https://gitlab.telecomnancy.univ-lorraine.fr) de l'école.

Veillez à organiser votre dépôt de la manière suivante :
  - un répertoire `src/` dans lequel vous placerez le code source de votre travail
  - ne committez que le code source Java et non les versions compilées de vos programmes. Pour cela ajouter le nécessaire dans le fichier `.gitignore` pour ignorer les fichiers `.class` (si ce n'est pas déjà fait)

Nous vous invitons à consulter :

  - l'API Java 8 en ligne : https://docs.oracle.com/javase/8/docs/api
  - les support de cours : 
    - CM1 (partie 1): https://arche.univ-lorraine.fr/mod/resource/view.php?id=1059764
    - CM1 (partie 2) : https://arche.univ-lorraine.fr/mod/resource/view.php?id=1059766
    - CM2 (auto-apprentissage) : https://arche.univ-lorraine.fr/mod/resource/view.php?id=1059769 
    - CM3 (partie 1) : https://arche.univ-lorraine.fr/mod/resource/view.php?id=1059773 
    - CM3 (partie 2) : https://arche.univ-lorraine.fr/mod/resource/view.php?id=1059774 
  - les feuillets récapitulatifs de la syntaxe du langage Java : 
    
    https://arche.univ-lorraine.fr/mod/resource/view.php?id=1059780.


## Rendu

Ce travail est à rendre au plus tard le **mardi 9 février 2021 à 14:00** sur la plateforme GitLab de l'école. 

## Sujet

Le [sujet de la séance est disponible sous forme d'un fichier au format PDF](./enonce.pdf).

## Compilation et tests

### De façon manuelle (en ligne de commandes)

**Remarque :** On suppose dans la suite de cette section que votre répertoire courant est le répertoire racine de votre dépôt local git. **Il se peut que vous deviez créer un répertoire `build/`.**

Pour compiler une classe que vous avez écrite, vous pouvez utiliser la commande suivante (par exemple la classe `dipole.Coil`) :
```bash
javac -d build/ src/dipole/Coil.java 
```

**Remarque :** Pour réussir à compiler la classe `dipole.Coil`, vous devrez auparavant compiler la classe `dipole.Complex` et l'interface `dipole.Dipole`.


Pour compiler, une classe de tests (par exemple la classe `dipole.CoilTest`) :
```bash
javac -d build/ -cp lib/junit-platform-console-standalone-1.7.0.jar:build/:test/ test/dipole/CoilTest.java
```

Puis, pour exécuter cette classe de tests :
```bash
java -jar lib/junit-platform-console-standalone-1.7.0.jar -cp=build/ --select-class=dipole.CoilTest
```

Si vous souhaitez exécuter toutes les classes de tests d'un package particulier, vous pouvez utiliser la commande suivante (par exemple pour le package `dipole`) :
```bash
java -jar lib/junit-platform-console-standalone-1.7.0.jar -cp=build/ --select-package=dipole
```

### De manière automatisée (en utilisant Gradle)

Pour compiler et exécuter les tests (et gérer les dépendances nécessaires), vous pouvez utiliser un moteur de production tel que `Gradle` (https://gradle.org/). 

Ce devoir est déjà configuré pour utiliser `Gradle`. Ainsi en utilisant la commande suivante, vous pouvez compiler l'ensemble de votre code source et exécuter les tests fournis :
```bash
./gradlew cleanTest test
```

Vous pouvez exécutez uniquement un certain test en précisant le nom de la classe de tests à exécuter en utilisant la commande suivante (par exemple pour la classe `dipole.CoilTest`):
```bash
./gradlew test --tests dipole.CoilTest
```

**Remarque :** Tous les tests fournis ne peuvent compiler tant que vous n'avez pas écris toutes les classes qu'ils testent. Nous avons donc dû exclure du processus de compilation la majorité des tests. Vous devrez donc les ré-activer lorsque vous aurez écrit les classes requises. Pour cela, vous devrez éditer le fichier `build.gradle` et **commenter au fur et à mesure de votre progression** la ligne correspondant aux tests que vous souhaitez réaliser.
