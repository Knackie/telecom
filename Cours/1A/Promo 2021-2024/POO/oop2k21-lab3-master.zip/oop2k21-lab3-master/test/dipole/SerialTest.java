package dipole;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class SerialTest {

    @Test
    void testSerial() {
        Coil c = new Coil(5e-2);
        Resistor r = new Resistor(100.);
        Serial s = new Serial(c, r);

        assertEquals(new Complex(100., 15.708), s.impedance(314.16));
        assertEquals(new Complex(100., 0.15708), s.impedance(3.1416));
        assertEquals(new Complex(100., 0.), s.impedance(0.));
    }

}
