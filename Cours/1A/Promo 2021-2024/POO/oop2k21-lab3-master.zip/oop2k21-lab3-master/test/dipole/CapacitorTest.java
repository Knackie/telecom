package dipole;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class CapacitorTest {

    @Test
    void testCapacitor() {
        Capacitor c = new Capacitor(42.);
        assertEquals(new Complex(0., -7.578789 * 1e-5), c.impedance(314.16));
        assertEquals(new Complex(0., -7.578789 * 1e-3), c.impedance(3.1416));
        assertEquals(new Complex(0., Double.NEGATIVE_INFINITY), c.impedance(0.));
    }

}
