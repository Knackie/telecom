package dipole;

public class Instances {
	
	public static Dipole dip1() {
        // a completer
		return null;
	}

	public static Dipole dip2() {
        // a completer
		return null;
	}
}
