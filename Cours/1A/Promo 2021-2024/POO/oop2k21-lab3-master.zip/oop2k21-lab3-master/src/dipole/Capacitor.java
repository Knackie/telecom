package dipole;

public class Capacitor implements Dipole {

    public Capacitor(double c) {
        // a completer (ajouter des variables d'instance si necessaire)
      }

    public Complex impedance(double omega) {
        // a completer
        return null;
    }
}