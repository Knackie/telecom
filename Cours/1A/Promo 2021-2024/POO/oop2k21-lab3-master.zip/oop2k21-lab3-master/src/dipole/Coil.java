package dipole;

public class Coil implements Dipole {

    private double l;

    public Coil(double l) {
        this.l = l;
    }

    public Complex impedance(double omega) {
        // a completer
        return null;
    }
}