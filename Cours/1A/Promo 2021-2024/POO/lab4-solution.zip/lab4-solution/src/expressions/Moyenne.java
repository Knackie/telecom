package expressions;

import java.util.ArrayList;
import java.util.Iterator;

public class Moyenne extends NAire {

    public Moyenne(ArrayList<Exp> ops) {
        super(ops);
    }

    public Moyenne(Exp[] ops) {
        super(ops);
    }

    public double evaluer(Contexte cxt) {
        if (this.isEvaluable(cxt)) {
            Iterator<Exp> it = this.operandes.iterator();
            double total = 0.0;

            while (it.hasNext()) {
                total += it.next().evaluer(cxt);
            }

            return total / this.operandes.size();
        } else {
            throw new UnsupportedOperationException("Not supported yet.");
        }
    }
    
    protected String symbole() {
        return "MOYENNE";
    }
}
