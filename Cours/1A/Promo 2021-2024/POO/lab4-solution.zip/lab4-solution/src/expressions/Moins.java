package expressions;

public class Moins extends Binaire {

    public Moins(Exp opg, Exp opd) {
        super(opg, opd);
    }

    protected double calculer(double valG, double valD) {
        return valG - valD;
    }

    protected String symbole() {
        return "-";
    }
}
