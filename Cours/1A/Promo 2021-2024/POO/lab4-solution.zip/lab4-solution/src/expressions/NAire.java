package expressions;

import java.util.ArrayList;
import java.util.Iterator;

public abstract class NAire implements Exp {

    protected ArrayList<Exp> operandes;
    
    public NAire(ArrayList<Exp> ops) {
        this.operandes = ops;
    }
    
    public NAire(Exp[] ops) {
        this.operandes = new ArrayList<Exp>();
        for (int i=0; i<ops.length; i++)
            this.operandes.add(ops[i]);
    }
    
    public Exp operande(int index) {
        return this.operandes.get(index);
    }
     
    public boolean isEvaluable(Contexte cxt) {
        boolean resultat = this.operandes.size() > 0;
        
        Iterator<Exp> it = this.operandes.iterator();
        while (resultat && it.hasNext()) {
            Exp e = it.next();
            resultat = e.isEvaluable(cxt);
        }
        return resultat;
    }

    public String decompiler() {   
        StringBuffer buf = new StringBuffer(symbole());
        buf.append("(");
        Iterator<Exp> it = this.operandes.iterator();
        while (it.hasNext()) {
            Exp e = it.next();
            buf.append(e.decompiler());
            if (it.hasNext())
                buf.append(",");
        }       
        buf.append(")");
        return buf.toString();   
    }
    
    
    protected abstract String symbole() ;

    public Exp reduire(Contexte cxt) {
        for (int i=0; i<this.operandes.size(); i++) {
            Exp e = this.operandes.get(i);
            this.operandes.remove(i);
            this.operandes.add(i,e.reduire(cxt));
        }
        // todo: combine children which are constant 
        return this;
    }
    
    
}
