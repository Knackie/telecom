package expressions;

import java.util.ArrayList;
import java.util.Iterator;

public class Max extends NAire {

    public Max(ArrayList<Exp> ops) {
        super(ops);
    }

    public Max(Exp[] ops) {
        super(ops);
    }

    public double evaluer(Contexte cxt) {
        if (this.isEvaluable(cxt)) {
            Iterator<Exp> it = this.operandes.iterator();
            double max = Double.NEGATIVE_INFINITY;
            while (it.hasNext()) {
                double v = it.next().evaluer(cxt);
                if (v > max) {
                    max = v;
                }
            }
            return max;
        } else {
            throw new UnsupportedOperationException("Not supported yet.");
        }
    }
    
    protected String symbole() {
        return "MAX";
    }
}
