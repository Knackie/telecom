package expressions;

public class Mult extends Binaire {

    public Mult(Exp opg, Exp opd) {
        super(opg, opd);
    }

    protected double calculer(double valG, double valD) {
        return valG * valD;
    }

    protected String symbole() {
        return "*";
    }
}
