package expressions;

public class VariableNonDefinieException extends RuntimeException {
    
    private Variable variable;
    
    public VariableNonDefinieException() {
    }
    
    public VariableNonDefinieException(Variable v) {
        this.variable = v;
    }
        
    public String getMessage() {
       
        if (this.variable != null) 
            return "La variable "+this.variable.nom()+" n'est pas definie\n"+super.getMessage();
        else
            return "Un certain nombre de variables ne sont pas definies\n"+super.getMessage();
    }

}
