package expressions;

public interface Exp {

    public double evaluer(Contexte cxt);
    
    public boolean isEvaluable(Contexte cxt);
    
    public String decompiler();
     
    public Exp reduire(Contexte cxt);
    
}
