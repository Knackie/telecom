package expressions;

public class Plus extends Binaire {

    public Plus(Exp opg, Exp opd) {
        super(opg, opd);
    }

    protected double calculer(double valG, double valD) {
        return valG + valD;
    }

    protected String symbole() {
        return "+";
    }
}
