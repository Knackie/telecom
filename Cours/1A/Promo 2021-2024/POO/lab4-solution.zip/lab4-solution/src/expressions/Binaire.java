package expressions;

public abstract class Binaire implements Exp {

    protected Exp operandeGauche;
    protected Exp operandeDroite;

    public Binaire(Exp opg, Exp opd) {
        this.operandeGauche = opg;
        this.operandeDroite = opd;
    }

    public Exp operandeGauche() {
        return this.operandeGauche;
    }

    public Exp operandeDroite() {
        return this.operandeDroite;
    }

    public boolean isEvaluable(Contexte cxt) {
        return (this.operandeGauche.isEvaluable(cxt) && this.operandeDroite.isEvaluable(cxt));
    }

    public double evaluer(Contexte cxt) {
        if (this.isEvaluable(cxt)) {
            return calculer(this.operandeGauche.evaluer(cxt), this.operandeDroite.evaluer(cxt));
        } else {
            throw new VariableNonDefinieException();
        }

    }

    public String decompiler() {
        return "(" + this.operandeGauche.decompiler() + symbole() + this.operandeDroite.decompiler() + ")";
    }

    protected abstract double calculer(double evaluer, double evaluer0);

    protected abstract String symbole();

    public Exp reduire(Contexte cxt) {
        this.operandeGauche = this.operandeGauche.reduire(cxt);
        this.operandeDroite = this.operandeDroite.reduire(cxt);
  
        if (this.operandeGauche instanceof Constante && this.operandeDroite instanceof Constante) {
            double vg = ((Constante) this.operandeGauche).valeur();
            double vf = ((Constante) this.operandeDroite).valeur();
            return new Constante(calculer(vg,vf));
        } else {
            return this;
        }
    }
}
