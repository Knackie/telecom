package expressions;

public class Test {

    public static void main(String[] args) {
             
        Constante c1 = new Constante(2.0);       
        Constante c2 = new Constante(-3.0);
        Constante c3 = new Constante(4.0);
        Constante c4 = new Constante(7.0);
        
        Variable x = new Variable("x");
        Variable y = new Variable("y");
        Variable z = new Variable("z");
        
        Exp e1 = new Max(new Exp[]{c1,x,c2,y});
        Exp e2 = new Moins(c4,e1);
        Exp e3 = new Plus(e2,z);
        
        
        System.out.println("E = "+e3.decompiler());
        Contexte cxt = new Contexte();
        cxt.fixerValeur(x, 2.0);
        cxt.fixerValeur(y, -3.0);
        cxt.fixerValeur(z, -1.0);
        System.out.println("E {x=2;y=-3;z=-1} = "+e3.evaluer(cxt));
        
        cxt.supprimerValeur(y);
        //System.out.println("E {x=2;z=-5} = "+e3.evaluer(cxt));
        System.out.println("E {x=2;y=-3;z=-5} = "+e3.reduire(cxt).decompiler());
    }
    
    
}
