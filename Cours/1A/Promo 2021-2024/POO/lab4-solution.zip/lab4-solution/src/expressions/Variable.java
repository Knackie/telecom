package expressions;

public class Variable implements Exp {

    private String nom;
    
    public Variable(String nom) {
        this.nom = nom;
    }
    
    public String nom() {
        return this.nom;
    }

    public double evaluer(Contexte cxt) {
        if (cxt.estDefinie(this)) {
            return cxt.valeur(this);
        } else {
            throw new VariableNonDefinieException(this);
        }
    }

    public boolean isEvaluable(Contexte cxt) {
        return cxt.estDefinie(this);
    }

    public String decompiler() {
        return this.nom;
    }

    public Exp reduire(Contexte cxt) {
        if (cxt.estDefinie(this)) {
            return new Constante(cxt.valeur(this));
        } else {
            return this;
        }
    }
    
}
