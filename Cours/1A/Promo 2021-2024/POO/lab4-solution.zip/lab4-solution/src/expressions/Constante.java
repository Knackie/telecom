package expressions;

public class Constante implements Exp {

    private double valeur;

    public Constante(double valeur) {
        this.valeur = valeur;
    }
    
    public double valeur() {
        return this.valeur;
    }

    public double evaluer(Contexte cxt) {
        return this.valeur;
    }

    public void fixerValeur(double valeur) {
        this.valeur = valeur;
    }

    public boolean isEvaluable(Contexte cxt) {
        return true;
    }

    public String decompiler() {
        if (this.valeur < 0) {
            return "(" + Double.toString(this.valeur) + ")";
        } else {
            return Double.toString(this.valeur);
        }
    }

    public Exp reduire(Contexte cxt) {
        return this;
    }
}
