# Labs #4 - Expressions arithmétiques

## Objectifs

- Concevoir et créer ses propres classes
  - interface, constructeurs, variable d'instances, méthodes
  - composition et délégation
  - tableaux (*dynamiques*) à taille variable
  - héritage, classe abstraites
  - liaison dynamique
  - appel de constructeurs en cascade
  - généricité
- Savoir compiler/exécuter un programme Java
  - notion basique de *package*
  - notion basique de *classpath*
- Savoir *refactoriser* du code existant
- Savoir exécuter des tests unitaires
- Créer ses propres classes d'exceptions
- Savoir gérer les exceptions dans un programme
- Tester ses propres classes
  - test unitaires

## Préliminaires

Vous réaliserez ce travail dans un dépôt Git local. Il vous est demandé de committer régulièrement vos contributions et de *pousser* celles-ci sur la plateforme GitLab (https://gitlab.telecomnancy.univ-lorraine.fr) de l'école.

Veillez à organiser votre dépôt de la manière suivante :
  - un répertoire `src/` dans lequel vous placerez le code source de votre travail
  - ne committez que le code source Java et non les versions compilées de vos programmes. Pour cela ajouter le nécessaire dans le fichier `.gitignore` pour ignorer les fichiers `.class` (si ce n'est pas déjà fait)

Nous vous invitons à consulter :

  - l'API Java 17 en ligne : https://docs.oracle.com/en/java/javase/17/docs/api/
  - les support de cours : 
    - CM1 (partie 1): https://arche.univ-lorraine.fr/mod/resource/view.php?id=1059764
    - CM1 (partie 2) : https://arche.univ-lorraine.fr/mod/resource/view.php?id=1059766
    - CM2 (auto-apprentissage) : https://arche.univ-lorraine.fr/mod/resource/view.php?id=1059769 
    - CM3 (partie 1) : https://arche.univ-lorraine.fr/mod/resource/view.php?id=1059774 
    - CM3 (partie 2) : https://arche.univ-lorraine.fr/mod/resource/view.php?id=1059773
    - CM4 : https://arche.univ-lorraine.fr/mod/resource/view.php?id=1059776 

  - les feuillets récapitulatifs de la syntaxe du langage Java : 
    
    https://arche.univ-lorraine.fr/mod/resource/view.php?id=1059780.


## Rendu

Aucun rendu n'est nécessaire pour ce sujet. Toutefois, nous vous invitons fortement à essayer par vous-même de réaliser le sujet complètement 
et à ne pas hésiter à contacter votre encadrants universitaires si vous avez des questions/problèmes.

## Travail demandé

Le [sujet de la séance est disponible sous forme d'un fichier au format PDF](./enonce.pdf).

