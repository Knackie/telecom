function X = expo (lambda)
X = -log(rand)/lambda;
end