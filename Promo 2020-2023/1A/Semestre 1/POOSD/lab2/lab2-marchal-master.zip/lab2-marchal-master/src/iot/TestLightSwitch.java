package iot;

public class TestLightSwitch {
    public static void test() {
        Light lamp1 = new Light();
        Light lamp2 = new Light();
        Light lamp3 = new Light();
        Light lamp4 = new Light();
        LightSwitch interrupteur = new LightSwitch();

        System.out.println("Test LightSwitch :");
        interrupteur.addLight(lamp1);
        interrupteur.addLight(lamp2);
        interrupteur.addLight(lamp3);
        interrupteur.addLight(lamp4);

        System.out.println("Etat");
        System.out.println(lamp1.getEtat());
        System.out.println(lamp2.getEtat());
        System.out.println(lamp3.getEtat());
        System.out.println(lamp4.getEtat());
        System.out.println(interrupteur.getEtat());
        System.out.println("Allumer");
        interrupteur.allumer();
        System.out.println(lamp1.getEtat());
        System.out.println(lamp2.getEtat());
        System.out.println(lamp3.getEtat());
        System.out.println(lamp4.getEtat());
        System.out.println(interrupteur.getEtat());
        System.out.println("Eteindre");
        interrupteur.eteindre();
        System.out.println(lamp1.getEtat());
        System.out.println(lamp2.getEtat());
        System.out.println(lamp3.getEtat());
        System.out.println(lamp4.getEtat());
        System.out.println(interrupteur.getEtat());

        System.out.println("Remove lamp 3 et 4 :");
        interrupteur.remLight(lamp3);
        interrupteur.remLight(lamp4);
        System.out.println("Allumer");
        interrupteur.allumer();
        System.out.println(lamp1.getEtat());
        System.out.println(lamp2.getEtat());
        System.out.println(lamp3.getEtat());
        System.out.println(lamp4.getEtat());
        System.out.println(interrupteur.getEtat());
        System.out.println("Eteindre");
        interrupteur.eteindre();
        System.out.println(lamp1.getEtat());
        System.out.println(lamp2.getEtat());
        System.out.println(lamp3.getEtat());
        System.out.println(lamp4.getEtat());
        System.out.println(interrupteur.getEtat());
    }
}
