package iot;

public class Light {
    private boolean etat; // Etat de la lumière

    public Light() {
        this.etat = false;
    }

    public boolean getEtat() {
        return etat;
    }

    public void allumer() {
        etat = true;
    }

    public void eteindre() {
        etat = false;
    }

    public void inverser() {
        etat = !etat;
    }

    @Override
    public String toString() {
        if(etat) return "Allumée";
        else return "Eteinte";
    }
}
