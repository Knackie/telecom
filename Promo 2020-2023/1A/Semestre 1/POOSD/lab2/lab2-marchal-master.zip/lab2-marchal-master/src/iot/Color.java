package iot;

public class Color {
    private int red;
    private int green;
    private int blue;

    public Color(int red, int green, int blue) {
        if (red < 0) red = 0;
        else if (red > 255) red = 255;
        this.red = red;

        if (green < 0) green = 0;
        else if (green > 255) green = 255;
        this.green = green;

        if (blue < 0) blue = 0;
        else if (blue > 255) blue = 255;
        this.blue = blue;
    }

    public int getRed() {
        return red;
    }

    public int getGreen() {
        return green;
    }

    public int getBlue() {
        return blue;
    }

    public void setRed(int red) {
        if (red < 0) red = 0;
        else if (red > 255) red = 255;
        this.red = red;
    }

    public void setGreen(int green) {
        if (green < 0) green = 0;
        else if (green > 255) green = 255;
        this.green = green;
    }

    public void setBlue(int blue) {
        if (blue < 0) blue = 0;
        else if (blue > 255) blue = 255;
        this.blue = blue;
    }
}
