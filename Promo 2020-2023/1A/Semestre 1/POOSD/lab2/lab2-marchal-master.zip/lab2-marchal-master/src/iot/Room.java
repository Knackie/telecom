package iot;

import java.util.ArrayList;

public class Room {
    private String name;
    private ArrayList<Light> lampList = new ArrayList<>();

    public Room(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public ArrayList<Light> getLampList() {
        return lampList;
    }

    @Override
    public String toString() {
        String result = name + " : ";
        for (int i = 0; i < lampList.size(); i++) {
            result = result + "Light est " + lampList.get(i) + ", ";
        }
        return result;
    }

    public String status() {
        return toString();
    }

    // Ajouter une Light
    public void addLight(Light lamp) {
        boolean dejaPresent = false;
        for (int i = 0; i < lampList.size(); i++) {
            if (lampList.get(i) == lamp) dejaPresent = true;
        }
        if (!dejaPresent) {
            lampList.add(lamp);
        }
    }

    // Supprimer une Light
    public void remLight(Light lamp) {
        lampList.remove(lamp);
    }
}
