import iot.*;

public class Main {
    public static void main(String[] args) {
        System.out.println("TestLightSwitch :");
        TestLightSwitch.test();
        System.out.println("TestDashBoard");
        TestDashboard.test();
        System.out.println("TestHomeDashboard");
        TestHomeDashboard.test();
    }
}
