package iot;

import java.util.HashMap;

public class HomeDashboard extends Dashboard {
    private HashMap<String, Room> roomList = new HashMap<>();

    public HomeDashboard() {
        super();
    }

    public void addRoom(Room piece) {
        roomList.put(piece.getName(), piece);
    }

    public void remRoom(Room piece) {
        roomList.remove(piece.getName());
    }

    public void addLightInRoom(Light lamp, Room piece) {
        piece.addLight(lamp);
    }

    public void remLightInRoom(Light lamp, Room piece) {
        piece.remLight(lamp);
    }

    public void addLightInRoom(Light lamp, String piece) {
        roomList.get(piece).addLight(lamp);
    }

    public void remLightInRoom(Light lamp, String piece) {
        roomList.get(piece).remLight(lamp);
    }

    public void allumerLightRoom(Room piece) {
        for (int i = 0; i < piece.getLampList().size(); i++) {
            piece.getLampList().get(i).allumer();
        }
    }

    public void eteindreLightRoom(Room piece) {
        for (int i = 0; i < piece.getLampList().size(); i++) {
            piece.getLampList().get(i).eteindre();
        }
    }

    public void allumerLightRoom(String piece) {
        for (int i = 0; i < roomList.get(piece).getLampList().size(); i++) {
            roomList.get(piece).getLampList().get(i).allumer();
        }
    }

    public void eteindreLightRoom(String piece) {
        for (int i = 0; i < roomList.get(piece).getLampList().size(); i++) {
            roomList.get(piece).getLampList().get(i).eteindre();
        }
    }

    @Override
    public String toString() {
        String result = super.toString();
        for (String piece : roomList.keySet()) {
            result = result + "Room Lights are : {" + roomList.get(piece) + "}, ";
        }
        return result;
    }
}
