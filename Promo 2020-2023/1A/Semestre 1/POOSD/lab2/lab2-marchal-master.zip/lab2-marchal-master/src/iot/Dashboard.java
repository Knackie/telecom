package iot;

import java.util.ArrayList;

public class Dashboard {
    private ArrayList<Light> lamps = new ArrayList<>();
    private ArrayList<LightSwitch> interrupteurs = new ArrayList<>();

    public Dashboard() {
    }

    // Ajoute un appareil de type Light
    public void addAppareil(Light lamp) {
        boolean dejaPresent = false;
        for (int i = 0; i < lamps.size(); i++) {
            if (lamps.get(i) == lamp) dejaPresent = true;
        }
        if (!dejaPresent) {
            lamps.add(lamp);
        }
    }

    // Ajoute un appareil de type LightSwitch
    public void addAppareil(LightSwitch interrupteur) {
        boolean dejaPresent = false;
        for (int i = 0; i < interrupteurs.size(); i++) {
            if (interrupteurs.get(i) == interrupteur) dejaPresent = true;
        }
        if (!dejaPresent) {
            interrupteurs.add(interrupteur);
        }
    }

    // Retire un appareil de type Light
    public void removeAppareil(Light lamp) {
        lamps.remove(lamp);
    }

    // Reture un appareil de type LightSwitch
    public void removeAppareil(LightSwitch interrupteur) {
        interrupteurs.remove(interrupteur);
    }

    // Déconnecte une Light de tous les LightSwitch
    public void deconnectLight(Light lamp) {
        for (int i = 0; i < interrupteurs.size(); i++) {
            interrupteurs.get(i).remLight(lamp);
        }
    }

    @Override
    public String toString() {
        String result = "";
        for (int i = 0; i < interrupteurs.size(); i++) {
            result = result + "LightSwitch est " + interrupteurs.get(i) + ", ";
        }
        for (int i = 0; i < lamps.size(); i++) {
            result = result + "Light est " + lamps.get(i) + ", ";
        }
        return result;
    }

    public String status() {
        return toString();
    }
}
