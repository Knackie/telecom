package iot;

public class TestDashboard {
    public static void test() {
        // Créations des objets
        Light l1 = new Light();
        Light l2 = new Light();
        Light l3 = new Light();
        Light l4 = new Light();
        LightSwitch s1 = new LightSwitch();
        LightSwitch s2 = new LightSwitch();
        Dashboard dashboard = new Dashboard();

        // Connexion des objets ensemble
        s1.addLight(l1);
        s1.addLight(l1);
        s1.addLight(l2);
        s2.addLight(l1);
        s2.addLight(l3);
        dashboard.addAppareil(s1);
        dashboard.addAppareil(s2);
        dashboard.addAppareil(l4);

        // Test toString de dashboard
        System.out.println(dashboard);
        // Test suppression d'équipement
        dashboard.removeAppareil(s2);
        System.out.println(dashboard);
        dashboard.addAppareil(s2);
        // Test déconnexion light
        dashboard.deconnectLight(l1);
        dashboard.addAppareil(l1);
        System.out.println(dashboard);
        s1.allumer();
        System.out.println(dashboard);
    }
}
