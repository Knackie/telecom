package iot;

public class ColoredLight extends Light {
    private Color couleur = new Color(255,255,255);
    private int intensite = 100; // Intensité en %

    public ColoredLight() {
        super();
    }

    @Override
    public String toString() {
        return super.toString() + " R=" + couleur.getRed() + " G=" + couleur.getGreen() + " B=" +couleur.getBlue();
    }

    public Color getCouleur() {
        return couleur;
    }

    public int getIntensite() {
        return intensite;
    }

    public void setCouleur(Color couleur) {
        this.couleur = couleur;
    }

    public void setIntensite(int intensite) {
        if (intensite > 100) intensite = 100;
        else if (intensite < 0) intensite = 0;
        this.intensite = intensite;
    }

    public void setCouleur(int red, int green, int blue) {
        this.couleur.setRed(red);
        this.couleur.setGreen(green);
        this.couleur.setBlue(blue);
    }
}
