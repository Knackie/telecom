package iot;

public class TestHomeDashboard {
    public static void test() {
        // Créations des objets
        Light l1 = new Light();
        Light l2 = new Light();
        Light l3 = new Light();
        Light l4 = new Light();
        LightSwitch s1 = new LightSwitch();
        LightSwitch s2 = new LightSwitch();
        Room p1 = new Room("chambre");
        Room p2 = new Room("cuisine");
        HomeDashboard dashboard = new HomeDashboard();

        // Connexion des objets ensemble
        s1.addLight(l1);
        s1.addLight(l1);
        s1.addLight(l2);
        s2.addLight(l1);
        s2.addLight(l3);
        p1.addLight(l1);
        p2.addLight(l3);
        dashboard.addAppareil(s1);
        dashboard.addAppareil(s2);
        dashboard.addAppareil(l4);
        dashboard.addRoom(p1);
        dashboard.addRoom(p2);
        dashboard.addLightInRoom(l2,p1);
        dashboard.addLightInRoom(l4,"cuisine");

        // Test toString de dashboard
        System.out.println(dashboard);
        // Test suppression d'équipement
        dashboard.removeAppareil(s2);
        System.out.println(dashboard);
        dashboard.addAppareil(s2);
        // Test déconnexion light
        dashboard.deconnectLight(l1);
        dashboard.addAppareil(l1);
        System.out.println(dashboard);
        s1.allumer();
        System.out.println(dashboard);
        // Test RoomLight
        dashboard.allumerLightRoom(p1);
        dashboard.allumerLightRoom("cuisine");
        System.out.println(dashboard);
    }
}
