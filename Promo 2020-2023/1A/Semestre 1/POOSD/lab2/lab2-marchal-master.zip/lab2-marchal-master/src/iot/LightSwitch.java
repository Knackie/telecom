package iot;

import java.util.ArrayList;

public class LightSwitch {

    // Variables
    private ArrayList<Light> lampList = new ArrayList<>();
    private boolean etat;

    public LightSwitch() {
    }

    public void allumer() {
        etat = true;
        for (int i = 0; i < lampList.size(); i++) {
            lampList.get(i).allumer();
        }
    }

    public void eteindre() {
        etat = false;
        for (int i = 0; i < lampList.size(); i++) {
            lampList.get(i).eteindre();
        }
    }

    public void addLight(Light lamp) {
        boolean dejaPresent = false;
        for (int i = 0; i < lampList.size(); i++) {
            if (lampList.get(i) == lamp) dejaPresent = true;
        }
        if (!dejaPresent) {
            lampList.add(lamp);
            if (etat) lamp.allumer();
            else lamp.eteindre();
        }
    }

    public void remLight(Light lamp) {
        lampList.remove(lamp);
    }

    public boolean getEtat() {
        return etat;
    }

    @Override
    public String toString() {
        if (etat) return "Fermé";
        else return "Ouvert";
    }
}
