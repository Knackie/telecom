# Labs #2 - Introduction à la programmation orientée objet

## Objectifs

- Concevoir et créer ses propres classes
  - interface, constructeurs, variable d'instances, méthodes
  - composition et délégation
  - tableaux à taille variable
- Tracer l'exécution d'un segment de code et résumer son effet en terme de mémoire
  - schéma mémoire

## Préliminaires

Vous réaliserez ce travail dans un dépôt Git local. Il vous est demandé de commiter régulièrement vos contributions et de *pousser* celles-ci sur la plateforme GitLab (https://gitlab.telecomnancy.univ-lorraine.fr) de l'école.
Veillez à organiser votre dépôt de la manière suivante :
- un répertoire `src/` dans lequel vous placerez le code source de votre travail
- ne committez que le code source Java et non les versions compilées de vos programmes. Pour cela ajouter le nécessaire dans le fichier `.gitignore` pour ignorer les fichiers `.class`

Nous vous invitons à consulter :
- l'API Java 8 en ligne : https://docs.oracle.com/javase/8/docs/api
- les supports de cours :
   - CM1 : https://arche.univ-lorraine.fr/mod/resource/view.php?id=500965
   - CM1 (homework) : https://arche.univ-lorraine.fr/mod/resource/view.php?id=325549 
- les feuillets récapitulatifs de la syntaxe du langage Java https://arche.univ-lorraine.fr/mod/resource/view.php?id=325548.


## Rendu

Ce travail est à rendre au plus tard le _définie ultérieurement_ sur la plateforme GitLab de l'école. Toutefois **un premier rendu à la fin de la séance de TD/TP est obligatoire**.

# Domotique et objets connectés

L'objectif de cet exercice est de modifier la classe `iot.LightSwitch` de manière à pouvoir contrôler plusieurs lampes à partir d'un même interrupteur.

## Modification de la la classe `iot.LightSwitch`

![Carte CRC de la classe iot.LightSwitch](./figures/crc-iot.lightswitch-new.png "Carte CRC de la classe iot.LightSwitch")

1. En vous aidant de la carte CRC correspondante et en reprenant la  classe `iot.LightSwitch` résultante de la séance de TP précédente, spécifiez l'interface publique d’un objet de classe `iot.LightSwitch`. 

2. Modifiez la classe `iot.LightSwitch` pour allumer et éteindre plusieurs lampes en même temps. Vous utiliserez une collection pour sauvegarder les références des lampes contrôlées par l'interrupteur. Pour ce faire, vous utiliserez la classe `java.util.ArrayList` (veuillez lire la [documentation associée](https://docs.oracle.com/javase/8/docs/api/java/util/ArrayList.html)).


## Modification de la classe `iot.TestLightSwitch`

1. Modifiez la classe `iot.TestLightSwitch` afin de prendre en compte (et donc de tester) les modifications apportées précédemment.

2. Quel est l'état de la lampe `l2` après l'exécution du code suivant ? Vous dessinerez (à la main) le schéma mémoire correspondant. Puis vous vérifierez celui-ci en utilisant la plateforme artEoz. Ajouter le schéma mémoire généré par artEoz à votre déopt sous la forme d'une image `.svg` (`figures/schema_memoire_lightswitch.svg`).

```java
Light l1 = new Light();
Light l2 = new Light();
LightSwitch s1 = new LightSwitch();
s1.bind(l1);
s1.bind(l2);
s1.bind(l2);

s1.turnOn();
s1.turnOnOff();
```

3. Que pouvez-vous faire pour éviter le problème identifié dans la question précédente ? Modifiez la méthode `iot.LightSwitch#bind` en conséquence.


# Un panneau de contrôle simpliste : Dashboard

À l'instar des géants du numérique, nous souhaitons à présent centraliser tous les objets connectés dans un tableau de bord. Les utilisateurs pourront ainsi consulter l'état de leurs appareils (lampes et interrupteurs) grâce à ce dernier.

## La classe `iot.Dashboard`

![Carte CRC de la classe iot.Dashboard](./figures/crc-iot.dashboard.png "Carte CRC de la classe iot.Dashboard")

1. En vous aidant de la carte CRC correspondante, spécifiez l'interface publique d’un objet de classe `iot.Dashboard`.

2. Pour assurer la compatibilité avec la classe `iot.Dashboard`, modifiez les classes `iot.Light` et `iot.LightSwitch` de façon à ce qu'elles renvoient un status (i.e. une chaîne de caractères renseignant sur l'état de la lampe). Appuyez-vous sur le concept de délégation.

3. Implémentez la classe `iot.Dashboard` en écrivant le corps des méthodes de l'interface publique dans un fichier `src/iot/Dashboard.java`. De la même manière que pour la classe `iot.LightSwitch`, vous utiliserez la classe `java.util.ArrayList` pour sauvegarder les références des lampes et des interrupteurs. Attention, comme indiqué dans la carte CRC, la classe `iot.Dashboard` n'a pas la responsabilité de maintenir les connexions entre les interrupteurs et les lampes.

## La classe de test `iot.TestDashboard` 

Écrivez une classe de test `iot.TestDashboard` qui démontre le bon fonctionnement de votre code.

## Schéma mémoire

Dessinez le schéma mémoire correspondant à l'exécution de votre classe de test en utilisant la plateforme artEoz. Ajoutez le schéma mémoire généré par l'outil à votre dépôt sous la forme d'une image (`figures/schema_memoire-dashboard.svg`)



# Un panneau de contrôle... plus intelligent

La compétition est rude et pour résister face à la concurrence, nous souhaitons ajouter une nouvelle fonctionnalité à notre panneau de contrôle pour le rendre plus modulaire. Nous souhaitons offrir à nos utilisateurs la possibilité d'enregistrer des pièces (chambre à coucher, salle de bain, cuisine, etc.) dans lesquelles seront installées les lampes. Ainsi, l'utilisateur pourra directement demander au panneau de contrôle d'allumer toutes les lampes d'une pièce ou d'éteindre toutes les lumières de son logement.
Avec un peu de reconnaissance vocale, nous pourrions arriver à ce résultat là : *Ok g**gle ! Peux-tu allumer la lumière dans le salon ?* 

## La classe `iot.Room`

![Carte CRC de la classe iot.Room](./figures/crc-iot.room.png "Carte CRC de la classe iot.Room")

1. En vous aidant de la carte CRC correspondante, spécifiez l'interface publique d’un objet de classe `iot.Room`.

2. Implémentez la classe `iot.Room` en écrivant le corps des méthodes de l'interface publique. De la même manière que pour la classe `iot.Dashboard`, vous utiliserez la classe `java.util.ArrayList` pour sauvegarder les références des lampes installées.


## La classe `iot.HomeDashboard`

Nous souhaitons modifier la classe `iot.Dashboard` de manière à ce qu'elle prenne en charge les pièces et la localisation des lampes. In fine, nous souhaitons que l'utilisateur gère les pièces et l'installation des lampes uniquement à travers le tableau de bord. Par l'intermédiaire de ce tableau de bord, l'utilisateur devra également pouvoir allumer ou éteindre toutes les lampes d'une pièce en la désignant par son nom (*une chaîne de caratères*).

![Carte CRC de la classe iot.Room](./figures/crc-iot.homedashboard.png "Carte CRC de la classe iot.HomeDashboard")

1. Écrivez la classe `iot.HomeDashboard` pour gérer les pièces en accord avec la carte CRC correspondante. Les références des pièces seront conservées dans des collections de type `java.util.HashMap`. Cette collection diffère un peu des collections de types `java.util.ArrayList`. Il s'agit d'un tableau associatif qui à une clé donnée associe l'objet correspondant (veuillez lire la documentation associée). Nous vous demandons d'utiliser comme clé le nom de la pièce associée.

2. Écrivez une classe permettant de tester le comportement de la classe `iot.HomeDashboard`.

## Un peu de couleurs...

Le marché des lampes connectées s'est beaucoup diversifié ces dernière annnées. Nous souhaitons pouvoir connecter d'autres types de lampe, en particulier, des lampes dont la couleur est modifiable.

## Les classes `iot.Color` et `iot.ColoredLight`

![Carte CRC de la classe iot.ColoredLight](./figures/crc-iot.coloredlight.png "Carte CRC de la classe iot.ColoredLight")

![Carte CRC de la classe iot.Color](./figures/crc-iot.color.png "Carte CRC de la classe iot.Color")

1. En vous appuyant sur la carte CRC correspondante, écrivez la classe `iot.Color`.

2. En vous appuyant sur la classe `iot.Light` et la carte CRC correspondante, écrivez la classe `iot.ColoredLight`.

3. Quelles modifications doivent être apportées dans les autres classes pour pouvoir utiliser des lampes colorées ? Qu'est-ce qui serait désirable de pouvoir faire pour limiter ces changements ?

