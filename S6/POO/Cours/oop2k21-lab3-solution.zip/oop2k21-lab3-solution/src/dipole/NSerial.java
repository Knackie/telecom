package dipole;

public class NSerial extends NAry {

    public Complex impedance(double omega) {
        Complex res = new Complex();

        for (Dipole d : this.dipoles) {
            res.add(d.impedance(omega));
        }

        return res;
    }

}