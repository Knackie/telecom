package dipole;

public class Instances {
	public static Dipole dip1() {
		NParallel res = new NParallel();
		res.addDipole(new Resistor(1e2));
		res.addDipole(new Serial(new Coil(5e-5), new Resistor(12e3)));
		res.addDipole(new Capacitor(9e-4));
		return res;
	}
	public static Dipole dip2() {
		NParallel core = new NParallel();
		core.addDipole(new Serial(new Resistor(1e3), new Coil(5e-2)));
		core.addDipole(new Capacitor(9e-3));
		core.addDipole(new Serial(new Capacitor(9e-4), new Capacitor(1e-5)));
		Serial center = new Serial(core, new Resistor(330));
		Parallel middle = new Parallel(center, new Serial(new Resistor(1000), new Coil(2*1e-1)));
		NSerial res = new NSerial();
		res.addDipole(new Resistor(100));
		res.addDipole(middle);
		res.addDipole(new Capacitor(1e-6));
		return res;
	}
}