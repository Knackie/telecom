package dipole;

public interface Dipole {

    public Complex impedance(double omega) ;

}