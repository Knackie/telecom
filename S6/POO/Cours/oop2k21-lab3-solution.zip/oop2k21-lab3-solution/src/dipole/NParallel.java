package dipole;

public class NParallel extends NAry {

    public Complex impedance(double omega) {
        Complex res = new Complex();

        for (Dipole d : this.dipoles) {
            res.add(d.impedance(omega).inverse());
        }

        return res.inverse();
    }

}