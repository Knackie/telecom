package dipole;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class ParallelTest {

    @Test
    void testParallel() {
        Resistor r = new Resistor(100.);
        Coil c = new Coil(5e-2);
        Parallel p1 = new Parallel(r, c);
        Capacitor cp = new Capacitor(9e-4);
        Parallel p2 = new Parallel(p1, cp);

        assertEquals(new Complex(0.20791318, -4.55500719), p2.impedance(314.16));
        assertEquals(new Complex(2.469599e-4, 0.15714940), p2.impedance(3.1416));
    }

}
