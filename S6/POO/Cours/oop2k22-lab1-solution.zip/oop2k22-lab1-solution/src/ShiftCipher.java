public class ShiftCipher {

    public static void main(String[] args) {

        if (args.length != 1) {
            System.err.println("Usage: java ShiftCipher shift_count");
            System.exit(-1);
        }

        int shift = Integer.parseInt(args[0]);

        char[] alphabet = { 
            'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm',
            'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 
            'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 
            'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z',
            '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', ' ', ',', '.' 
        };

        String messageStr = "Too Many Secrets";

        char[] message = messageStr.toCharArray();

        char[] cipher = new char[message.length];

        for (int i=0; i<message.length; i++) {
            int charToEncode = message[i];

            int indexOfChar = 0;
            while ((indexOfChar<alphabet.length) && (alphabet[indexOfChar] != charToEncode)) {
                indexOfChar++;
            }
            if (indexOfChar==alphabet.length) {
                System.out.println("Please use characters in the alphabet");
                return;
            } else {            
                cipher[i] = alphabet[Math.floorMod(indexOfChar + shift, alphabet.length)];         
            }
        }

        System.out.println(String.valueOf(cipher));
    }

}