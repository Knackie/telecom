public class BruteForce {

    public static void main(String[] args) {

        char[] alphabet = { 
            'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm',
            'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 
            'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 
            'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z',
            '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', ' ', ',', '.' 
        };

        String cipheredStr = "bGUUzYKVJzVJGzDGUVAz5KGzNKMGzVJGzTGUVA";

        char[] ciphered = cipheredStr.toCharArray();

        char[] message = new char[ciphered.length];

        for (int shift=1 ; shift < alphabet.length ; shift++) {
            for (int i=0; i<message.length; i++) {
                int charToEncode = ciphered[i];

                int indexOfChar = 0;
                while (alphabet[indexOfChar] != charToEncode) {
                    indexOfChar++;
                }

                message[i] = alphabet[Math.floorMod(indexOfChar + shift, alphabet.length)];  
                       
            }

            System.out.println("[" + (alphabet.length-shift) + "]: " + String.valueOf(message));
        }
    }

}