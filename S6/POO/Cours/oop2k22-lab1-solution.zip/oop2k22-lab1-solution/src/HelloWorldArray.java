public class HelloWorldArray {

    public static void main(String[] args) {
        char[] message = { 'H', 'e', 'l', 'l', 'o', ',', ' ', 'W', 'o', 'r', 'l', 'd', '!' };
        
        for (int i=0; i<message.length; i++) {
            System.out.print(message[i]);
        }
        System.out.println();
    }

}