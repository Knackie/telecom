package iot;

import java.util.ArrayList;

public class LightsSwitch {

  private ArrayList<Light> controlledLamps;
  
  public LightsSwitch() {
    this.controlledLamps = new ArrayList<>();
  }

  public LightsSwitch(Light... lamps) {
    this.controlledLamps = new ArrayList<>();
    this.controlledLamps.addAll(java.util.Arrays.asList(lamps));
  }

  public LightsSwitch(ArrayList<Light> lamps) {
    this.controlledLamps = new ArrayList<>();
    this.controlledLamps.addAll(lamps);
  }

  public void bind(Light lamp) {
    // we might check if the lamp is already bound to the switch
    this.controlledLamps.add(lamp);
  }

  public void turnOn() {
    for (Light controlledLamp : this.controlledLamps) {
      controlledLamp.turnOn();
    }
  }

  public void turnOff() {
    for (Light controlledLamp : this.controlledLamps) {
      controlledLamp.turnOff();
    }
  }

  public void turnOnOff() {
    for (Light controlledLamp : this.controlledLamps) {
      controlledLamp.turnOnOff();
    }
  }

}
