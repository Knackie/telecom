package iot;

public class Light {

	private boolean state;

	public Light() {
		this.state = false;
	}

	public void turnOn() {
		this.state = true;
	}

	public void turnOff() {
		this.state = false;
	}

	public void turnOnOff() {
		this.state = ! state;
	}

	public boolean isOn() {
		return this.state;
	}

}
