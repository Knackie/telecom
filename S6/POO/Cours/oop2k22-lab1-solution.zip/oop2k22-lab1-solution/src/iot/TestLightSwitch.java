package iot;

public class TestLightSwitch {

  public static void main(String[] args) {
     (new TestLightSwitch()).run();
  }

  public void check(String message, boolean condition, String debug) {
    if (! condition) {
      System.out.print("[failed]\t"+debug+" - ");
    } else {
      System.out.print("[ok]\t");
    }
    System.out.println(message);
  }

  public void run() {

    Light lamp = new Light();
    LightSwitch remoteController = new LightSwitch();
    boolean expected = false; // par defaut la lampe est eteinte

    remoteController.bind(lamp);
    boolean value = lamp.isOn();
    check("Etat de la lampe associee a la telecommande", value == expected, 
          "expected=" + expected + " value=" + value);

    remoteController.turnOn();
    expected = true;
    value = lamp.isOn();
    check("Etat de la lampe apres allumage depuis la telecommande", value == expected, 
          "expected=" + expected + " value=" + value);

    remoteController.turnOff();
    expected = false;
    value = lamp.isOn();
    check("Etat de la lampe apres extinction depuis la telecommande", value == expected, 
          "expected=" + expected + " value=" + value);

    remoteController.turnOnOff();
    expected = true;
    value = lamp.isOn();
    check("Etat de la lampe apres un premier switch depuis la telecommande", value == expected, 
          "expected=" + expected + " value=" + value);

    remoteController.turnOnOff();
    expected = false;
    value = lamp.isOn();
    check("Etat de la lampe apres un deuxieme switch depuis la telecommande ", value == expected, 
          "expected=" + expected + " value=" + value);

  }
}
