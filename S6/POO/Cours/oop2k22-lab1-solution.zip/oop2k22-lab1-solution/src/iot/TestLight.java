package iot;

public class TestLight {

  public static void main(String[] args) {
     (new TestLight()).run();
  }

  public void check(String message, boolean condition, String debug) {
    if (! condition) {
      System.out.print("[failed]\t"+debug+" - ");
    } else {
      System.out.print("[ok]\t");
    }
    System.out.println(message);
  }

  public void run() {
    Light lamp = new Light();
    boolean expected = false; // par defaut la lampe est eteinte
    boolean value = lamp.isOn();
    check("Etat de la lampe par defaut", value == expected, 
          "expected="+expected+" value="+value);

    lamp.turnOn();
    expected = true;
    value = lamp.isOn();
    check("Etat de la lampe apres allumage", value == expected, 
          "expected="+expected+" value="+value);

    lamp.turnOff();
    expected = false;
    value = lamp.isOn();
    check("Etat de la lampe apres extinction", value == expected, 
          "expected="+expected+" value="+value);

    lamp.turnOnOff();
    expected = true;
    value = lamp.isOn();
    check("Etat de la lampe apres un premier switch", value == expected, 
          "expected="+expected+" value="+value);

    lamp.turnOnOff();
    expected = false;
    value = lamp.isOn();
    check("Etat de la lampe apres un deuxieme switch", value == expected, 
          "expected="+expected+" value="+value);
  }
}
