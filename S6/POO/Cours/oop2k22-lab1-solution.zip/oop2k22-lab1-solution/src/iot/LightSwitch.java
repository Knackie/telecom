package iot;

public class LightSwitch {

  private Light controlledLamp;
  
  public LightSwitch() {
  }

  public LightSwitch(Light lamp) {
    this.controlledLamp = lamp;
  }

  public void bind(Light lamp) {
    this.controlledLamp = lamp;
  }

  public void turnOn() {
    this.controlledLamp.turnOn();
  }

  public void turnOff() {
    this.controlledLamp.turnOff();
  }

  public void turnOnOff() {
    this.controlledLamp.turnOnOff();
  }

}
