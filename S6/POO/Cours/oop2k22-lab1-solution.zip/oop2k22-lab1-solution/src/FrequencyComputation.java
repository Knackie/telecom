import java.util.List;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;


public class FrequencyComputation {


    public static char[][] readTextFile(String filename) {
        char[][] text = null;

        try {
            Scanner sc = new Scanner(new File(filename));

            List<char[]> lines = new ArrayList<char[]>();
            while (sc.hasNextLine()) {
                lines.add(sc.nextLine().toCharArray());
            }
            sc.close();

            text = new char[lines.size()][];
            int lineCount = 0;
            for (char[] l : lines) {
                text[lineCount++] = l;
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        return text;
    }

    public static void main(String[] args) {
        String filename = "../data/sometext.txt";

        char[][] text = readTextFile(filename);


        char[] alphabet = { 
            'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm',
            'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 
            'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 
            'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z',
            '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', ' ', ',', '.' 
        };

        double[] frequencies = new double[alphabet.length];
        int charCount = 0;
        for (int l=0 ; l<text.length; l++) {
            for (int c=0; c<text[l].length; c++) {

                char charToProcess = text[l][c];
                int indexOfChar = 0;
                try {
                while (alphabet[indexOfChar] != charToProcess) {
                    indexOfChar++;
                }
            } catch (java.lang.ArrayIndexOutOfBoundsException ex) {
                System.err.println("<" + charToProcess + "> not found");
            }

                frequencies[indexOfChar]++;
                charCount++;
            }
        }
        for (int i=0; i<frequencies.length; i++) {
            frequencies[i] = frequencies[i] / charCount;
        }

        for (int i=0; i<alphabet.length; i++) {
            System.out.println(alphabet[i] + ":" + frequencies[i]);
        }
    }
}