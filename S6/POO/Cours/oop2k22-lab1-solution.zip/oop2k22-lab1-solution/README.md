# Labs #1 - Introduction à la programmation en Java

## Objectifs

- Connaître la syntaxe de base du langage Java
  - variables, types primitifs, tableaux à taille fixe
  - boucles, conditionnelles, etc.
- Concevoir et créer ses propres classes
  - interface, constructeurs, variable d'instances, méthodes
  - composition et délégation
- Savoir compiler/exécuter un programme Java
  - concept de machine virtuelle
  - notion basique de *package*
  - notion basique de *classpath*
- Tracer l'exécution d'un segment de code et résumer son effet en terme de mémoire
  - schéma mémoire


## Préliminaires

Vous réaliserez ce travail dans un dépôt Git local. Il vous est demandé de committer régulièrement vos contributions et de *pousser* celles-ci sur la plateforme GitLab (https://gitlab.telecomnancy.univ-lorraine.fr) de l'école.

Veillez à organiser votre dépôt de la manière suivante :

  - un répertoire `src/` dans lequel vous placerez le code source de votre travail
  - ne committez que le code source Java et non les versions compilées de vos programme. Pour cela ajouter le nécessaire dans le fichier `.gitignore` pour ignorer les fichiers `.class` (si ce n'est pas déjà fait)

Nous vous invitons à consulter :

  - l'API Java 8 en ligne : https://docs.oracle.com/en/java/javase/17/docs/api/
  - les support de cours : 
    - CM1 (partie 1): https://arche.univ-lorraine.fr/mod/resource/view.php?id=1059764
    - CM1 (partie 2) : https://arche.univ-lorraine.fr/mod/resource/view.php?id=1059766
    - CM2 (auto-apprentissage) : https://arche.univ-lorraine.fr/mod/resource/view.php?id=1059769 
  - les feuillets récapitulatifs de la syntaxe du langage Java : 
    
    https://arche.univ-lorraine.fr/mod/resource/view.php?id=1059780.

Dans ce premier TP, vous  écrirez tout votre code dans le corps de la méthode ``public static void main(String[] args)``. Vous pouvez écrire des fonctions utilitaires si vous le souhaitez, mais ce n'est pas forcément nécessaire.


## Rendu

Ce travail est à rendre au plus tard le **mardi 21 février 2022 à 8:00** sur la plateforme GitLab de l'école. Toutefois **un premier rendu à la fin de la séance de TD/TP est obligatoire**.


## Première partie : Mise à jour de votre environnement

Dans cette partie, nous allons voir comment mettre à jour votre environnement de travail est plus précisément comment étendre l'espace disque de votre machine virtuelle Telecom Nancy, faire un peu de nettoyage, mettre à jour votre environnement et installer les outils nécessaires à la suite du module.


### Ajouter de l'espace de stockage à votre machine virtuelle

Si vous disposez de suffisamment d'espace sur votre machine physique alors vous pouvez dédier un peu plus d'espace disque à votre machine virtuelle (l'espace prévu initialement étant un peu trop restreint).

1. Exécutez VirtualBox, mais ne démarrez par la machine virtuelle
2. Sélectionner sur la machine virtuelle -> Configuration -> Stockage -> Contrôleur SATA -> Ajouter un nouveau disque dur
3. Créer -> VDI (VirtualBox Disk Image) -> Taille fixe -> Indiquer un chemin (celui par défaut devrait convenir) et la taille (10 Go devrait convenir) -> Créer
4. Démarrer votre machine virtuelle
5. Exécuter les commandes suivantes dans un terminal :
   
```sh
# affiche l'espace dispnonible et total
df -h /

# crée un nouveau volume physique LVM à partir du nouveau disque ajouté
sudo pvcreate /dev/sdb
# ajoute le nouveau volum physique au groupe de volume
sudo vgextend vgubuntu /dev/sdb
# étend l'espace logique en utilisant 100% de l'espace disponible dans le volume logique
sudo lvextend -l +100%FREE /dev/vgubuntu/root
# redimensionne l'espace de fichiers ext4
sudo resize2fs /dev/vgubuntu/root

# affiche à nouveau l'espace dispnonible (qui a dû augmenté)
df -h /
```

### Faire un peu de place dans la machine virtuelle (VM)

```sh
sudo snap set system refresh.retain=2  # pour limiter le nombre de version conservée en archive 

LANG=c snap list --all | while read snapname ver rev trk pub notes; do if [[ $notes = *disabled* ]]; then sudo snap remove "$snapname" --purge --revision=$rev; fi; done # pour supprimer toutes les versions qui ne sont pas actives
```

Pour désinstaller IntelliJ et PyCharm si vous ne vous en servez pas (si vous ne les utilisez pas -- nous ne les utiliserons pas en TP)

```sh
sudo snap remove --purge intellij-idea-ultimate
sudo snap remove --purge pycharm-professional
```

### Mettre à jour les paquets installés sur la VM

```sh
sudo apt-get update
sudo apt-get upgrade
```

### Suppression du Java Development Kit v16 et installation de la version v17

```sh
sudo apt-get purge openjdk-16-jre
sudo apt-get purge openjdk-16-jdk

sudo apt-get install openjdk-17-jdk
```

### Suppression des paquets "temporaires" et "archivés"

```sh
sudo apt-get clean
sudo apt-get autoremove
```


### Installation de l'extension "Java Extension Pack" pour Visual Studio Code

Pour l'ensemble du module, nous utiliserons l'environnement de développement intégré Visual Studio Code (https://code.visualstudio.com/) ainsi que l'extension "Java Extension Pack" (https://marketplace.visualstudio.com/items?itemName=vscjava.vscode-java-pack).


Dans un terminal, vous devez exécuter la commande suivante :
```sh
code --install-extension vscjava.vscode-java-pack
```


<!-- Lors de l'installation, veillez à cocher l'option (surtout vrai pour l'installation sous Windows) pour ajouter le répertoire d'installation (`/bin` pour être plus précis) à votre variable d'environnement `PATH`. Ce n'est pas obligatoire, mais cela simplifiera l'utilisation en ligne de commande.

Une fois l'installation du JDK réalisée, vous devrez configurer son utilisation dans Visual Studio Code. Pour cela, il vous suffit d'exécuter la commande `"Java: Configure Java Runtime"` (pour exécuter une commande sous VisualStudio Code, il faut utiliser la palette de commande -- Menu `"View"` -> `"Item Commande Palette..."` -- ou `CTRL+SHIFT+P` sous Windows ou `COMMANDE+SHIFT+P` sous MacOS). L'onglet `"Java Tooling Runtime"` vous permet de sélectionner l'un des JDK installé sur votre système. -->


## Seconde Partie : Les premiers pas


### Pré-requis

Pour l'ensemble du module, nous utiliserons l'environnement de développement intégré Visual Studio Code (https://code.visualstudio.com/) ainsi que l'extension "Java Extension Pack" (https://marketplace.visualstudio.com/items?itemName=vscjava.vscode-java-pack). Ceux-ci sont normalement déjà installés dans la machine virtuelle si vous avez suivi les instructions précédentes.

Sinon, vous devrez :

- Téléchargez et installez celui-ci si ce n'est pas déjà fait (https://code.visualstudio.com/).
- Installez l'extension "Java Extension Pack" (https://marketplace.visualstudio.com/items?itemName=vscjava.vscode-java-pack)

Vous installerez également un kit de développement Java (Java Development Kit - https://adoptium.net/). Nous vous invitons **fortement** à télécharger la version 17 (LTS -- Long Term Support). 


Vous devez maintenant, si ce n'est pas déjà fait, cloner le dépôt du TP, vous placer dans le répertoire ainsi créer et ouvrir ce répertoire dans Visual Studio Code 
```sh
# en SSH
git clone git@gitlab.telecomnancy.univ-lorraine.fr:oop2k22/lab1-oster7.git
# ou en HTTPS
git clone https://gerald.oster%40telecomnancy.eu@gitlab.telecomnancy.univ-lorraine.fr/oop2k22/lab1-oster7.git

cd lab1-oster7.git
code .
```

**C'est parti !**



### Hello World !

1. Dans un fichier `src/HelloWorld.java` écrivez un programme permettant d'afficher le message `Hello, World!` sur la sortie standard.

2. Placez vous dans le répertoire `src/`, compilez ce programme (en utilisant la commande `javac` adéquate).

3. Regardez ce que le compilateur a produit comme fichier(s) (en utilisant la commande `ls`).

4. Exécutez ce programme (en utilisant la commande `java` adéquate) depuis le répertoire `src/` puis essayez depuis le répertoire parent (la répertoire racine de votre dépôt donc).


5. Dans un fichier `src/HelloWorldArray.java` modifiez votre programme pour qu'il affiche sur la sortie standard le contenu d'une variable locale de type tableau de caractères contenant `['H', 'e', 'l', 'l', 'o', ',', ' ', 'W', 'o', 'r', 'l', 'd', '!']` en effectuant une itération (une boucle).


### Ave Caesar Morituri te Salutant 


#### Introduction

Nous nous intéressons à la conception et à la réalisation d'un *code à cran* (dit code de César). Ce code fonctionne par décalage circulaire. Chaque lettre du message clair est remplacée par la lettre apparaissant *n* crans plus loin dans l'alphabet, et ce, de façon cyclique : `'T'` décalée de 5 crans devient `'Y'`.

Pour plus de détails, vous pouvez consulter la page Wikipédia dédiée au chiffrement par décalage (https://fr.wikipedia.org/wiki/Chiffrement_par_d%C3%A9calage).

Dans la suite, vous considérerez que l'alphabet utilisé est constitué : des 26 lettres minuscules suivis des 26 lettres majuscules, suivis des 10 chiffres dans l'ordre croissant, suivis du caractère espace, du caractère virgule et du caractère point pour terminé.

#### Travail à réaliser

1. Dans un fichier `src/CaesarCode.java`, écrivez un programme permettant de chiffrer le message `'Too Many Secrets'` avec le code de César (décalage à gauche de 3). Votre programme affichera le message chiffré sur la sortie standard.

   Vous aurez besoin de définir :
   - une variable de type tableau de caractères contenant l'alphabet
   - une variable de type tableau de caractères contenant le message clair à chiffrer
   - une variable de type tableau de caractères contenant le message chiffré

2. Dans un fichier `src/ShiftCipher.java`, modifiez le programme précédent pour pouvoir paramètrer le décalage de chiffrement (décalage à gauche ou à droite, valeur du décalage). Ce paramètre sera donné sur la ligne de commande au moment de l'exécution de votre programme.


### Breaking the code!

Dans la suite, vous allez chercher à décrypter un contenu chiffré. 

#### BruteForce - attaque par recherche de la valeur de décalage

Puisque le nombre de décalage est limité, il est facile d'énumérer tous les chiffrements (et donc déchiffrement possibles).

3. Dans un fichier `src/BruteForce.java` écrivez un programme permettant de calculer et d'afficher tous les déchiffrements possibles du message chiffré suivant : 
   
   `bGUUzYKVJzVJGzDGUVAz5KGzNKMGzVJGzTGUVA`
   
    Pour chaque déchiffrement affiché vous préciserez le décalage utilisé **pour le chiffrement initial**.

   Ainsi, l'affichage produit sera de la forme :
   ```
   [64]: cHVVAZLWKAWKHAEHVWBA6LHAOLNHAWKHAUHVWB
   [63]: dIWWB0MXLBXLIBFIWXCB7MIBPMOIBXLIBVIWXC
   [62]: eJXXC1NYMCYMJCGJXYDC8NJCQNPJCYMJCWJXYD
   [61]: fKYYD2OZNDZNKDHKYZED9OKDROQKDZNKDXKYZE
   ...
   [1]: aFTTyXJUIyUIFyCFTUzy4JFyMJLFyUIFySFTUz
   ```


#### Analyse fréquentielle (simplifiée)

Comme le chiffrement utilisé consiste en un simple décalage, il est possible d'examiner la fréquence des lettres employées dans un message chiffré et de faire correspondre cette fréquence avec celle des lettres de l'alphabet dans une langue donnée. Par exemple, en français la lettre `'e'` est la plus utilisée, suivie de la lettre `'a'` et de la lettre `'s'`. 


4. Dans un fichier `src/FrequencyComputation.java` écrivez un programme qui calcule la fréquence d'apparition de chaque caractères contenu dans le fichier de données `data/sometext.txt`.
    1. Dans un premiers temps, essayez de lire et de ré-afficher le contenu du fichier. 
    2. Puis ensuite, calculer le nombre d'occurence de chaque lettre de votre alphabet dans le texte.
    3. Enfin, calculer la fréquence et afficher les résultats sous la forme (les valeurs présentées ci-dessous ne correspondent pas aux valeurs attendues):
    
    ```
    a:0.05179282868525897
    b:0.009391007398975526
    c:0.018497438816163916
    ...
    ```
5. Une fois que vous avez déterminé la lettre dont la fréquence est la plus élevée, utilisez cette information pour déchiffrer le fichier. Dans un fichier `src/BreakTheCode.java`, combinez vos différents codes sources pour déchiffrer les fichiers `data/manifesto.bin`, `data/manifesto-v2.bin` et `data/yumyum.bin`. Normalement, les lettres `'e'`, `'t'`, `'a'`, `'o'` sont les plus courantes dans la langue anglaise. Toutefois, ici le caractère espace a été chiffré et il est présent bien plus souvent.


##### Un peu de code pour aider...

Pour lire le contenu d'un fichier texte brute et remplir un tableau de caractères à 2 dimensions, vous pouvez utiliser le code suivant (à ajouter dans votre programme) :
```java
public static char[][] readTextFile(String filename) {
    char[][] text = null;

    try {
        Scanner sc = new Scanner(new File(filename));

        List<char[]> lines = new ArrayList<char[]>();
        while (sc.hasNextLine()) {
            lines.add(sc.nextLine().toCharArray());
        }
        sc.close();

        text = new char[lines.size()][];
        int lineCount = 0;
        for (char[] l : lines) {
            text[lineCount++] = l;
        }
    } catch (FileNotFoundException e) {
        e.printStackTrace();
    }

    return text;
}
```

Il est également nécessaire d'ajouter les lignes suivantes au début de votre fichier source :
```java
import java.util.List;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
```

Vous pouvez ensuite, utiliser la *méthode de classe* ainsi définie en utilisant l'instruction :
```java
char[][] someText = readTextFile("../data/sometext.txt");
```


## Troisième Partie : Les premiers objets


### Carte CRC (Class, Responsibilities, Collaborators)

Au cours de cette séance, vous allez concevoir vos premières classes. Afin de vous aider dans le processus de réflexion et son résultat, vous allez utiliser un outil : les cartes CRC (*Class*, *Responsibilities*, *Collaborators*)[Beck89].

Ces petites cartes permettent de décrire chaque famille d'objets (chaque classe donc) en faisant abstraction de leur implémentation (du langage qui sera utilisé, de la syntaxe du langage, du choix de l'implémentation de certaines structures de données, etc.).

Une carte CRC est constituée de 3 parties :

- **Un nom de classe :** Ce nom permet de créer un vocabulaire entre les différents acteurs de la conception d'une application. Il est donc important de trouver un nom qui décrit bien la classe. Ce nom doit être le plus évocateur possible, car il a vocation à être utilisé dans un contexte de conception plus large.

- **Des responsabilités :** Celles-ci identifient les problèmes qui doivent être résolus par la classe. Une manière de définir les responsabilités d’un objet consiste à déterminer ce que l'objet doit *savoir* et ce qu'il doit *faire*.

  Les responsabilités qui répondent à *que doit savoir cet objet ?* incluent notamment : 
  - les valeurs que cet objet doit conserver (les attributs ou membres de classe) ;

  Les responsabilités qui répondent à *que doit faire cet objet ?* incluent notamment :
  - effectuer un calcul particulier ;
  - modifier son état interne d'une certaine façon ;
  - créer et initialiser d'autres objets ;
  - contrôler et coordonner les activités d’autres objets.

- **Des collaborateurs :** Ce sont les noms des classes avec lesquelles la classe, décrite la carte décrite, devra collaborer pour assurer ses responsabilités. Autrement dit, les noms des classes auxquelles notre classe enverra des messages (appels de méthodes).


[Benck89] K. Beck and W. Cunningham. A Laboratory for Teaching Object-Oriented Thinking, in Proceedings of OOPSLA’89. pp. 1–6, 1989. ACM Press. DOI:[10.1145/74877.74879](http://doi.acm.org/10.1145/74877.74879) http://c2.com/doc/oopsla89/paper.html   


La figure ci-dessous donne une illustration d'une carte CRC.

![Exemple de carte CRC pour la classe boogle.Dice](./figures/crc-boogle.dice.png "Exemple de carte CRC pour la classe boogle.Dice")


### Domotique et objets connectés : lampes et interrupteurs

L'objectif de ce premier exercice est de concevoir et réaliser les classes de bases d’un programme modélisant un système domotique simplifié reposant sur des lampes et des interrupteurs.

#### La classe `iot.Light`

![Carte CRC de la classe iot.Light](./figures/crc-iot.light.png "Carte CRC de la classe iot.Light")

1. En vous aidant de la carte CRC correspondante, spécifiez l'interface publique d’un objet de classe `iot.Light`. 

2. Spécifiez les profils des constructeurs de la classe `iot.Light`.

3. Implémentez la classe `iot.Light` en écrivant le corps des méthodes de l'interface publique et les constructeurs dans un fichier `src/iot/Light.java`. Le nom complet de la classe est `iot.Light`. Cela signifie que cette classe est contenue dans un paquetage (*package*) dénommé `iot`. C'est pourquoi, le fichier `Light.java` doit se situé dans un sous-répertoire `iot` du répertoire `src` (la racine de votre *classpath*).


#### La classe de test `iot.TestLight` de classe `iot.Light`

Écrivez une classe de test qui teste le comportement obtenu de la classe `iot.Light` et le compare au comportement attendu. Cette classe comportera une méthode de classe `public static void main(String[] args)` afin de pouvoir exécuter les tests.


#### La classe `iot.LightSwitch`

![Carte CRC de la classe iot.LightSwitch](./figures/crc-iot.lightswitch.png "Carte CRC de la classe iot.LightSwitch")

1. En vous aidant de la carte CRC correspondante, spécifiez l'interface publique d’un objet de classe `iot.LightSwitch`. 

2. Spécifiez les profils des constructeurs de la classe `iot.LightSwitch`.

3. Implémentez la classe `iot.LightSwitch` en écrivant le corps des méthodes de l'interface publique et les constructeurs dans un fichier `src/iot/LightSwitch.java`.


#### La classe de test `iot.TestLightSwitch` de classe `iot.LightSwitch`

Écrivez une classe de test qui teste le comportement obtenu de la classe `iot.LightSwitch` et le compare au comportement attendu.


#### Premier schéma mémoire à la main 

Nous nous intéressons maintenant à une représentation graphique simplifiée en mémoire des variables et des objets manipulés par un programme.

On considère que l'on a exécuté le code Java suivant (adapté ce code avec le nom des méthodes que vous avez écrites précédemment) :

```java
Light l = new Light();
LightSwitch s1 = new LightSwitch();
LightSwitch s2 = new LightSwitch();
s1.bind(l);
s2.bind(l);

s1.turnOn();
```

Réalisez un schéma de la mémoire faisant apparaître la pile avec les variables déclarées et le tas avec les objets référencés par les variables. Vous pouvez si vous le souhaitez ajouter une image de ce schéma dans votre dépôt git.


## Quatrième Partie : des objets un peu plus complexes


#### Modification de la classe `iot.LightSwitch`

L'objectif est de modifier la classe `iot.LightSwitch` de manière à pouvoir contrôler plusieurs lampes à partir d'un seul interrupteur.

![Carte CRC de la classe iot.LightSwitch](./figures/crc-iot.lightswitch-modified.png "Carte CRC de la classe iot.LightSwitch")

1. En vous aidant de la carte CRC correspondante et en reprenant la classe `iot.LightSwitch` que vous avez réalisée lors de la précédente séance, spécifiez l'interface publique d’un objet de classe. 

2. Modifiez la classe `iot.LightSwitch` pour allumer et éteindre plusieurs lampes à la fois. Nous allons utiliser une *collection* pour sauvegarder les références des lampes contrôlées par l'interrupteur. Pour ce faire, vous utiliserez la classe `java.util.ArrayList` (veuillez lire la *javadoc* associée).


#### Modification de la classe de test `iot.TestLightSwitch`

Reprenez le code de la classe `iot.TestLightSwitch` que vous avez réalisé lors de la séance précédente et modifiez le afin de tester également les modifications apportées à la classe `iot.LightSwitch`. Bien entendu, vous serez également obligé de reprendre le code de la classe `iot.Light` pour pouvoir compiler et exécuter votre code.


#### Schémas mémoire

1. Quel est l'état de la lampe `l2` après l'exécution du code suivant ? 

```java
Light l1 = new Light();
Light l2 = new Light();
LightSwitch s1 = new LightSwitch();
s1.bind(l1);
s1.bind(l2);
s1.bind(l2);

s1.turnOff();
s1.turnOnOff();
```

2. Vous dessinerez le schéma mémoire correspondant à la main (pile, tas, etc.). Vous pourrez éventuellement vérifiez votre schéma en utilisant la plateforme artEoz. Ajouter une image/photo de votre schéma mémoire sous la forme d'un fichier dans votre dépôt.

3. Que pouvez-vous faire pour éviter le problème identifié à la question précédente ? Modifiez la classe `iot.LightSwitch` en conséquence.


#### La classe `iot.DashBoard`

À l'instar des géants du numérique, nous souhaitons à présent centraliser tous les objets connectés dans un tableau de bord. Les utilisateurs de ce tableau de bord pourront consulter l'état des appareils qu'ils ont enregistrés (connecté, non connecté, allumé, éteint, etc.).

![Carte CRC de la classe iot.DashBoard](./figures/crc-iot.dashboard.png "Carte CRC de la classe iot.DashBoard")

1. En vous aidant de la carte CRC correspondante, spécifiez l'interface publique d'un objet de la classe `iot.DashBoard`.

2. Pour assurer la compatibilité avec la classe `iot.DashBoard`, modifiez les classes `iot.Light` et `iot.LightSwitch` de façon à ce qu'elles renvoient un statut (i.e. *une chaîne de caractères renseignant sur l'état de la lampe, respectivement l'état de l'interrupteur -- connecté à quelles lampes, allumé ou éteint --*). Vous vous appuierez vous sur le concept de *délégation*.

3. Implémentez la classe `iot.DashBoard` en écrivant le corps des méthodes de l'interface publique que vous avez spécifiez. De la même manière que pour la classe `iot.LightSwitch`, nous vous demandons d'utiliser la classe `java.util.ArrayList` pour sauvegarder les références des lampes et des interrupteurs.

#### La classe de test `iot.TestDashBoard`

Écrivez une classe de test `iot.TestDashBoard` démontrant le bon fonctionnement de votre code.


#### La classe `iot.Room`

La compétition est rude et pour résister face à la concurrence sur le marché des objets connectés, nous souhaitons ajouter une nouvelle fonctionnalité à notre tableau de board pour le rendre plus modulaire. Nous souhaitons offrir à nos utilisateurs la possibilité d'enregistrer des pièces (chambre, salle de bain, cuisine, etc.) dans lesquelles seront installées les lampes. Ainsi, l'utilisateur pourra directement demander à sa tableau de bord d'allumer toutes les lampes d'une pièce.

Avec un peu de reconnaissance vocale (hors sujet), nous pourrions arriver à un résultat du genre : *"Ok g**gle! Peux-tu allumer la lumière dans le salon ?"*.

Dans un premier temps, nous allons définir ce qu'est une pièce. Pour simplifier, un objet de type pièce doit comporter un nom la désignant ("cuisine", "salle de bain", etc.) et une liste de lampes installées dans cette pièce. D'une manière plus formelle, nous définissons le comportement de la classe `iot.Room` par la classe CRC suivante :

![Carte CRC de la classe iot.Room](./figures/crc-iot.room.png "Carte CRC de la classe iot.Room")

1. En vous aidant de la carte CRC correspondante, spécifiez l'interface publique d'un objet de la classe `iot.Room`.

2. Implémentez la classe `iot.Room` en écrivant le corps des méthodes de l'interface publique que vous avez spécifiez. De la même manière que pour la classe `iot.DashBoard`, nous vous demandons d'utiliser la classe `java.util.ArrayList` pour sauvegarder les références des lampes installées.


#### Les classes `iot.HomeDashBoard` et `iot.TestHomeDashBoard`

Nous souhaitons créez un nouveau tableau de bord (`iot.HomeDashBoard`) en modifiant le code de la classe `iot.DashBoard` de manière à ce qu'elle prenne en charge les pièces et la localisation des lampes. In fine, nous voulons que l'utilisateur gère les pièces et l'installation des lampes uniquement à travers le tableau de bord. Par l'intermédiaire du tableau de board, l'utilisateur devra également pouvoir allumer ou éteindre toutes les lampes d'une pièce en la désignant par son nom.

![Carte CRC de la classe iot.HomeDashBoard](./figures/crc-iot.homedashboard.png "Carte CRC de la classe iot.HomeDashBoard")

1. Écrivez la classe `iot.HomeDashBoard` pour gérer les pièces en accord avec la carte CRC correspondante. Les références des pièces seront sauvegardées dans des collections de type `java.util.HashMap`. Cette collection diffère un peu des collections de type `java.util.ArrayList`. C'est un tableau associatif qui à une clé donnée associe l'objet correspondant (veuillez lire la *javadoc* associée). Nous vous demandons d'utiliser comme clé, le nom de la pièce associée.

2. Écrivez une classe `iot.TestHomeDashBoard` permettant de démontrer le comportement de classe `iot.HomeDashBoard`.


#### Les classes `iot.Color` et `iot.ColoredLight`

Le marché des lampes connectées s'est beaucoup diversifié ces dernières années. Nous souhaitons pouvoir connecter d'autres types de lampes, en particulier les lampes dont la couleur est ajustable.

![Carte CRC de la classe iot.Color](./figures/crc-iot.color.png "Carte CRC de la classe iot.Color")

![Carte CRC de la classe iot.ColoredLight](./figures/crc-iot.coloredlight.png "Carte CRC de la classe iot.ColoredLight")

1. En vous appuyant sur la carte CRC correspondante, écrivez la classe `iot.Color`.
   
2. En vous appuyant sur la classe `iot.Light` et la classe CRC correspondante, écrivez la classe `iot.ColoredLight`.


#### This is the end...

1. Quelles modifications devraient être apportées dans les autres classes (`iot.LightSwitch`, `iot.HomeDashBoard`, etc.) pour pouvoir utiliser des lampes classiques et des lampes colorées ? 

2. Que serait-il désirable de pouvoir faire pour limiter ces changements ?
