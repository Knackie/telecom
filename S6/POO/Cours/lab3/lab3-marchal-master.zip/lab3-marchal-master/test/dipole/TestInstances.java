package dipole;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class TestInstances {

    @Test
    public void testDipole1() {
        double omega = 314.16 ;
        Dipole dip1 = Instances.dip1();

        Complex expected = new Complex(0.12596948129551394, -3.5322758683317153);
        Complex got = dip1.impedance(omega);
        assertEquals(expected, got);
    }

    @Test
    public void testDipole2() {
        double omega = 314.16 ;
        Dipole dip2 = Instances.dip2();

        Complex expected2 = new Complex(348.3089760187273, -3179.4318300422947);
        Complex got2 = dip2.impedance(omega);
        assertEquals(expected2, got2);
    }
}
