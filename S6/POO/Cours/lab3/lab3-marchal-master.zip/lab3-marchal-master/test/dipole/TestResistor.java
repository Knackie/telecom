package dipole;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class TestResistor {

    @Test
    void testResistor() {
        Resistor r = new Resistor(100.);
        assertEquals(new Complex(100., 0.), r.impedance(314.16));
        assertEquals(new Complex(100., 0.), r.impedance(3.1416));
        assertEquals(new Complex(100., 0.), r.impedance(0.));
    }

}
