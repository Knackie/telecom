package dipole;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class TestNAry {

    @Test
    void testNSerial() {
        Coil c = new Coil(5e-2);
        Resistor r = new Resistor(100.);
        NSerial s = new NSerial();
        s.addDipole(c);
        s.addDipole(r);

        assertEquals(new Complex(100., 15.708), s.impedance(314.16));
        assertEquals(new Complex(100., 0.15708), s.impedance(3.1416));
        assertEquals(new Complex(100., 0.), s.impedance(0.));
    }

    @Test
    void testNParallel() {
        Resistor r = new Resistor(100.);
        Coil c = new Coil(5e-2);
        Capacitor cp = new Capacitor(9e-4);


        NParallel p = new NParallel();
        p.addDipole(r);
        p.addDipole(c);
        p.addDipole(cp);
        
        assertEquals(new Complex(0.20791318, -4.55500719), p.impedance(314.16));
        assertEquals(new Complex(2.469599e-4, 0.15714940), p.impedance(3.1416));
    }

    @Test
    void testNAire() {
        Resistor r = new Resistor(1e7);
        Capacitor cp = new Capacitor(1e-6);

        Resistor r2 = new Resistor(100);
        Coil c = new Coil(2e-1);
        NSerial s = new NSerial();
        s.addDipole(r2);
        s.addDipole(c);

        NParallel np = new NParallel();
        np.addDipole(r);
        np.addDipole(cp);
        np.addDipole(s);

        Resistor r3 = new Resistor(1);
        NSerial ns = new NSerial();
        ns.addDipole(r3);
        ns.addDipole(np);

        assertEquals(new Complex(104.9604150, 60.76416082), ns.impedance(314.16));
        assertEquals(new Complex(100.99938495, 0.59689311), ns.impedance(3.1416));
    }

}
