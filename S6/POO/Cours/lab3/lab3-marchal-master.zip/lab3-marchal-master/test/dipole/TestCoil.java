package dipole;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class TestCoil {

    @Test
    void testCoil() {
        Coil c = new Coil(7e-2);
        assertEquals(new Complex(0., 21.9912), c.impedance(314.16));
        assertEquals(new Complex(0., 0.219912), c.impedance(3.1416));
        assertEquals(new Complex(0., 0.), c.impedance(0.));
    }

}
