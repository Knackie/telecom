package dipole;

public class Capacitor implements Dipole {

    private double c; // Capacité en Farad

    public Capacitor(double c) {
        this.c = c;
    }

    public Complex impedance(double omega) {
        return new Complex(0, -1 / (omega * c));
    }
}