package dipole;

public class Parallel extends Binary {

    public Parallel(Dipole d1, Dipole d2) {
        super(d1, d2);
    }

    @Override
    public Complex impedance(double omega) {
        return d1.impedance(omega).inverse().add(d2.impedance(omega).inverse()).inverse();
    }


}
