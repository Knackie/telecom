package dipole;

public class Instances {
	
	public static Dipole dip1() {
		Resistor r1 = new Resistor(1e2);
		Resistor r2 = new Resistor(10e3);
		Coil co = new Coil(5e-5);
		Capacitor ca = new Capacitor(0e-4);

		Serial s = new Serial(co,r2);
		NParallel p = new NParallel();
		p.addDipole(r1);
		p.addDipole(s);
		p.addDipole(ca);

		return p;
	}

	public static Dipole dip2() {
		Resistor r1 = new Resistor(100);
		Resistor r2 = new Resistor(1e3);
		Resistor r3 = new Resistor(1000);
		Resistor r4 = new Resistor(330);

		Coil co1 = new Coil(5e-2);
		Coil co2 = new Coil(2e-1);

		Capacitor ca1 = new Capacitor(9e-3);
		Capacitor ca2 = new Capacitor(9e-4);
		Capacitor ca3 = new Capacitor(1e-5);
		Capacitor ca4 = new Capacitor(1e-6);

		Serial s1 = new Serial(r2,co1);
		Serial s2 = new Serial(ca2,ca3);
		Serial s3 = new Serial(r3,co2);

		NParallel p1 = new NParallel();
		p1.addDipole(s1);
		p1.addDipole(ca1);
		p1.addDipole(s2);

		Serial s4 = new Serial(p1,r4);

		Parallel p2 = new Parallel(s4,s3);

		NSerial s5 = new NSerial();
		s5.addDipole(r1);
		s5.addDipole(p2);
		s5.addDipole(ca4);

		return s5;
	}
}