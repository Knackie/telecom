package dipole;

public class NParallel extends NAry {

    public NParallel() {
    }

    @Override
    public Complex impedance(double omega) {
        Complex imp = new Complex();
        for (int i = 0; i < dipoles.size(); i++) {
            imp.add(dipoles.get(i).impedance(omega).inverse());
        }
        return imp.inverse();
    }
}
