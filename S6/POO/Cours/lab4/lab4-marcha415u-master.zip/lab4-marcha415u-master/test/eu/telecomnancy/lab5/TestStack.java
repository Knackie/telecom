package eu.telecomnancy.lab5;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.NoSuchElementException;

public class TestStack {
	Stack<String> fa0, fa1, fa2;

	@BeforeEach
	public void setUp() throws Exception {
		fa0 = new Stack<String>();

		fa1 = new Stack<String>();
		fa1.push("plop");

		fa2 = new Stack<String>();
		fa2.push("a");
		fa2.push("b");
	}

	@Test
	public void testIsEmpty() {
		assertTrue(fa0.isEmpty());
		assertFalse(fa1.isEmpty());
	}

	@Test
	public void testPush() {
		assertTrue(fa0.isEmpty());
		fa0.push("toto");
		assertFalse(fa0.isEmpty());
	}

	@Test
	public void testPop() {
		assertThrows(NoSuchElementException.class, () -> {
			fa0.pop();
		});

		assertEquals("plop", fa1.pop());
		assertTrue(fa1.isEmpty());
		assertEquals("b", fa2.pop());
		assertEquals("a", fa2.pop());
		assertTrue(fa2.isEmpty());
	}

	@Test
	public void testPushPop() {
		assertTrue(fa0.isEmpty());
		fa0.push("a");
		fa0.push("b");
		assertEquals("b", fa0.pop());
		fa0.push("b");
		fa0.push("c");
		assertEquals("c", fa0.pop());
		assertEquals("b", fa0.pop());
		assertEquals("a", fa0.pop());
		assertTrue(fa0.isEmpty());
	}

	@Test
	public void testSize() {
		assertEquals(0,fa0.size());
		assertEquals(1,fa1.size());
		assertEquals(2,fa2.size());
	}

	@Test
	public void testPeek() {
		assertEquals("plop",fa1.peek());
		assertEquals("b",fa2.peek());
	}
}
