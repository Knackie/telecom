package eu.telecomnancy.lab5;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.NoSuchElementException;

public class TestDeque {
    Deque<String> fa0, fa1, fa2, fa3;

    @BeforeEach
    public void setUp() throws Exception {
        fa0 = new Deque<String>();

        fa1 = new Deque<String>();
        fa1.pushBack("plop");

        fa2 = new Deque<String>();
        fa2.pushBack("a");
        fa2.pushBack("b");

        fa3 = new Deque<String>();
        fa3.pushFront("a");
        fa3.pushFront("b");
    }

    @Test
    public void testIsEmpty() {
        assertTrue(fa0.isEmpty());
        assertFalse(fa1.isEmpty());
    }

    @Test
    public void testPushBack() {
        assertTrue(fa0.isEmpty());
        fa0.pushBack("toto");
        assertFalse(fa0.isEmpty());
    }

    @Test
    public void testPushFront() {
        assertTrue(fa0.isEmpty());
        fa0.pushFront("toto");
        assertFalse(fa0.isEmpty());
    }

    @Test
    public void testPopBack() {
        assertThrows(NoSuchElementException.class, () -> {
            fa0.popBack();
        });

        assertEquals("plop", fa1.popBack());
        assertTrue(fa1.isEmpty());
        assertEquals("b", fa2.popBack());
        assertEquals("a", fa2.popBack());
        assertTrue(fa2.isEmpty());
        assertEquals("a", fa3.popBack());
        assertEquals("b", fa3.popBack());
        assertTrue(fa3.isEmpty());
    }

    @Test
    public void testPopFront() {
        assertThrows(NoSuchElementException.class, () -> {
            fa0.popFront();
        });

        assertEquals("plop", fa1.popFront());
        assertTrue(fa1.isEmpty());
        assertEquals("a", fa2.popFront());
        assertEquals("b", fa2.popFront());
        assertTrue(fa2.isEmpty());
        assertEquals("b", fa3.popFront());
        assertEquals("a", fa3.popFront());
        assertTrue(fa3.isEmpty());
    }

    @Test
    public void testPushPopBack() {
        assertTrue(fa0.isEmpty());
        fa0.pushBack("a");
        fa0.pushBack("b");
        assertEquals("b", fa0.popBack());
        fa0.pushBack("b");
        fa0.pushBack("c");
        assertEquals("c", fa0.popBack());
        assertEquals("b", fa0.popBack());
        assertEquals("a", fa0.popBack());
        assertTrue(fa0.isEmpty());
    }

    @Test
    public void testPushPopFront() {
        assertTrue(fa0.isEmpty());
        fa0.pushFront("a");
        fa0.pushFront("b");
        assertEquals("b", fa0.popFront());
        fa0.pushFront("b");
        fa0.pushFront("c");
        assertEquals("c", fa0.popFront());
        assertEquals("b", fa0.popFront());
        assertEquals("a", fa0.popFront());
        assertTrue(fa0.isEmpty());
    }

    @Test
    public void testSize() {
        assertEquals(0,fa0.size());
        assertEquals(1,fa1.size());
        assertEquals(2,fa2.size());
        assertEquals(2,fa3.size());
    }

    @Test
    public void testPeekBack() {
        assertEquals("plop",fa1.peekBack());
        assertEquals("b",fa2.peekBack());
        assertEquals("a",fa3.peekBack());
    }

    @Test
    public void testPeekFront() {
        assertEquals("plop",fa1.peekFront());
        assertEquals("a",fa2.peekFront());
        assertEquals("b",fa3.peekFront());
    }
}
