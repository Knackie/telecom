package eu.telecomnancy.lab5.reImplementation;

import java.util.NoSuchElementException;

public class Stack<E> {
    private Element<E> list;

    public boolean isEmpty() {
        return list == null;
    }

    public void push(E tete) {
        if (list == null) list = new Element<E>(tete);
        else list = new Element<E>(tete,list);
    }

    public E pop() throws NoSuchElementException {
        if (isEmpty()) throw new NoSuchElementException();
        else {
            E old = list.getTete();
            list = list.getQueue();
            return old;
        }
    }

    public int size() {
        if (list == null) return 0;
        else {
            int size = 0;
            Element<E> tmp = list;
            while (tmp != null) {
                tmp = tmp.getQueue();
                size++;
            }
            return size;
        }
    }

    public E peek() throws NoSuchElementException {
        if (isEmpty()) throw new NoSuchElementException();
        else return list.getTete();
    }
}
