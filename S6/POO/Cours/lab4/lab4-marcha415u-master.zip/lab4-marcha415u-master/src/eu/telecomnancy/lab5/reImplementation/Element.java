package eu.telecomnancy.lab5.reImplementation;

public class Element<E> {
    private E tete;
    private Element queue;

    public Element(E tete) {
        this.tete = tete;
        this.queue = null;
    }

    public Element(E tete, Element queue) {
        this.tete = tete;
        this.queue = queue;
    }

    public E getTete() {
        return tete;
    }

    public Element<E> getQueue() {
        return queue;
    }

    public void setTete(E tete) {
        this.tete = tete;
    }

    public void setQueue(Element queue) {
        this.queue = queue;
    }
}
