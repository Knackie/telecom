package eu.telecomnancy.lab5;

import java.util.ArrayList;
import java.util.NoSuchElementException;

public class Queue<E> {
    private ArrayList<E> list = new ArrayList<E>();

    public boolean isEmpty() {
        return list.isEmpty();
    }

    public void push(E elem) {
        if (elem != null) list.add(0,elem);
    }

    public E pop() throws NoSuchElementException {
        if (list.isEmpty()) throw new NoSuchElementException();
        else return list.remove(list.size() - 1);
    }

    public int size() {
        return list.size();
    }

    public E peek() {
        return list.get(list.size() - 1);
    }
}
