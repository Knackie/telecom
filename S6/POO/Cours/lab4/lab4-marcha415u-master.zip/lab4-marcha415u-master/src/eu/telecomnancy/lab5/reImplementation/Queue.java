package eu.telecomnancy.lab5.reImplementation;

import java.util.NoSuchElementException;

public class Queue<E> {
    private Element<E> list;

    public boolean isEmpty() {
        return list == null;
    }

    public void push(E tete) {
        list = push(tete, list);
    }

    private Element<E> push(E tete, Element<E> queue) {
        if (queue == null) return queue = new Element<E>(tete);
        else return new Element<E>(queue.getTete(), push(tete, queue.getQueue()));
    }

    public E pop() throws NoSuchElementException {
        if (isEmpty()) throw new NoSuchElementException();
        else {
            E old = list.getTete();
            list = list.getQueue();
            return old;
        }
    }

    public int size() {
        if (list == null) return 0;
        else {
            int size = 0;
            Element<E> tmp = list;
            while (tmp != null) {
                tmp = tmp.getQueue();
                size++;
            }
            return size;
        }
    }

    public E peek() throws NoSuchElementException {
        if (isEmpty()) throw new NoSuchElementException();
        else return list.getTete();
    }
}
