package eu.telecomnancy.lab5;

import java.util.ArrayList;
import java.util.NoSuchElementException;

public class Deque<E> {
    private ArrayList<E> list = new ArrayList<E>();

    public boolean isEmpty() {
        return list.isEmpty();
    }

    public void pushFront(E elem) {
        if (elem != null) list.add(0,elem);
    }

    public void pushBack(E elem) {
        if (elem != null) list.add(elem);
    }

    public E popBack() throws NoSuchElementException {
        if (list.isEmpty()) throw new NoSuchElementException();
        else return list.remove(list.size() - 1);
    }

    public E popFront() throws NoSuchElementException {
        if (list.isEmpty()) throw new NoSuchElementException();
        else return list.remove(0);
    }

    public int size() {
        return list.size();
    }

    public E peekFront() {
        return list.get(0);
    }

    public E peekBack() {
        return list.get(list.size() - 1);
    }
}
