package eu.telecomnancy.lab5.reImplementation;

import java.util.NoSuchElementException;

public class Deque<E> {
    private Element<E> list;

    public boolean isEmpty() {
        return list == null;
    }

    public void pushBack(E tete) {
        list = pushBack(tete, list);
    }

    private Element<E> pushBack(E tete, Element<E> queue) {
        if (queue == null) return queue = new Element<E>(tete);
        else return new Element<E>(queue.getTete(), pushBack(tete, queue.getQueue()));
    }

    public void pushFront(E tete) {
        if (list == null) list = new Element<E>(tete);
        else list = new Element<E>(tete, list);
    }

    public E popFront() throws NoSuchElementException {
        if (isEmpty()) throw new NoSuchElementException();
        else {
            E old = list.getTete();
            list = list.getQueue();
            return old;
        }
    }

    public E popBack() throws NoSuchElementException {
        if (isEmpty()) throw new NoSuchElementException();
        else {
            E old = peekBack();
            list = popBack(list);
            return old;
        }
    }

    private Element<E> popBack(Element<E> queue) {
        if (queue.getQueue() == null)  return null;
        else return new Element<E>(queue.getTete(), popBack(queue.getQueue()));
    }

    public E peekFront() throws NoSuchElementException {
        if (isEmpty()) throw new NoSuchElementException();
        else return list.getTete();
    }

    public E peekBack() throws NoSuchElementException {
        if (isEmpty()) throw new NoSuchElementException();
        else return peekBack(list);
    }

    private E peekBack(Element<E> queue) {
        if (queue.getQueue() == null) return queue.getTete();
        else return peekBack(queue.getQueue());
    }

    public int size() {
        if (list == null) return 0;
        else {
            int size = 0;
            Element<E> tmp = list;
            while (tmp != null) {
                tmp = tmp.getQueue();
                size++;
            }
            return size;
        }
    }
}
