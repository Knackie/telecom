#! /usr/local/bin/python3

# ne pas oublier d'installer jinja2
# python3 -m venv .venv
# source .venv/bin/activate
# pip install jinja2
import os
import argparse
from jinja2 import Template

def human_readable_size(nbytes):
    suffixes = ['o', 'Ko', 'Mo', 'Go', 'To', 'PB']
    i = 0
    while nbytes >= 1000 and i < len(suffixes)-1:
        nbytes /= 1000.
        i += 1
    size = f"{nbytes:.2f}".rstrip('0').rstrip('.')
    return f"{size} {suffixes[i]}"

def extract_mime_type(file):
    result = {}
    with open(file, 'r') as f:
        for line in f:
            if line.strip():
                if line.startswith("#"):
                    continue
                spl = line.split()
                mime = spl[0]
                extensions = spl[1:]
                for ext in extensions:
                    result[ext] = mime
    return result


def print_files(folder_path, mimefile):
    mimetype_dict = extract_mime_type(args.mimefile)
    files = []
    for dirpath, dirnames, filenames in os.walk(args.folder_path):
        for filename in filenames:
            filename_path = os.path.join(dirpath, filename)
            filename_size = os.path.getsize(filename_path)
            _, filename_extension = os.path.splitext(filename) 
            filemane_mime = mimetype_dict.get(filename_extension.lower()[1:], "unknown")
            files.append(f"{filename_path} -- {human_readable_size(filename_size)} -- {filemane_mime}")

    template = Template(open('template.j2').read())
    template.stream(files=files).dump('result.html')
  
if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--folder_path', type=str, default='.')
    parser.add_argument('--mimefile', type=str, default="mime.types.txt", help='the name of the mime file')
    args = parser.parse_args()
    print_files(args.folder_path, args.mimefile)
