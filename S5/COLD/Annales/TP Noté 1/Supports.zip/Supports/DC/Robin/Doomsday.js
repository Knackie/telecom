Kingdom Come 53
For The Man Who Has Everything 52
For The Man Who Has Everything 92
The New Frontier 96
The Killing Joke 51
The Dark Knight Returns 14
The New Frontier 69
For The Man Who Has Everything 24
Kingdom Come 90
Identity Crisis 94
Arkham Asylum: A Serious House On Serious Earth 6
Superman For All Seasons 96
For The Man Who Has Everything 29
Swamp Thing: The Anatomy Lesson 18
Doom Patrol 18
The New Frontier 70
Doom Patrol 32
Batman: The Long Halloween 3
Doom Patrol 55
Kingdom Come 81
The Dark Knight Returns 88
For The Man Who Has Everything 93
Jack Kirby's New Gods 53
Swamp Thing: The Anatomy Lesson 98
The Dark Knight Returns 20
Jack Kirby's New Gods 9
Identity Crisis 40
The Dark Knight Returns 65
Green Arrow: The Longbow Hunters 86
Crisis On Infinite Earths 1
The Sinestro Corps War 61
JLA: Tower Of Babel 2
Superman: Red Son 87
Crisis On Infinite Earths 3
Swamp Thing: The Anatomy Lesson 70
Kingdom Come 69
Whatever Happened To The Man Of Tomorrow? 64
Arkham Asylum: A Serious House On Serious Earth 8
The Killing Joke 9
Multiversity 31
For The Man Who Has Everything 98
Batman: The Long Halloween 58
The Killing Joke 3
JLA: Earth 2 20
Arkham Asylum: A Serious House On Serious Earth 87
The Dark Knight Returns 34
The New Frontier 71
Identity Crisis 32
Grant Morrison's Animal Man 34
Superman: Red Son 72
Multiversity 49
Superman For All Seasons 58
The Dark Knight Returns 20
Grant Morrison's Animal Man 7
Action Comics 68
Detective Comics 58
Grant Morrison's Animal Man 24
Superman For All Seasons 30
Swamp Thing: The Anatomy Lesson 89
The Coyote Gospel 23
Identity Crisis 64
The Coyote Gospel 4
The Killing Joke 95
Green Arrow: The Longbow Hunters 40
All Star Superman 1
Gotham Central 27
The Coyote Gospel 12
Kingdom Come 59
Gotham Central 75
Snowbirds Don't Fly 14
Grant Morrison's Animal Man 9
Arkham Asylum: A Serious House On Serious Earth 54
The New Frontier 37
Detective Comics 38
Arkham Asylum: A Serious House On Serious Earth 61
Arkham Asylum: A Serious House On Serious Earth 93
The Coyote Gospel 99
Swamp Thing: The Anatomy Lesson 90
JLA: Earth 2 59
Crisis On Infinite Earths 83
Superman For All Seasons 81
The New Frontier 58
JLA: Tower Of Babel 7
Identity Crisis 77
Grant Morrison's Animal Man 62
Superman: Red Son 24
Swamp Thing: The Anatomy Lesson 82
Whatever Happened To The Man Of Tomorrow? 68
Detective Comics 89
Snowbirds Don't Fly 61
