Green Arrow: The Longbow Hunters 50
The Coyote Gospel 71
Teen Titans: The Judas Contract 50
For The Man Who Has Everything 52
JLA: Earth 2 49
Superman: Red Son 63
Doom Patrol 76
Snowbirds Don't Fly 56
Green Arrow: The Longbow Hunters 87
Swamp Thing: The Anatomy Lesson 97
Action Comics 13
The Dark Knight Returns 27
Kingdom Come 25
Crisis On Infinite Earths 3
Batman: Year One 2
All Star Superman 72
Whatever Happened To The Man Of Tomorrow? 55
Batman: The Long Halloween 38
Batman: Year One 87
The Coyote Gospel 25
Detective Comics 64
Snowbirds Don't Fly 2
The Coyote Gospel 37
Snowbirds Don't Fly 4
The Coyote Gospel 39
