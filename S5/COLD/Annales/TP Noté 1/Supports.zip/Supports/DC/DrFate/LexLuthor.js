The Coyote Gospel 74
Arkham Asylum: A Serious House On Serious Earth 1
The Killing Joke 57
Superman For All Seasons 10
The Coyote Gospel 68
Crisis On Infinite Earths 23
Action Comics 17
Action Comics 81
The Coyote Gospel 33
Batman: Year One 91
Teen Titans: The Judas Contract 26
Crisis On Infinite Earths 79
Superman: Red Son 46
Teen Titans: The Judas Contract 95
Detective Comics 52
Detective Comics 67
Batman: Year One 51
Grant Morrison's Animal Man 36
The New Frontier 12
Arkham Asylum: A Serious House On Serious Earth 95
The Killing Joke 97
Superman For All Seasons 60
The Dark Knight Returns 71
Grant Morrison's Animal Man 43
JLA: Tower Of Babel 63
Green Arrow: The Longbow Hunters 10
The Sinestro Corps War 70
Action Comics 42
JLA: Earth 2 88
Superman For All Seasons 50
Green Arrow: The Longbow Hunters 86
Action Comics 48
Doom Patrol 33
Batman: Year One 85
JLA: Earth 2 47
Grant Morrison's Animal Man 79
Teen Titans: The Judas Contract 59
Grant Morrison's Animal Man 44
Jack Kirby's New Gods 83
Multiversity 70
Crisis On Infinite Earths 87
The Killing Joke 48
Snowbirds Don't Fly 50
Detective Comics 83
Arkham Asylum: A Serious House On Serious Earth 60
Grant Morrison's Animal Man 33
Green Arrow: The Longbow Hunters 54
Grant Morrison's Animal Man 48
Arkham Asylum: A Serious House On Serious Earth 2
Whatever Happened To The Man Of Tomorrow? 10
Crisis On Infinite Earths 31
The Sinestro Corps War 58
Superman For All Seasons 65
Snowbirds Don't Fly 16
The New Frontier 95
Batman: The Long Halloween 40
Multiversity 86
Crisis On Infinite Earths 39
Grant Morrison's Animal Man 10
All Star Superman 64
Crisis On Infinite Earths 65
The Sinestro Corps War 79
Teen Titans: The Judas Contract 46
Teen Titans: The Judas Contract 95
Snowbirds Don't Fly 95
The Sinestro Corps War 15
Teen Titans: The Judas Contract 63
Swamp Thing: The Anatomy Lesson 2
JLA: Tower Of Babel 27
Grant Morrison's Animal Man 84
JLA: Earth 2 82
Green Arrow: The Longbow Hunters 22
JLA: Tower Of Babel 51
Detective Comics 75
