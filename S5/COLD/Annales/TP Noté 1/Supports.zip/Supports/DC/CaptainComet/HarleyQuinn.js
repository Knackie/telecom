Batman: The Long Halloween 49
Green Arrow: The Longbow Hunters 38
Jack Kirby's New Gods 68
Multiversity 87
Identity Crisis 97
Superman For All Seasons 73
Gotham Central 49
Identity Crisis 73
Green Arrow: The Longbow Hunters 90
The Sinestro Corps War 18
Superman For All Seasons 19
Detective Comics 11
Snowbirds Don't Fly 87
Jack Kirby's New Gods 68
Green Arrow: The Longbow Hunters 9
JLA: Tower Of Babel 42
Swamp Thing: The Anatomy Lesson 99
The Coyote Gospel 54
