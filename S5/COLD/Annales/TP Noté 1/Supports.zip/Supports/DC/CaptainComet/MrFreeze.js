The New Frontier 11
The Dark Knight Returns 44
Gotham Central 68
JLA: Tower Of Babel 42
The Sinestro Corps War 42
Snowbirds Don't Fly 3
Superman: Red Son 86
Crisis On Infinite Earths 92
Whatever Happened To The Man Of Tomorrow? 61
Identity Crisis 20
All Star Superman 62
Detective Comics 73
Gotham Central 99
Swamp Thing: The Anatomy Lesson 84
Teen Titans: The Judas Contract 41
Superman: Red Son 88
The Sinestro Corps War 66
Snowbirds Don't Fly 60
Doom Patrol 39
Jack Kirby's New Gods 50
Crisis On Infinite Earths 84
