Superman: Red Son 52
Whatever Happened To The Man Of Tomorrow? 25
Multiversity 60
Swamp Thing: The Anatomy Lesson 66
Snowbirds Don't Fly 62
Grant Morrison's Animal Man 11
Crisis On Infinite Earths 58
Doom Patrol 10
The Sinestro Corps War 85
Multiversity 36
Grant Morrison's Animal Man 52
JLA: Tower Of Babel 72
Swamp Thing: The Anatomy Lesson 57
The New Frontier 89
Grant Morrison's Animal Man 88
The New Frontier 99
Identity Crisis 79
Whatever Happened To The Man Of Tomorrow? 39
The Killing Joke 76
Snowbirds Don't Fly 79
Kingdom Come 92
Detective Comics 33
The Sinestro Corps War 43
Superman: Red Son 32
Arkham Asylum: A Serious House On Serious Earth 31
JLA: Earth 2 69
Green Arrow: The Longbow Hunters 74
Crisis On Infinite Earths 29
Arkham Asylum: A Serious House On Serious Earth 82
Snowbirds Don't Fly 41
The Killing Joke 18
Snowbirds Don't Fly 39
The New Frontier 28
Kingdom Come 67
Superman: Red Son 26
Whatever Happened To The Man Of Tomorrow? 99
Teen Titans: The Judas Contract 74
Swamp Thing: The Anatomy Lesson 36
Crisis On Infinite Earths 45
Whatever Happened To The Man Of Tomorrow? 91
The Coyote Gospel 48
Grant Morrison's Animal Man 83
Gotham Central 79
Doom Patrol 18
The Killing Joke 82
Jack Kirby's New Gods 86
Snowbirds Don't Fly 68
Superman: Red Son 83
Arkham Asylum: A Serious House On Serious Earth 3
Identity Crisis 28
The Coyote Gospel 38
Action Comics 31
Action Comics 29
The Dark Knight Returns 6
