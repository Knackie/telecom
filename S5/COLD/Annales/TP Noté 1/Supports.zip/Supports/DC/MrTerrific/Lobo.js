Gotham Central 11
Green Arrow: The Longbow Hunters 76
Batman: Year One 67
For The Man Who Has Everything 33
The New Frontier 45
Batman: The Long Halloween 19
Batman: Year One 78
Kingdom Come 28
The Coyote Gospel 66
JLA: Tower Of Babel 8
The Dark Knight Returns 58
Detective Comics 69
Superman: Red Son 65
Superman For All Seasons 85
The Dark Knight Returns 76
The New Frontier 73
JLA: Earth 2 7
Multiversity 23
The Dark Knight Returns 15
Snowbirds Don't Fly 33
Snowbirds Don't Fly 50
Superman For All Seasons 66
The Sinestro Corps War 15
For The Man Who Has Everything 0
The Dark Knight Returns 57
Multiversity 33
Teen Titans: The Judas Contract 84
Action Comics 12
JLA: Tower Of Babel 58
Kingdom Come 51
For The Man Who Has Everything 77
JLA: Tower Of Babel 63
The Killing Joke 14
Superman For All Seasons 26
Green Arrow: The Longbow Hunters 54
For The Man Who Has Everything 59
Teen Titans: The Judas Contract 80
Grant Morrison's Animal Man 69
The Dark Knight Returns 4
Doom Patrol 15
Identity Crisis 89
Grant Morrison's Animal Man 62
Batman: The Long Halloween 0
JLA: Tower Of Babel 52
Green Arrow: The Longbow Hunters 8
JLA: Tower Of Babel 69
The Killing Joke 39
JLA: Earth 2 87
Crisis On Infinite Earths 81
Jack Kirby's New Gods 12
The Dark Knight Returns 83
The Coyote Gospel 5
The Dark Knight Returns 37
Kingdom Come 5
Superman: Red Son 38
The Killing Joke 17
Green Arrow: The Longbow Hunters 1
Identity Crisis 1
The Killing Joke 85
The Coyote Gospel 76
Detective Comics 61
Jack Kirby's New Gods 66
Whatever Happened To The Man Of Tomorrow? 15
Grant Morrison's Animal Man 94
Green Arrow: The Longbow Hunters 45
Jack Kirby's New Gods 49
Kingdom Come 98
The Killing Joke 46
Batman: Year One 7
Teen Titans: The Judas Contract 7
Grant Morrison's Animal Man 18
The New Frontier 56
The Dark Knight Returns 99
The Coyote Gospel 65
Action Comics 4
The Killing Joke 94
Grant Morrison's Animal Man 48
Superman: Red Son 38
For The Man Who Has Everything 32
All Star Superman 76
Snowbirds Don't Fly 47
Teen Titans: The Judas Contract 47
Multiversity 8
Superman For All Seasons 23
Swamp Thing: The Anatomy Lesson 98
Action Comics 66
Identity Crisis 88
Action Comics 75
