Jack Kirby's New Gods 28
The Dark Knight Returns 7
Identity Crisis 2
Gotham Central 82
Jack Kirby's New Gods 93
All Star Superman 49
Grant Morrison's Animal Man 26
All Star Superman 24
Doom Patrol 22
All Star Superman 2
Batman: The Long Halloween 56
Kingdom Come 53
The Dark Knight Returns 88
Identity Crisis 9
Swamp Thing: The Anatomy Lesson 62
The New Frontier 94
JLA: Earth 2 60
Swamp Thing: The Anatomy Lesson 12
Identity Crisis 59
Superman: Red Son 39
Gotham Central 8
Superman For All Seasons 70
Multiversity 37
Snowbirds Don't Fly 54
Grant Morrison's Animal Man 80
Action Comics 90
Jack Kirby's New Gods 88
Superman For All Seasons 42
Arkham Asylum: A Serious House On Serious Earth 39
All Star Superman 28
Multiversity 60
