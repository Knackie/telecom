Batman: Year One 4
Batman: The Long Halloween 29
The Sinestro Corps War 98
Crisis On Infinite Earths 85
Detective Comics 56
All Star Superman 75
Action Comics 69
JLA: Earth 2 33
JLA: Tower Of Babel 83
Arkham Asylum: A Serious House On Serious Earth 97
The New Frontier 74
For The Man Who Has Everything 40
Green Arrow: The Longbow Hunters 92
Gotham Central 78
Identity Crisis 95
Batman: Year One 73
JLA: Tower Of Babel 78
Snowbirds Don't Fly 82
Teen Titans: The Judas Contract 44
Whatever Happened To The Man Of Tomorrow? 46
All Star Superman 43
JLA: Tower Of Babel 84
Detective Comics 80
Crisis On Infinite Earths 91
Superman: Red Son 89
Superman: Red Son 34
Detective Comics 3
Doom Patrol 30
JLA: Earth 2 29
Detective Comics 91
Batman: Year One 4
Batman: Year One 73
Action Comics 62
For The Man Who Has Everything 30
Whatever Happened To The Man Of Tomorrow? 65
Gotham Central 20
Snowbirds Don't Fly 62
The New Frontier 85
Doom Patrol 91
Identity Crisis 29
Identity Crisis 9
Multiversity 82
All Star Superman 94
