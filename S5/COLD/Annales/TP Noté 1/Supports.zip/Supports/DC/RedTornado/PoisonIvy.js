JLA: Tower Of Babel 67
The Dark Knight Returns 4
Multiversity 12
The Dark Knight Returns 38
Kingdom Come 13
Teen Titans: The Judas Contract 69
Superman For All Seasons 37
The Dark Knight Returns 72
For The Man Who Has Everything 74
Doom Patrol 36
Superman: Red Son 65
Multiversity 77
Doom Patrol 0
Identity Crisis 85
Detective Comics 20
Batman: Year One 25
Batman: The Long Halloween 78
The New Frontier 68
JLA: Earth 2 90
Action Comics 85
The Dark Knight Returns 40
Kingdom Come 81
Action Comics 87
JLA: Tower Of Babel 79
Multiversity 86
Multiversity 2
Kingdom Come 50
Batman: Year One 92
The Dark Knight Returns 6
The Coyote Gospel 38
Swamp Thing: The Anatomy Lesson 60
Action Comics 30
The Coyote Gospel 15
For The Man Who Has Everything 96
The Killing Joke 45
The Killing Joke 85
Action Comics 95
Batman: The Long Halloween 71
Identity Crisis 28
Superman: Red Son 14
Green Arrow: The Longbow Hunters 15
Kingdom Come 17
The Dark Knight Returns 31
Superman For All Seasons 61
Multiversity 94
Grant Morrison's Animal Man 92
The Dark Knight Returns 42
Teen Titans: The Judas Contract 86
Kingdom Come 92
Swamp Thing: The Anatomy Lesson 23
Grant Morrison's Animal Man 65
Multiversity 0
Superman For All Seasons 12
Jack Kirby's New Gods 96
Detective Comics 62
Multiversity 21
Multiversity 67
Whatever Happened To The Man Of Tomorrow? 33
Grant Morrison's Animal Man 78
Kingdom Come 57
Detective Comics 91
Detective Comics 71
Crisis On Infinite Earths 87
Action Comics 9
JLA: Tower Of Babel 32
Teen Titans: The Judas Contract 74
Jack Kirby's New Gods 55
JLA: Earth 2 73
Grant Morrison's Animal Man 15
Snowbirds Don't Fly 51
Batman: Year One 26
Green Arrow: The Longbow Hunters 35
Multiversity 5
Crisis On Infinite Earths 86
Jack Kirby's New Gods 35
JLA: Earth 2 57
The Sinestro Corps War 51
Action Comics 46
Superman: Red Son 55
Snowbirds Don't Fly 40
Teen Titans: The Judas Contract 69
Whatever Happened To The Man Of Tomorrow? 26
Doom Patrol 99
Identity Crisis 73
Doom Patrol 81
The Killing Joke 71
Snowbirds Don't Fly 28
Grant Morrison's Animal Man 17
Superman: Red Son 74
Teen Titans: The Judas Contract 74
Batman: The Long Halloween 48
The Sinestro Corps War 4
For The Man Who Has Everything 89
The Coyote Gospel 42
JLA: Tower Of Babel 13
JLA: Tower Of Babel 61
Detective Comics 46
Jack Kirby's New Gods 45
