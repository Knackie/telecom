Green Arrow: The Longbow Hunters 65
Batman: Year One 14
Teen Titans: The Judas Contract 87
Crisis On Infinite Earths 28
Snowbirds Don't Fly 11
Teen Titans: The Judas Contract 82
Batman: Year One 1
All Star Superman 24
Green Arrow: The Longbow Hunters 17
The New Frontier 15
Teen Titans: The Judas Contract 68
Arkham Asylum: A Serious House On Serious Earth 41
Arkham Asylum: A Serious House On Serious Earth 50
Teen Titans: The Judas Contract 31
Green Arrow: The Longbow Hunters 26
For The Man Who Has Everything 67
The Dark Knight Returns 56
The New Frontier 86
Whatever Happened To The Man Of Tomorrow? 98
JLA: Earth 2 90
Superman For All Seasons 21
Multiversity 95
Whatever Happened To The Man Of Tomorrow? 85
Whatever Happened To The Man Of Tomorrow? 37
Snowbirds Don't Fly 47
Jack Kirby's New Gods 81
The New Frontier 93
Identity Crisis 61
Batman: Year One 6
Batman: Year One 93
Doom Patrol 98
Crisis On Infinite Earths 31
The Dark Knight Returns 35
Snowbirds Don't Fly 9
Identity Crisis 0
Action Comics 14
Grant Morrison's Animal Man 7
The Sinestro Corps War 92
JLA: Tower Of Babel 86
JLA: Earth 2 98
JLA: Earth 2 84
The Killing Joke 61
Gotham Central 1
The Sinestro Corps War 55
Kingdom Come 43
The Dark Knight Returns 6
Green Arrow: The Longbow Hunters 61
Batman: Year One 8
Doom Patrol 61
The Sinestro Corps War 39
Superman For All Seasons 92
Arkham Asylum: A Serious House On Serious Earth 93
All Star Superman 69
Batman: The Long Halloween 35
Detective Comics 85
Gotham Central 76
Arkham Asylum: A Serious House On Serious Earth 11
The Killing Joke 9
Doom Patrol 47
Snowbirds Don't Fly 14
Identity Crisis 89
The Coyote Gospel 56
Detective Comics 52
Arkham Asylum: A Serious House On Serious Earth 56
Multiversity 15
Crisis On Infinite Earths 42
Swamp Thing: The Anatomy Lesson 34
JLA: Tower Of Babel 79
Teen Titans: The Judas Contract 36
Crisis On Infinite Earths 90
For The Man Who Has Everything 92
Jack Kirby's New Gods 27
For The Man Who Has Everything 62
Action Comics 10
