Identity Crisis 24
Action Comics 37
JLA: Earth 2 64
JLA: Earth 2 97
The Dark Knight Returns 31
Superman For All Seasons 35
Teen Titans: The Judas Contract 41
Teen Titans: The Judas Contract 28
JLA: Tower Of Babel 79
The Sinestro Corps War 18
Action Comics 48
The Killing Joke 31
JLA: Tower Of Babel 69
Multiversity 46
Doom Patrol 61
For The Man Who Has Everything 49
All Star Superman 10
Teen Titans: The Judas Contract 30
Doom Patrol 42
Batman: Year One 66
Identity Crisis 10
Snowbirds Don't Fly 68
Superman: Red Son 59
JLA: Tower Of Babel 63
Whatever Happened To The Man Of Tomorrow? 88
Swamp Thing: The Anatomy Lesson 86
The New Frontier 99
Detective Comics 76
JLA: Tower Of Babel 69
Gotham Central 33
Multiversity 59
Identity Crisis 28
The New Frontier 51
All Star Superman 92
Green Arrow: The Longbow Hunters 49
Superman For All Seasons 25
Teen Titans: The Judas Contract 82
Multiversity 31
Green Arrow: The Longbow Hunters 64
JLA: Earth 2 98
Detective Comics 96
Swamp Thing: The Anatomy Lesson 50
Batman: Year One 72
Green Arrow: The Longbow Hunters 26
Green Arrow: The Longbow Hunters 24
Action Comics 32
The Coyote Gospel 4
Batman: The Long Halloween 75
Grant Morrison's Animal Man 91
Grant Morrison's Animal Man 53
Doom Patrol 16
Batman: The Long Halloween 4
Batman: Year One 39
JLA: Earth 2 86
Arkham Asylum: A Serious House On Serious Earth 90
Batman: The Long Halloween 30
Detective Comics 38
Arkham Asylum: A Serious House On Serious Earth 90
Whatever Happened To The Man Of Tomorrow? 61
Batman: The Long Halloween 8
Detective Comics 94
Gotham Central 23
The Killing Joke 25
JLA: Tower Of Babel 31
Doom Patrol 45
Doom Patrol 24
Action Comics 58
Action Comics 15
