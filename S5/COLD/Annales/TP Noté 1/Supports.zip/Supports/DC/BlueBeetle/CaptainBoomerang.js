Superman: Red Son 58
The Killing Joke 95
JLA: Earth 2 36
Superman For All Seasons 19
Snowbirds Don't Fly 78
JLA: Tower Of Babel 55
JLA: Earth 2 51
The Dark Knight Returns 48
Identity Crisis 29
JLA: Earth 2 17
JLA: Tower Of Babel 12
Detective Comics 55
Doom Patrol 60
Snowbirds Don't Fly 80
Gotham Central 67
Kingdom Come 51
Arkham Asylum: A Serious House On Serious Earth 44
Jack Kirby's New Gods 37
Superman For All Seasons 8
Green Arrow: The Longbow Hunters 28
Snowbirds Don't Fly 53
JLA: Tower Of Babel 64
Detective Comics 40
Gotham Central 34
JLA: Tower Of Babel 24
Kingdom Come 33
Snowbirds Don't Fly 1
The New Frontier 29
The Dark Knight Returns 13
Batman: Year One 36
JLA: Earth 2 4
Snowbirds Don't Fly 34
Batman: Year One 38
JLA: Earth 2 73
The Dark Knight Returns 97
Teen Titans: The Judas Contract 23
Superman: Red Son 44
The Sinestro Corps War 45
Gotham Central 99
Batman: The Long Halloween 30
Teen Titans: The Judas Contract 49
All Star Superman 77
Kingdom Come 77
Identity Crisis 21
Green Arrow: The Longbow Hunters 56
Swamp Thing: The Anatomy Lesson 34
For The Man Who Has Everything 59
Gotham Central 18
The Dark Knight Returns 57
Whatever Happened To The Man Of Tomorrow? 45
Superman: Red Son 2
Grant Morrison's Animal Man 55
Grant Morrison's Animal Man 83
Swamp Thing: The Anatomy Lesson 10
The Killing Joke 75
The Coyote Gospel 10
Batman: The Long Halloween 38
Gotham Central 57
Identity Crisis 89
The Coyote Gospel 47
Arkham Asylum: A Serious House On Serious Earth 69
JLA: Tower Of Babel 86
Detective Comics 4
Whatever Happened To The Man Of Tomorrow? 96
For The Man Who Has Everything 8
Crisis On Infinite Earths 72
JLA: Tower Of Babel 41
The Killing Joke 92
Whatever Happened To The Man Of Tomorrow? 71
Kingdom Come 38
Identity Crisis 54
Detective Comics 94
Superman: Red Son 16
Identity Crisis 67
Detective Comics 75
Identity Crisis 71
The Dark Knight Returns 49
Whatever Happened To The Man Of Tomorrow? 49
Gotham Central 2
Identity Crisis 84
Teen Titans: The Judas Contract 87
Kingdom Come 19
Crisis On Infinite Earths 78
Swamp Thing: The Anatomy Lesson 52
Gotham Central 91
Jack Kirby's New Gods 97
The New Frontier 0
JLA: Tower Of Babel 53
Snowbirds Don't Fly 35
The Killing Joke 85
The Sinestro Corps War 74
Crisis On Infinite Earths 5
