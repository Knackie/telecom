The New Frontier 99
Gotham Central 17
Swamp Thing: The Anatomy Lesson 82
Jack Kirby's New Gods 82
The Killing Joke 89
The Killing Joke 41
Action Comics 85
Superman: Red Son 4
The Dark Knight Returns 28
Action Comics 90
The Dark Knight Returns 52
For The Man Who Has Everything 78
Arkham Asylum: A Serious House On Serious Earth 17
Superman For All Seasons 13
Green Arrow: The Longbow Hunters 15
The Killing Joke 71
All Star Superman 44
Grant Morrison's Animal Man 61
JLA: Tower Of Babel 33
Batman: The Long Halloween 17
Jack Kirby's New Gods 87
Gotham Central 51
Gotham Central 25
Green Arrow: The Longbow Hunters 73
Green Arrow: The Longbow Hunters 93
Grant Morrison's Animal Man 87
Snowbirds Don't Fly 83
Teen Titans: The Judas Contract 60
For The Man Who Has Everything 61
Grant Morrison's Animal Man 93
Jack Kirby's New Gods 48
The Killing Joke 13
Action Comics 69
JLA: Tower Of Babel 79
Superman: Red Son 64
Action Comics 70
The Dark Knight Returns 38
JLA: Earth 2 23
Arkham Asylum: A Serious House On Serious Earth 82
Arkham Asylum: A Serious House On Serious Earth 27
The Coyote Gospel 59
Jack Kirby's New Gods 67
Jack Kirby's New Gods 60
The Killing Joke 88
Jack Kirby's New Gods 24
Jack Kirby's New Gods 93
Whatever Happened To The Man Of Tomorrow? 43
Gotham Central 4
The New Frontier 32
JLA: Tower Of Babel 3
Action Comics 21
For The Man Who Has Everything 4
Snowbirds Don't Fly 32
Swamp Thing: The Anatomy Lesson 52
The Killing Joke 11
Jack Kirby's New Gods 57
JLA: Tower Of Babel 5
Whatever Happened To The Man Of Tomorrow? 61
Superman: Red Son 89
Superman: Red Son 2
