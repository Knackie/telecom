All Star Superman 64
Batman: The Long Halloween 59
