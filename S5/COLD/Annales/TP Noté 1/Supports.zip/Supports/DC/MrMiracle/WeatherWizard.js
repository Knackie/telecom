Swamp Thing: The Anatomy Lesson 37
Snowbirds Don't Fly 88
Green Arrow: The Longbow Hunters 55
The Killing Joke 28
Kingdom Come 99
Green Arrow: The Longbow Hunters 63
All Star Superman 73
Whatever Happened To The Man Of Tomorrow? 9
Jack Kirby's New Gods 54
Action Comics 95
Swamp Thing: The Anatomy Lesson 31
The Dark Knight Returns 55
Identity Crisis 1
Detective Comics 63
All Star Superman 17
The Killing Joke 3
Arkham Asylum: A Serious House On Serious Earth 64
Jack Kirby's New Gods 52
Snowbirds Don't Fly 5
Batman: The Long Halloween 63
Green Arrow: The Longbow Hunters 77
Snowbirds Don't Fly 27
The Killing Joke 78
Identity Crisis 57
Action Comics 63
Superman For All Seasons 98
Action Comics 3
The New Frontier 25
Superman For All Seasons 79
Green Arrow: The Longbow Hunters 34
The New Frontier 2
Arkham Asylum: A Serious House On Serious Earth 3
Green Arrow: The Longbow Hunters 36
The Coyote Gospel 22
Arkham Asylum: A Serious House On Serious Earth 86
JLA: Earth 2 71
Detective Comics 79
Superman For All Seasons 45
The Coyote Gospel 42
Identity Crisis 98
Crisis On Infinite Earths 52
Green Arrow: The Longbow Hunters 87
JLA: Tower Of Babel 73
JLA: Earth 2 80
Multiversity 49
Grant Morrison's Animal Man 63
JLA: Earth 2 69
The Killing Joke 39
Jack Kirby's New Gods 13
For The Man Who Has Everything 16
JLA: Earth 2 7
Superman: Red Son 45
Snowbirds Don't Fly 98
Arkham Asylum: A Serious House On Serious Earth 62
Kingdom Come 13
Detective Comics 30
Green Arrow: The Longbow Hunters 19
Superman: Red Son 44
Snowbirds Don't Fly 82
The Sinestro Corps War 44
The Killing Joke 40
The Dark Knight Returns 46
Batman: Year One 84
Grant Morrison's Animal Man 16
Swamp Thing: The Anatomy Lesson 29
