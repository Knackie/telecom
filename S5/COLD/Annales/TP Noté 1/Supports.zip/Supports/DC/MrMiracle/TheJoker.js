Crisis On Infinite Earths 22
JLA: Tower Of Babel 73
Whatever Happened To The Man Of Tomorrow? 64
Batman: The Long Halloween 87
The New Frontier 74
Jack Kirby's New Gods 56
Green Arrow: The Longbow Hunters 43
Multiversity 74
All Star Superman 95
The Dark Knight Returns 48
The Dark Knight Returns 4
Multiversity 15
Swamp Thing: The Anatomy Lesson 2
For The Man Who Has Everything 3
JLA: Earth 2 58
Jack Kirby's New Gods 46
Swamp Thing: The Anatomy Lesson 41
Batman: The Long Halloween 66
Arkham Asylum: A Serious House On Serious Earth 98
JLA: Earth 2 79
Grant Morrison's Animal Man 12
The Dark Knight Returns 44
The Sinestro Corps War 58
Batman: Year One 8
The Coyote Gospel 13
Action Comics 95
For The Man Who Has Everything 50
Batman: Year One 6
Swamp Thing: The Anatomy Lesson 93
Action Comics 91
For The Man Who Has Everything 98
Swamp Thing: The Anatomy Lesson 33
Superman: Red Son 30
Green Arrow: The Longbow Hunters 57
Detective Comics 57
Detective Comics 86
Green Arrow: The Longbow Hunters 16
The New Frontier 73
Green Arrow: The Longbow Hunters 35
Snowbirds Don't Fly 7
Detective Comics 20
Grant Morrison's Animal Man 27
Teen Titans: The Judas Contract 60
Identity Crisis 50
Action Comics 78
Identity Crisis 17
The Killing Joke 99
Grant Morrison's Animal Man 76
Doom Patrol 13
The Coyote Gospel 72
Batman: The Long Halloween 96
Green Arrow: The Longbow Hunters 31
Swamp Thing: The Anatomy Lesson 2
