Crisis On Infinite Earths 48
Arkham Asylum: A Serious House On Serious Earth 91
Batman: Year One 16
The Killing Joke 38
Doom Patrol 27
Snowbirds Don't Fly 48
Teen Titans: The Judas Contract 53
Crisis On Infinite Earths 46
Batman: The Long Halloween 76
Whatever Happened To The Man Of Tomorrow? 80
Swamp Thing: The Anatomy Lesson 37
Superman For All Seasons 58
Multiversity 36
JLA: Tower Of Babel 77
All Star Superman 74
Jack Kirby's New Gods 21
For The Man Who Has Everything 58
Snowbirds Don't Fly 84
Identity Crisis 64
Grant Morrison's Animal Man 43
Detective Comics 55
Batman: The Long Halloween 33
Snowbirds Don't Fly 30
The Sinestro Corps War 65
All Star Superman 65
Action Comics 24
Detective Comics 83
Superman: Red Son 87
