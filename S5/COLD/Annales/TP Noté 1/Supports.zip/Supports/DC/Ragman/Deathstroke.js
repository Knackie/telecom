Superman For All Seasons 51
Multiversity 94
JLA: Earth 2 20
The New Frontier 10
The Sinestro Corps War 11
All Star Superman 8
Kingdom Come 98
Crisis On Infinite Earths 13
Teen Titans: The Judas Contract 0
The Sinestro Corps War 21
Gotham Central 20
Batman: The Long Halloween 16
Doom Patrol 18
Snowbirds Don't Fly 38
Gotham Central 53
Detective Comics 92
The Killing Joke 88
The Sinestro Corps War 57
Snowbirds Don't Fly 98
The Killing Joke 30
Identity Crisis 91
Arkham Asylum: A Serious House On Serious Earth 12
Superman For All Seasons 78
Multiversity 36
Green Arrow: The Longbow Hunters 45
Whatever Happened To The Man Of Tomorrow? 26
Detective Comics 16
Green Arrow: The Longbow Hunters 48
Identity Crisis 38
Teen Titans: The Judas Contract 82
Doom Patrol 26
Superman: Red Son 78
Batman: Year One 32
Multiversity 21
JLA: Tower Of Babel 89
The Dark Knight Returns 34
JLA: Earth 2 89
For The Man Who Has Everything 46
Identity Crisis 27
Batman: Year One 11
Snowbirds Don't Fly 86
The New Frontier 25
Jack Kirby's New Gods 62
Multiversity 36
Detective Comics 93
Doom Patrol 65
Green Arrow: The Longbow Hunters 90
The Coyote Gospel 41
The New Frontier 89
The Coyote Gospel 86
Batman: Year One 67
All Star Superman 91
The New Frontier 13
Gotham Central 46
Jack Kirby's New Gods 45
JLA: Tower Of Babel 25
Whatever Happened To The Man Of Tomorrow? 91
The New Frontier 27
All Star Superman 63
Jack Kirby's New Gods 10
The Sinestro Corps War 83
The Killing Joke 46
Grant Morrison's Animal Man 34
Doom Patrol 63
Swamp Thing: The Anatomy Lesson 37
The Dark Knight Returns 46
Doom Patrol 98
Doom Patrol 88
Snowbirds Don't Fly 5
Crisis On Infinite Earths 48
The Killing Joke 14
Teen Titans: The Judas Contract 13
Jack Kirby's New Gods 47
Gotham Central 65
Crisis On Infinite Earths 61
Teen Titans: The Judas Contract 22
The Killing Joke 95
Action Comics 34
Superman For All Seasons 14
Teen Titans: The Judas Contract 83
Batman: The Long Halloween 53
Identity Crisis 18
Identity Crisis 16
Green Arrow: The Longbow Hunters 40
The Killing Joke 24
The Sinestro Corps War 83
Whatever Happened To The Man Of Tomorrow? 14
Multiversity 87
For The Man Who Has Everything 42
Grant Morrison's Animal Man 61
Detective Comics 57
Gotham Central 67
All Star Superman 18
Batman: The Long Halloween 31
Kingdom Come 77
Multiversity 33
Swamp Thing: The Anatomy Lesson 68
The Dark Knight Returns 33
The New Frontier 20
