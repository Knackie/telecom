Superman For All Seasons 94
Teen Titans: The Judas Contract 59
Superman For All Seasons 33
Whatever Happened To The Man Of Tomorrow? 99
Superman: Red Son 38
Whatever Happened To The Man Of Tomorrow? 39
Doom Patrol 79
Green Arrow: The Longbow Hunters 75
Kingdom Come 79
Arkham Asylum: A Serious House On Serious Earth 86
Kingdom Come 84
Gotham Central 30
Green Arrow: The Longbow Hunters 9
Gotham Central 75
Crisis On Infinite Earths 10
Superman: Red Son 69
JLA: Earth 2 68
Detective Comics 31
Swamp Thing: The Anatomy Lesson 44
Grant Morrison's Animal Man 45
JLA: Earth 2 96
The Killing Joke 19
Doom Patrol 61
All Star Superman 58
The Killing Joke 72
Snowbirds Don't Fly 23
Batman: Year One 93
Superman For All Seasons 24
Action Comics 97
Detective Comics 55
Multiversity 21
Superman For All Seasons 22
JLA: Earth 2 44
Swamp Thing: The Anatomy Lesson 40
The Killing Joke 51
Grant Morrison's Animal Man 7
Identity Crisis 37
Snowbirds Don't Fly 75
Jack Kirby's New Gods 64
Gotham Central 50
Gotham Central 0
Superman: Red Son 43
JLA: Tower Of Babel 94
Crisis On Infinite Earths 21
Doom Patrol 5
Superman For All Seasons 49
Snowbirds Don't Fly 46
Crisis On Infinite Earths 22
Snowbirds Don't Fly 16
JLA: Earth 2 25
Arkham Asylum: A Serious House On Serious Earth 28
The New Frontier 53
JLA: Earth 2 71
Multiversity 72
Jack Kirby's New Gods 86
Action Comics 88
The Dark Knight Returns 2
The Dark Knight Returns 73
JLA: Earth 2 94
Superman For All Seasons 72
Identity Crisis 85
Grant Morrison's Animal Man 13
Gotham Central 8
Crisis On Infinite Earths 82
The Dark Knight Returns 22
The Killing Joke 86
Identity Crisis 30
Gotham Central 0
Superman For All Seasons 5
The New Frontier 50
Superman For All Seasons 16
The Dark Knight Returns 82
JLA: Earth 2 48
Batman: The Long Halloween 50
Snowbirds Don't Fly 28
The Coyote Gospel 17
All Star Superman 66
The Coyote Gospel 27
Gotham Central 36
The Sinestro Corps War 51
Identity Crisis 73
Green Arrow: The Longbow Hunters 86
Doom Patrol 76
The New Frontier 81
The New Frontier 72
JLA: Earth 2 62
Green Arrow: The Longbow Hunters 42
JLA: Tower Of Babel 32
Kingdom Come 12
Teen Titans: The Judas Contract 16
For The Man Who Has Everything 21
Crisis On Infinite Earths 6
The Dark Knight Returns 42
Snowbirds Don't Fly 60
Snowbirds Don't Fly 24
The Killing Joke 49
Batman: Year One 41
