Crisis On Infinite Earths 0
Crisis On Infinite Earths 0
Whatever Happened To The Man Of Tomorrow? 61
The Coyote Gospel 18
Crisis On Infinite Earths 2
Whatever Happened To The Man Of Tomorrow? 12
Detective Comics 34
Swamp Thing: The Anatomy Lesson 39
Green Arrow: The Longbow Hunters 79
Detective Comics 52
The Sinestro Corps War 87
Superman For All Seasons 16
The Killing Joke 14
The Sinestro Corps War 51
The Dark Knight Returns 95
JLA: Earth 2 9
Kingdom Come 79
Swamp Thing: The Anatomy Lesson 99
The New Frontier 95
Action Comics 28
Gotham Central 58
Crisis On Infinite Earths 50
Grant Morrison's Animal Man 25
The Dark Knight Returns 32
Multiversity 9
Detective Comics 32
The Dark Knight Returns 10
Kingdom Come 73
Detective Comics 57
Whatever Happened To The Man Of Tomorrow? 69
Identity Crisis 78
Batman: The Long Halloween 25
JLA: Earth 2 39
All Star Superman 47
Grant Morrison's Animal Man 1
Kingdom Come 20
Gotham Central 46
Detective Comics 97
Arkham Asylum: A Serious House On Serious Earth 88
Swamp Thing: The Anatomy Lesson 70
Teen Titans: The Judas Contract 92
