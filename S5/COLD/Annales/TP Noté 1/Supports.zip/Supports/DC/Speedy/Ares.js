The Coyote Gospel 40
Teen Titans: The Judas Contract 49
Batman: The Long Halloween 30
Batman: The Long Halloween 43
Superman: Red Son 48
Superman: Red Son 66
Superman For All Seasons 28
The Sinestro Corps War 99
Superman: Red Son 41
Snowbirds Don't Fly 43
Green Arrow: The Longbow Hunters 36
Batman: The Long Halloween 10
Green Arrow: The Longbow Hunters 39
The Sinestro Corps War 81
Crisis On Infinite Earths 9
Grant Morrison's Animal Man 55
All Star Superman 4
The Sinestro Corps War 47
Doom Patrol 45
Detective Comics 22
JLA: Earth 2 77
Grant Morrison's Animal Man 72
Green Arrow: The Longbow Hunters 36
Arkham Asylum: A Serious House On Serious Earth 70
Batman: The Long Halloween 54
The New Frontier 45
Batman: Year One 99
Whatever Happened To The Man Of Tomorrow? 61
Superman: Red Son 65
Arkham Asylum: A Serious House On Serious Earth 92
All Star Superman 39
The Dark Knight Returns 91
JLA: Earth 2 11
Identity Crisis 2
Teen Titans: The Judas Contract 69
JLA: Tower Of Babel 7
Detective Comics 32
Jack Kirby's New Gods 37
Grant Morrison's Animal Man 84
The Sinestro Corps War 65
Superman For All Seasons 13
Snowbirds Don't Fly 7
The Sinestro Corps War 85
Whatever Happened To The Man Of Tomorrow? 15
