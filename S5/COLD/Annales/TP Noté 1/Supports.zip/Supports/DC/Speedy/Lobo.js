Detective Comics 22
Teen Titans: The Judas Contract 93
Identity Crisis 19
Identity Crisis 50
The Killing Joke 4
Whatever Happened To The Man Of Tomorrow? 46
The Dark Knight Returns 1
Teen Titans: The Judas Contract 52
The Killing Joke 70
Jack Kirby's New Gods 64
The Dark Knight Returns 15
JLA: Earth 2 79
Doom Patrol 93
Jack Kirby's New Gods 3
Action Comics 37
Superman: Red Son 24
Superman For All Seasons 81
Superman For All Seasons 85
The New Frontier 38
Swamp Thing: The Anatomy Lesson 17
JLA: Tower Of Babel 93
The Coyote Gospel 61
Gotham Central 23
Crisis On Infinite Earths 45
Teen Titans: The Judas Contract 84
Jack Kirby's New Gods 82
Grant Morrison's Animal Man 25
Green Arrow: The Longbow Hunters 42
The Dark Knight Returns 50
Kingdom Come 97
Doom Patrol 69
Swamp Thing: The Anatomy Lesson 14
Snowbirds Don't Fly 61
All Star Superman 78
Snowbirds Don't Fly 86
Identity Crisis 35
Doom Patrol 37
Arkham Asylum: A Serious House On Serious Earth 35
Superman: Red Son 11
The Dark Knight Returns 47
All Star Superman 17
Batman: Year One 29
Snowbirds Don't Fly 60
Swamp Thing: The Anatomy Lesson 20
Arkham Asylum: A Serious House On Serious Earth 82
The New Frontier 39
Jack Kirby's New Gods 44
Swamp Thing: The Anatomy Lesson 56
Detective Comics 20
