Batman: The Long Halloween 77
The Sinestro Corps War 18
Whatever Happened To The Man Of Tomorrow? 90
Gotham Central 37
Green Arrow: The Longbow Hunters 25
Gotham Central 55
Whatever Happened To The Man Of Tomorrow? 61
Batman: The Long Halloween 99
Superman: Red Son 79
JLA: Tower Of Babel 23
The New Frontier 46
Snowbirds Don't Fly 21
Teen Titans: The Judas Contract 10
Multiversity 63
Swamp Thing: The Anatomy Lesson 46
Kingdom Come 8
Identity Crisis 98
Green Arrow: The Longbow Hunters 94
JLA: Earth 2 87
JLA: Tower Of Babel 64
Grant Morrison's Animal Man 49
Doom Patrol 88
The Coyote Gospel 96
For The Man Who Has Everything 13
The Sinestro Corps War 56
Arkham Asylum: A Serious House On Serious Earth 10
Green Arrow: The Longbow Hunters 63
Green Arrow: The Longbow Hunters 72
Snowbirds Don't Fly 47
Teen Titans: The Judas Contract 68
Snowbirds Don't Fly 92
Crisis On Infinite Earths 48
Multiversity 93
The Dark Knight Returns 0
The Killing Joke 1
For The Man Who Has Everything 8
Detective Comics 8
The Sinestro Corps War 60
Crisis On Infinite Earths 35
Teen Titans: The Judas Contract 18
Crisis On Infinite Earths 76
For The Man Who Has Everything 61
JLA: Tower Of Babel 27
Superman For All Seasons 30
The Coyote Gospel 5
Arkham Asylum: A Serious House On Serious Earth 94
JLA: Earth 2 27
Detective Comics 95
Multiversity 3
The Sinestro Corps War 23
Snowbirds Don't Fly 17
Grant Morrison's Animal Man 35
Green Arrow: The Longbow Hunters 9
Whatever Happened To The Man Of Tomorrow? 45
JLA: Earth 2 87
Jack Kirby's New Gods 45
Kingdom Come 78
Multiversity 53
For The Man Who Has Everything 69
Kingdom Come 13
Batman: Year One 55
Identity Crisis 13
Whatever Happened To The Man Of Tomorrow? 17
Arkham Asylum: A Serious House On Serious Earth 53
Action Comics 90
The Dark Knight Returns 51
The New Frontier 12
The Killing Joke 29
Whatever Happened To The Man Of Tomorrow? 51
Teen Titans: The Judas Contract 75
Teen Titans: The Judas Contract 69
Doom Patrol 28
Detective Comics 48
Gotham Central 90
Swamp Thing: The Anatomy Lesson 8
Action Comics 55
Superman: Red Son 69
All Star Superman 61
The Dark Knight Returns 18
Crisis On Infinite Earths 23
Gotham Central 44
