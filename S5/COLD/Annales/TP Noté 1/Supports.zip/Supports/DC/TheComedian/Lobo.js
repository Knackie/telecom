Multiversity 67
Green Arrow: The Longbow Hunters 10
Batman: The Long Halloween 94
Whatever Happened To The Man Of Tomorrow? 46
Detective Comics 46
Teen Titans: The Judas Contract 5
Arkham Asylum: A Serious House On Serious Earth 11
Snowbirds Don't Fly 46
Doom Patrol 94
Detective Comics 32
Identity Crisis 75
Multiversity 20
Snowbirds Don't Fly 92
For The Man Who Has Everything 78
Whatever Happened To The Man Of Tomorrow? 52
Teen Titans: The Judas Contract 87
Identity Crisis 51
The Coyote Gospel 27
Jack Kirby's New Gods 83
Batman: The Long Halloween 23
Action Comics 11
Batman: Year One 1
JLA: Earth 2 92
All Star Superman 13
Crisis On Infinite Earths 14
Detective Comics 17
JLA: Tower Of Babel 33
Batman: The Long Halloween 93
JLA: Earth 2 23
Batman: The Long Halloween 46
Green Arrow: The Longbow Hunters 25
JLA: Earth 2 58
The Dark Knight Returns 50
Doom Patrol 69
Batman: The Long Halloween 90
The Dark Knight Returns 64
Arkham Asylum: A Serious House On Serious Earth 1
The Sinestro Corps War 71
The Killing Joke 11
Crisis On Infinite Earths 28
All Star Superman 1
For The Man Who Has Everything 97
The Coyote Gospel 36
Detective Comics 13
The Killing Joke 17
For The Man Who Has Everything 30
Arkham Asylum: A Serious House On Serious Earth 67
Kingdom Come 70
JLA: Earth 2 0
Doom Patrol 8
Batman: Year One 95
Arkham Asylum: A Serious House On Serious Earth 13
Kingdom Come 7
Doom Patrol 61
Doom Patrol 53
Teen Titans: The Judas Contract 16
The Coyote Gospel 93
The Coyote Gospel 38
Identity Crisis 60
Snowbirds Don't Fly 58
The Killing Joke 65
Superman For All Seasons 70
Crisis On Infinite Earths 29
Superman: Red Son 16
Green Arrow: The Longbow Hunters 83
For The Man Who Has Everything 50
Teen Titans: The Judas Contract 83
Whatever Happened To The Man Of Tomorrow? 15
Swamp Thing: The Anatomy Lesson 72
The Killing Joke 88
