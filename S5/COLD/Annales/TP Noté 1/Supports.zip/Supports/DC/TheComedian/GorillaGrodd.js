Kingdom Come 2
The Coyote Gospel 38
Grant Morrison's Animal Man 49
The Sinestro Corps War 57
All Star Superman 84
Snowbirds Don't Fly 18
Kingdom Come 31
Doom Patrol 67
The New Frontier 35
Batman: The Long Halloween 30
Snowbirds Don't Fly 59
Multiversity 75
Gotham Central 62
Multiversity 26
JLA: Tower Of Babel 97
Green Arrow: The Longbow Hunters 24
Superman: Red Son 56
JLA: Tower Of Babel 69
Crisis On Infinite Earths 9
Swamp Thing: The Anatomy Lesson 25
Batman: Year One 54
Batman: Year One 2
Whatever Happened To The Man Of Tomorrow? 87
Whatever Happened To The Man Of Tomorrow? 63
Swamp Thing: The Anatomy Lesson 51
Snowbirds Don't Fly 72
JLA: Tower Of Babel 85
Batman: Year One 89
JLA: Earth 2 10
The New Frontier 48
Snowbirds Don't Fly 76
Kingdom Come 85
Identity Crisis 42
Grant Morrison's Animal Man 68
Grant Morrison's Animal Man 71
Action Comics 12
Superman For All Seasons 88
Green Arrow: The Longbow Hunters 41
The New Frontier 69
Superman: Red Son 46
Action Comics 87
The New Frontier 26
Doom Patrol 12
The Dark Knight Returns 66
All Star Superman 91
JLA: Tower Of Babel 45
JLA: Tower Of Babel 60
The Dark Knight Returns 81
The Sinestro Corps War 40
Doom Patrol 12
Whatever Happened To The Man Of Tomorrow? 80
Crisis On Infinite Earths 38
Gotham Central 77
Jack Kirby's New Gods 20
Superman: Red Son 0
Superman For All Seasons 96
Identity Crisis 1
Superman: Red Son 12
Detective Comics 2
All Star Superman 89
Swamp Thing: The Anatomy Lesson 34
All Star Superman 38
Batman: The Long Halloween 36
Superman For All Seasons 98
Identity Crisis 60
All Star Superman 50
The New Frontier 44
Whatever Happened To The Man Of Tomorrow? 75
Swamp Thing: The Anatomy Lesson 37
Swamp Thing: The Anatomy Lesson 41
Multiversity 83
JLA: Earth 2 32
Snowbirds Don't Fly 97
Arkham Asylum: A Serious House On Serious Earth 54
Green Arrow: The Longbow Hunters 35
Snowbirds Don't Fly 75
Action Comics 34
Snowbirds Don't Fly 79
Green Arrow: The Longbow Hunters 47
Teen Titans: The Judas Contract 11
The Dark Knight Returns 70
The New Frontier 97
JLA: Tower Of Babel 38
All Star Superman 2
Action Comics 87
Snowbirds Don't Fly 82
Superman For All Seasons 19
