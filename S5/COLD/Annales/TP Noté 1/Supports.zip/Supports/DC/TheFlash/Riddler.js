The New Frontier 9
All Star Superman 54
The Dark Knight Returns 6
Swamp Thing: The Anatomy Lesson 40
Grant Morrison's Animal Man 54
Batman: The Long Halloween 77
Kingdom Come 16
JLA: Earth 2 59
The Killing Joke 45
All Star Superman 71
All Star Superman 99
JLA: Earth 2 46
For The Man Who Has Everything 20
Grant Morrison's Animal Man 19
JLA: Tower Of Babel 63
Superman For All Seasons 1
The Dark Knight Returns 52
Whatever Happened To The Man Of Tomorrow? 1
Identity Crisis 19
Crisis On Infinite Earths 66
Swamp Thing: The Anatomy Lesson 70
Green Arrow: The Longbow Hunters 47
All Star Superman 71
Batman: The Long Halloween 79
JLA: Earth 2 48
Kingdom Come 98
Multiversity 28
The Dark Knight Returns 15
Kingdom Come 39
The New Frontier 16
Detective Comics 96
JLA: Tower Of Babel 73
Green Arrow: The Longbow Hunters 34
The New Frontier 72
All Star Superman 99
Superman: Red Son 24
The Sinestro Corps War 95
Batman: Year One 77
Green Arrow: The Longbow Hunters 21
Teen Titans: The Judas Contract 15
JLA: Earth 2 77
Jack Kirby's New Gods 93
Superman: Red Son 12
Whatever Happened To The Man Of Tomorrow? 67
The Killing Joke 24
The Dark Knight Returns 27
All Star Superman 45
The Sinestro Corps War 93
Swamp Thing: The Anatomy Lesson 3
The Sinestro Corps War 87
JLA: Earth 2 62
Detective Comics 99
Crisis On Infinite Earths 39
For The Man Who Has Everything 74
Crisis On Infinite Earths 49
Whatever Happened To The Man Of Tomorrow? 12
Action Comics 26
The Killing Joke 70
Superman: Red Son 42
Batman: The Long Halloween 1
JLA: Tower Of Babel 67
JLA: Earth 2 53
Superman: Red Son 93
Batman: The Long Halloween 6
Swamp Thing: The Anatomy Lesson 76
