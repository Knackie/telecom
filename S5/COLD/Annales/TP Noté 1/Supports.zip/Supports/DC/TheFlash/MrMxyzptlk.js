The Dark Knight Returns 77
Teen Titans: The Judas Contract 76
Snowbirds Don't Fly 97
Jack Kirby's New Gods 7
The New Frontier 71
Teen Titans: The Judas Contract 35
Green Arrow: The Longbow Hunters 34
Snowbirds Don't Fly 5
The Sinestro Corps War 7
Grant Morrison's Animal Man 94
The Coyote Gospel 70
Multiversity 34
JLA: Tower Of Babel 26
Arkham Asylum: A Serious House On Serious Earth 58
Snowbirds Don't Fly 55
All Star Superman 5
Kingdom Come 81
Detective Comics 0
Identity Crisis 20
Crisis On Infinite Earths 31
Identity Crisis 18
Green Arrow: The Longbow Hunters 11
Kingdom Come 64
Arkham Asylum: A Serious House On Serious Earth 34
Jack Kirby's New Gods 21
Doom Patrol 41
Gotham Central 38
All Star Superman 35
Kingdom Come 89
Grant Morrison's Animal Man 0
Action Comics 50
Batman: Year One 14
All Star Superman 75
Identity Crisis 27
Jack Kirby's New Gods 19
Jack Kirby's New Gods 30
Green Arrow: The Longbow Hunters 34
Action Comics 54
Swamp Thing: The Anatomy Lesson 4
Arkham Asylum: A Serious House On Serious Earth 81
The New Frontier 46
Superman: Red Son 36
Swamp Thing: The Anatomy Lesson 0
The Dark Knight Returns 58
Snowbirds Don't Fly 94
Gotham Central 84
The Coyote Gospel 55
JLA: Tower Of Babel 18
Crisis On Infinite Earths 14
Action Comics 79
Identity Crisis 51
Multiversity 79
JLA: Earth 2 81
All Star Superman 58
Batman: The Long Halloween 39
The Killing Joke 87
Gotham Central 63
Swamp Thing: The Anatomy Lesson 86
Superman For All Seasons 22
