Doom Patrol 70
Crisis On Infinite Earths 71
For The Man Who Has Everything 61
Batman: The Long Halloween 27
Arkham Asylum: A Serious House On Serious Earth 0
Teen Titans: The Judas Contract 42
JLA: Earth 2 5
Batman: Year One 52
Superman For All Seasons 33
For The Man Who Has Everything 56
Swamp Thing: The Anatomy Lesson 50
Identity Crisis 65
For The Man Who Has Everything 77
Grant Morrison's Animal Man 91
For The Man Who Has Everything 25
Action Comics 30
Detective Comics 59
Whatever Happened To The Man Of Tomorrow? 66
The Sinestro Corps War 61
Crisis On Infinite Earths 8
Teen Titans: The Judas Contract 98
Whatever Happened To The Man Of Tomorrow? 4
Superman For All Seasons 50
Superman For All Seasons 76
The New Frontier 86
Gotham Central 12
Arkham Asylum: A Serious House On Serious Earth 46
For The Man Who Has Everything 15
Whatever Happened To The Man Of Tomorrow? 44
Batman: The Long Halloween 12
Action Comics 22
The Killing Joke 97
Superman: Red Son 11
The Killing Joke 49
Grant Morrison's Animal Man 99
Batman: Year One 16
The Killing Joke 95
Identity Crisis 43
Batman: The Long Halloween 1
Arkham Asylum: A Serious House On Serious Earth 66
The Dark Knight Returns 70
Action Comics 14
JLA: Tower Of Babel 51
Whatever Happened To The Man Of Tomorrow? 27
JLA: Tower Of Babel 90
The Dark Knight Returns 92
All Star Superman 73
Doom Patrol 6
Action Comics 84
JLA: Earth 2 60
The Dark Knight Returns 35
Gotham Central 15
Gotham Central 31
Gotham Central 8
Grant Morrison's Animal Man 7
Jack Kirby's New Gods 95
Gotham Central 98
Swamp Thing: The Anatomy Lesson 77
Batman: The Long Halloween 84
The Coyote Gospel 62
Batman: The Long Halloween 3
Identity Crisis 36
Action Comics 73
JLA: Tower Of Babel 89
Whatever Happened To The Man Of Tomorrow? 48
JLA: Tower Of Babel 98
Green Arrow: The Longbow Hunters 66
Detective Comics 99
JLA: Earth 2 95
The Killing Joke 35
The New Frontier 17
Kingdom Come 55
Identity Crisis 74
Superman For All Seasons 74
Detective Comics 25
Doom Patrol 55
JLA: Tower Of Babel 59
Superman For All Seasons 23
Batman: Year One 7
