Kingdom Come 56
Batman: Year One 36
Arkham Asylum: A Serious House On Serious Earth 34
Gotham Central 46
For The Man Who Has Everything 80
Batman: The Long Halloween 20
Doom Patrol 54
JLA: Tower Of Babel 31
Batman: Year One 77
Swamp Thing: The Anatomy Lesson 62
The Killing Joke 50
Crisis On Infinite Earths 76
Doom Patrol 69
The Coyote Gospel 67
Gotham Central 20
The Sinestro Corps War 65
Snowbirds Don't Fly 24
Kingdom Come 22
For The Man Who Has Everything 52
Swamp Thing: The Anatomy Lesson 40
Green Arrow: The Longbow Hunters 15
The Killing Joke 25
The New Frontier 17
The Sinestro Corps War 21
Kingdom Come 34
For The Man Who Has Everything 96
Identity Crisis 61
Doom Patrol 98
JLA: Earth 2 20
Snowbirds Don't Fly 83
The Sinestro Corps War 30
Batman: Year One 29
Gotham Central 58
Grant Morrison's Animal Man 90
The Sinestro Corps War 66
The Dark Knight Returns 75
The Coyote Gospel 38
Identity Crisis 94
Swamp Thing: The Anatomy Lesson 98
Whatever Happened To The Man Of Tomorrow? 30
Kingdom Come 55
Green Arrow: The Longbow Hunters 52
