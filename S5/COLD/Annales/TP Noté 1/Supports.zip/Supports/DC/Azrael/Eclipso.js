The Killing Joke 12
Superman For All Seasons 87
JLA: Earth 2 6
The Coyote Gospel 8
For The Man Who Has Everything 39
Multiversity 69
The Coyote Gospel 4
Identity Crisis 34
The Coyote Gospel 19
Jack Kirby's New Gods 13
JLA: Earth 2 87
Superman For All Seasons 52
Batman: Year One 21
Arkham Asylum: A Serious House On Serious Earth 19
The Dark Knight Returns 34
JLA: Earth 2 89
Doom Patrol 32
JLA: Tower Of Babel 53
Kingdom Come 14
All Star Superman 81
Gotham Central 92
Identity Crisis 9
Green Arrow: The Longbow Hunters 93
Superman For All Seasons 6
Swamp Thing: The Anatomy Lesson 11
The Killing Joke 70
JLA: Tower Of Babel 3
Whatever Happened To The Man Of Tomorrow? 63
Batman: The Long Halloween 56
Detective Comics 59
Action Comics 78
Identity Crisis 79
The Killing Joke 28
Detective Comics 17
Green Arrow: The Longbow Hunters 51
Superman: Red Son 92
Identity Crisis 82
Action Comics 13
Swamp Thing: The Anatomy Lesson 15
Crisis On Infinite Earths 26
The Sinestro Corps War 26
Jack Kirby's New Gods 17
Green Arrow: The Longbow Hunters 99
JLA: Earth 2 34
Arkham Asylum: A Serious House On Serious Earth 75
Detective Comics 55
Batman: The Long Halloween 72
Arkham Asylum: A Serious House On Serious Earth 46
Doom Patrol 43
Batman: Year One 58
Batman: Year One 29
Superman: Red Son 70
JLA: Tower Of Babel 71
Kingdom Come 12
For The Man Who Has Everything 62
Multiversity 71
For The Man Who Has Everything 69
Batman: The Long Halloween 80
The Coyote Gospel 70
Detective Comics 91
Crisis On Infinite Earths 46
Superman For All Seasons 78
Arkham Asylum: A Serious House On Serious Earth 53
JLA: Earth 2 92
Kingdom Come 84
Identity Crisis 30
Batman: Year One 11
For The Man Who Has Everything 52
Batman: The Long Halloween 34
Identity Crisis 59
The New Frontier 85
The Coyote Gospel 23
Multiversity 41
Green Arrow: The Longbow Hunters 82
Swamp Thing: The Anatomy Lesson 8
Crisis On Infinite Earths 58
Arkham Asylum: A Serious House On Serious Earth 57
Swamp Thing: The Anatomy Lesson 40
