JLA: Tower Of Babel 37
Superman: Red Son 41
JLA: Tower Of Babel 65
Crisis On Infinite Earths 62
Identity Crisis 93
The Coyote Gospel 95
Batman: Year One 60
Detective Comics 12
Kingdom Come 27
Detective Comics 77
Green Arrow: The Longbow Hunters 94
Superman: Red Son 33
JLA: Tower Of Babel 9
Gotham Central 49
Superman For All Seasons 22
Gotham Central 92
Gotham Central 44
Kingdom Come 35
Jack Kirby's New Gods 13
Green Arrow: The Longbow Hunters 66
Batman: The Long Halloween 6
The Coyote Gospel 6
Superman: Red Son 26
Whatever Happened To The Man Of Tomorrow? 29
Whatever Happened To The Man Of Tomorrow? 38
The Sinestro Corps War 36
Gotham Central 88
Gotham Central 81
Batman: The Long Halloween 44
The Sinestro Corps War 32
Jack Kirby's New Gods 94
Superman For All Seasons 68
Green Arrow: The Longbow Hunters 46
Kingdom Come 51
Superman: Red Son 1
Action Comics 61
Jack Kirby's New Gods 16
Swamp Thing: The Anatomy Lesson 39
Identity Crisis 25
Green Arrow: The Longbow Hunters 10
Detective Comics 89
Kingdom Come 36
The Coyote Gospel 13
JLA: Tower Of Babel 46
Grant Morrison's Animal Man 61
Snowbirds Don't Fly 11
Jack Kirby's New Gods 0
Gotham Central 79
Whatever Happened To The Man Of Tomorrow? 52
The New Frontier 63
JLA: Earth 2 35
The New Frontier 35
Kingdom Come 13
Identity Crisis 73
The New Frontier 57
Green Arrow: The Longbow Hunters 7
Kingdom Come 55
The New Frontier 6
The Coyote Gospel 43
For The Man Who Has Everything 47
Batman: Year One 38
Arkham Asylum: A Serious House On Serious Earth 7
Green Arrow: The Longbow Hunters 40
Multiversity 37
Jack Kirby's New Gods 10
Crisis On Infinite Earths 80
Snowbirds Don't Fly 62
For The Man Who Has Everything 55
Kingdom Come 6
Teen Titans: The Judas Contract 45
The Sinestro Corps War 46
Whatever Happened To The Man Of Tomorrow? 7
Batman: The Long Halloween 14
Arkham Asylum: A Serious House On Serious Earth 30
Swamp Thing: The Anatomy Lesson 7
Superman For All Seasons 93
JLA: Earth 2 94
Gotham Central 51
