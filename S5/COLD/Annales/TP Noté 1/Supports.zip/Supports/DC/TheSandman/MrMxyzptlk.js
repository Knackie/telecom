Kingdom Come 23
Action Comics 10
Whatever Happened To The Man Of Tomorrow? 74
Kingdom Come 54
Crisis On Infinite Earths 39
The Sinestro Corps War 63
Action Comics 12
Action Comics 14
Batman: Year One 49
Whatever Happened To The Man Of Tomorrow? 53
The Sinestro Corps War 80
Teen Titans: The Judas Contract 97
All Star Superman 17
Action Comics 59
Arkham Asylum: A Serious House On Serious Earth 2
Crisis On Infinite Earths 97
Arkham Asylum: A Serious House On Serious Earth 20
Whatever Happened To The Man Of Tomorrow? 80
All Star Superman 46
Swamp Thing: The Anatomy Lesson 26
Grant Morrison's Animal Man 89
The Coyote Gospel 50
JLA: Tower Of Babel 52
Green Arrow: The Longbow Hunters 15
Jack Kirby's New Gods 23
Action Comics 37
Action Comics 95
Whatever Happened To The Man Of Tomorrow? 89
Green Arrow: The Longbow Hunters 18
JLA: Tower Of Babel 59
Arkham Asylum: A Serious House On Serious Earth 42
JLA: Tower Of Babel 80
Detective Comics 30
Multiversity 26
Action Comics 86
Swamp Thing: The Anatomy Lesson 96
The Killing Joke 21
The Coyote Gospel 72
Jack Kirby's New Gods 41
The New Frontier 40
Superman: Red Son 0
All Star Superman 90
Grant Morrison's Animal Man 71
Superman: Red Son 12
Swamp Thing: The Anatomy Lesson 20
The Sinestro Corps War 69
Superman For All Seasons 47
The Sinestro Corps War 46
Identity Crisis 92
Gotham Central 43
Multiversity 41
Whatever Happened To The Man Of Tomorrow? 69
Kingdom Come 47
Gotham Central 90
Crisis On Infinite Earths 75
The Coyote Gospel 52
Action Comics 65
Doom Patrol 25
JLA: Tower Of Babel 62
Detective Comics 70
JLA: Earth 2 61
Grant Morrison's Animal Man 54
Identity Crisis 81
Grant Morrison's Animal Man 70
Arkham Asylum: A Serious House On Serious Earth 24
The Dark Knight Returns 15
Superman For All Seasons 9
For The Man Who Has Everything 64
Kingdom Come 77
Green Arrow: The Longbow Hunters 87
Multiversity 90
The Killing Joke 99
Superman: Red Son 46
Kingdom Come 60
The Dark Knight Returns 22
The Killing Joke 51
For The Man Who Has Everything 54
Multiversity 34
