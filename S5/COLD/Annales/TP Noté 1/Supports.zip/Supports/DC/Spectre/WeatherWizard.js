Batman: The Long Halloween 2
The Killing Joke 45
Swamp Thing: The Anatomy Lesson 54
Doom Patrol 62
Swamp Thing: The Anatomy Lesson 50
Multiversity 9
All Star Superman 83
Detective Comics 51
Grant Morrison's Animal Man 47
Swamp Thing: The Anatomy Lesson 22
Grant Morrison's Animal Man 22
Jack Kirby's New Gods 49
Superman: Red Son 32
Batman: The Long Halloween 68
Detective Comics 45
Green Arrow: The Longbow Hunters 75
Batman: The Long Halloween 37
JLA: Earth 2 15
Swamp Thing: The Anatomy Lesson 60
Doom Patrol 78
Action Comics 93
JLA: Tower Of Babel 41
Batman: Year One 37
Superman: Red Son 91
All Star Superman 38
For The Man Who Has Everything 33
Action Comics 1
Arkham Asylum: A Serious House On Serious Earth 42
Superman: Red Son 27
JLA: Earth 2 62
The New Frontier 95
Arkham Asylum: A Serious House On Serious Earth 81
The Dark Knight Returns 32
Kingdom Come 71
Whatever Happened To The Man Of Tomorrow? 43
JLA: Tower Of Babel 55
Arkham Asylum: A Serious House On Serious Earth 92
Gotham Central 73
JLA: Tower Of Babel 58
Snowbirds Don't Fly 33
Swamp Thing: The Anatomy Lesson 75
The Dark Knight Returns 48
The Dark Knight Returns 81
The Dark Knight Returns 28
Doom Patrol 25
Snowbirds Don't Fly 3
Crisis On Infinite Earths 4
Action Comics 37
For The Man Who Has Everything 69
Doom Patrol 25
The Coyote Gospel 27
Superman For All Seasons 69
Teen Titans: The Judas Contract 45
Action Comics 46
Multiversity 9
Swamp Thing: The Anatomy Lesson 61
Identity Crisis 15
Whatever Happened To The Man Of Tomorrow? 94
Superman For All Seasons 5
Batman: The Long Halloween 9
Multiversity 89
JLA: Tower Of Babel 18
For The Man Who Has Everything 58
For The Man Who Has Everything 77
Superman: Red Son 42
Batman: Year One 87
Swamp Thing: The Anatomy Lesson 21
Jack Kirby's New Gods 7
Kingdom Come 88
Swamp Thing: The Anatomy Lesson 32
The Dark Knight Returns 5
Batman: The Long Halloween 18
Batman: Year One 31
Crisis On Infinite Earths 41
The Dark Knight Returns 95
JLA: Earth 2 53
The Killing Joke 69
Whatever Happened To The Man Of Tomorrow? 70
Arkham Asylum: A Serious House On Serious Earth 98
