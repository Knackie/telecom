Identity Crisis 96
JLA: Earth 2 25
Batman: The Long Halloween 17
JLA: Earth 2 96
All Star Superman 91
The Dark Knight Returns 96
Superman: Red Son 80
Teen Titans: The Judas Contract 53
The Coyote Gospel 46
Batman: The Long Halloween 44
Superman: Red Son 91
Action Comics 2
The Coyote Gospel 90
Kingdom Come 88
For The Man Who Has Everything 77
Batman: The Long Halloween 89
