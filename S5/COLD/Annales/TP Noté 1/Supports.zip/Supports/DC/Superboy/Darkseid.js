Green Arrow: The Longbow Hunters 74
Swamp Thing: The Anatomy Lesson 92
Identity Crisis 68
JLA: Tower Of Babel 40
Gotham Central 34
Doom Patrol 54
Green Arrow: The Longbow Hunters 68
Batman: The Long Halloween 89
For The Man Who Has Everything 70
For The Man Who Has Everything 22
JLA: Earth 2 73
Multiversity 32
Crisis On Infinite Earths 92
The Dark Knight Returns 97
Crisis On Infinite Earths 79
Kingdom Come 85
JLA: Tower Of Babel 73
Whatever Happened To The Man Of Tomorrow? 16
Doom Patrol 30
Kingdom Come 48
Detective Comics 62
Superman: Red Son 45
Whatever Happened To The Man Of Tomorrow? 17
JLA: Earth 2 34
Gotham Central 59
Whatever Happened To The Man Of Tomorrow? 36
Identity Crisis 91
Multiversity 61
Snowbirds Don't Fly 21
JLA: Earth 2 58
The Dark Knight Returns 53
Jack Kirby's New Gods 96
Identity Crisis 7
Crisis On Infinite Earths 57
Grant Morrison's Animal Man 88
Gotham Central 62
Whatever Happened To The Man Of Tomorrow? 97
The Coyote Gospel 16
Superman: Red Son 30
The Killing Joke 97
Swamp Thing: The Anatomy Lesson 40
The Dark Knight Returns 35
The Sinestro Corps War 73
Whatever Happened To The Man Of Tomorrow? 17
The New Frontier 43
Swamp Thing: The Anatomy Lesson 51
For The Man Who Has Everything 17
Batman: Year One 27
For The Man Who Has Everything 58
Detective Comics 56
Batman: The Long Halloween 35
Crisis On Infinite Earths 32
Gotham Central 21
Gotham Central 74
The Killing Joke 42
Arkham Asylum: A Serious House On Serious Earth 31
Batman: Year One 3
Crisis On Infinite Earths 81
JLA: Tower Of Babel 74
Superman: Red Son 70
All Star Superman 18
Swamp Thing: The Anatomy Lesson 23
The Sinestro Corps War 81
Superman For All Seasons 51
Batman: Year One 97
The Coyote Gospel 85
Batman: The Long Halloween 27
Whatever Happened To The Man Of Tomorrow? 40
Jack Kirby's New Gods 84
The Coyote Gospel 91
Crisis On Infinite Earths 22
Batman: Year One 34
