Jack Kirby's New Gods 52
Swamp Thing: The Anatomy Lesson 42
For The Man Who Has Everything 80
Doom Patrol 51
The Coyote Gospel 61
Snowbirds Don't Fly 77
Detective Comics 18
Green Arrow: The Longbow Hunters 92
JLA: Tower Of Babel 61
Batman: Year One 84
Action Comics 53
Kingdom Come 57
Teen Titans: The Judas Contract 59
Superman: Red Son 41
The Sinestro Corps War 26
All Star Superman 72
Action Comics 9
Grant Morrison's Animal Man 99
Crisis On Infinite Earths 39
Detective Comics 39
Swamp Thing: The Anatomy Lesson 96
The Sinestro Corps War 54
Crisis On Infinite Earths 32
Action Comics 80
Gotham Central 9
Action Comics 77
Doom Patrol 41
Teen Titans: The Judas Contract 75
Green Arrow: The Longbow Hunters 84
Jack Kirby's New Gods 49
JLA: Tower Of Babel 78
The Dark Knight Returns 85
Gotham Central 10
Crisis On Infinite Earths 8
Action Comics 28
Crisis On Infinite Earths 42
Arkham Asylum: A Serious House On Serious Earth 2
Detective Comics 40
Crisis On Infinite Earths 96
The Sinestro Corps War 23
Arkham Asylum: A Serious House On Serious Earth 91
Batman: Year One 59
Jack Kirby's New Gods 7
Batman: The Long Halloween 32
Batman: The Long Halloween 8
Grant Morrison's Animal Man 16
Grant Morrison's Animal Man 53
JLA: Tower Of Babel 91
The Coyote Gospel 38
JLA: Earth 2 36
Identity Crisis 77
Identity Crisis 25
Arkham Asylum: A Serious House On Serious Earth 82
Action Comics 59
The New Frontier 70
All Star Superman 21
Superman For All Seasons 67
Gotham Central 12
Jack Kirby's New Gods 56
Kingdom Come 57
