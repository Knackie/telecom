Swamp Thing: The Anatomy Lesson 1
Grant Morrison's Animal Man 87
Action Comics 33
JLA: Earth 2 30
Batman: Year One 76
The Dark Knight Returns 51
Green Arrow: The Longbow Hunters 22
Gotham Central 63
Batman: Year One 41
Kingdom Come 55
