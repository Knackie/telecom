Doom Patrol 7
The Dark Knight Returns 64
All Star Superman 8
Identity Crisis 48
The Sinestro Corps War 94
Multiversity 0
Whatever Happened To The Man Of Tomorrow? 7
The Killing Joke 8
JLA: Earth 2 64
The Coyote Gospel 10
Arkham Asylum: A Serious House On Serious Earth 86
Action Comics 70
Green Arrow: The Longbow Hunters 6
JLA: Tower Of Babel 90
Jack Kirby's New Gods 80
The New Frontier 4
Snowbirds Don't Fly 40
The New Frontier 30
Identity Crisis 71
JLA: Tower Of Babel 67
The Coyote Gospel 56
The Killing Joke 2
The Coyote Gospel 60
JLA: Tower Of Babel 18
Arkham Asylum: A Serious House On Serious Earth 21
Whatever Happened To The Man Of Tomorrow? 49
Action Comics 59
The Sinestro Corps War 23
Superman For All Seasons 67
Whatever Happened To The Man Of Tomorrow? 15
Gotham Central 2
JLA: Tower Of Babel 51
The Coyote Gospel 85
Jack Kirby's New Gods 11
Action Comics 60
Superman: Red Son 35
Doom Patrol 39
The Killing Joke 42
Batman: Year One 92
Identity Crisis 62
Superman For All Seasons 20
Batman: Year One 34
Green Arrow: The Longbow Hunters 74
The Dark Knight Returns 0
Whatever Happened To The Man Of Tomorrow? 23
Arkham Asylum: A Serious House On Serious Earth 23
Identity Crisis 82
Superman For All Seasons 53
