Snowbirds Don't Fly 48
Crisis On Infinite Earths 5
JLA: Earth 2 45
Green Arrow: The Longbow Hunters 81
The Sinestro Corps War 96
Doom Patrol 85
The Killing Joke 58
All Star Superman 23
For The Man Who Has Everything 45
Whatever Happened To The Man Of Tomorrow? 78
Batman: Year One 31
For The Man Who Has Everything 6
JLA: Earth 2 5
Grant Morrison's Animal Man 43
JLA: Tower Of Babel 89
The Killing Joke 91
Multiversity 62
Batman: The Long Halloween 41
The Sinestro Corps War 14
