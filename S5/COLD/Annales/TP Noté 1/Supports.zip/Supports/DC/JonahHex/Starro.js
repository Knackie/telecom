For The Man Who Has Everything 76
Crisis On Infinite Earths 67
All Star Superman 33
Arkham Asylum: A Serious House On Serious Earth 70
Doom Patrol 93
The Dark Knight Returns 59
The Coyote Gospel 40
Batman: Year One 70
The Dark Knight Returns 82
All Star Superman 99
Kingdom Come 69
The Sinestro Corps War 53
Snowbirds Don't Fly 50
JLA: Tower Of Babel 68
Multiversity 36
Doom Patrol 98
Crisis On Infinite Earths 30
Action Comics 57
JLA: Earth 2 77
All Star Superman 78
Teen Titans: The Judas Contract 41
Detective Comics 56
Jack Kirby's New Gods 34
Identity Crisis 61
Grant Morrison's Animal Man 91
Swamp Thing: The Anatomy Lesson 7
JLA: Earth 2 94
Jack Kirby's New Gods 41
The Coyote Gospel 63
JLA: Tower Of Babel 89
Superman: Red Son 19
Whatever Happened To The Man Of Tomorrow? 27
Whatever Happened To The Man Of Tomorrow? 88
The Dark Knight Returns 33
Teen Titans: The Judas Contract 18
For The Man Who Has Everything 40
Grant Morrison's Animal Man 52
The Dark Knight Returns 23
All Star Superman 92
Jack Kirby's New Gods 57
Superman: Red Son 42
Whatever Happened To The Man Of Tomorrow? 4
Arkham Asylum: A Serious House On Serious Earth 98
All Star Superman 73
JLA: Tower Of Babel 95
Teen Titans: The Judas Contract 20
Jack Kirby's New Gods 67
Batman: Year One 24
Crisis On Infinite Earths 81
Batman: The Long Halloween 49
Identity Crisis 80
Crisis On Infinite Earths 76
Grant Morrison's Animal Man 2
For The Man Who Has Everything 43
Snowbirds Don't Fly 93
Kingdom Come 61
The Coyote Gospel 61
Superman For All Seasons 55
All Star Superman 88
The Sinestro Corps War 52
Whatever Happened To The Man Of Tomorrow? 89
All Star Superman 34
JLA: Tower Of Babel 3
Batman: The Long Halloween 15
Identity Crisis 18
Snowbirds Don't Fly 38
Grant Morrison's Animal Man 20
The Killing Joke 24
Grant Morrison's Animal Man 72
JLA: Earth 2 0
Detective Comics 67
Snowbirds Don't Fly 10
Kingdom Come 40
For The Man Who Has Everything 51
Kingdom Come 83
Grant Morrison's Animal Man 95
Green Arrow: The Longbow Hunters 66
Crisis On Infinite Earths 4
Green Arrow: The Longbow Hunters 1
Detective Comics 91
Identity Crisis 6
