Superman For All Seasons 65
Crisis On Infinite Earths 57
Gotham Central 4
Teen Titans: The Judas Contract 98
Teen Titans: The Judas Contract 1
Superman: Red Son 79
JLA: Earth 2 46
Swamp Thing: The Anatomy Lesson 20
Detective Comics 47
Identity Crisis 32
Teen Titans: The Judas Contract 24
Detective Comics 73
Superman For All Seasons 20
For The Man Who Has Everything 38
Identity Crisis 40
The New Frontier 94
Green Arrow: The Longbow Hunters 27
JLA: Tower Of Babel 85
The Dark Knight Returns 9
Snowbirds Don't Fly 82
The Sinestro Corps War 22
JLA: Tower Of Babel 29
