Arkham Asylum: A Serious House On Serious Earth 31
Batman: Year One 63
Snowbirds Don't Fly 16
Action Comics 24
Superman: Red Son 99
The Dark Knight Returns 19
Doom Patrol 98
Green Arrow: The Longbow Hunters 49
Swamp Thing: The Anatomy Lesson 76
Doom Patrol 51
The Sinestro Corps War 3
The New Frontier 20
Batman: The Long Halloween 52
Superman For All Seasons 61
Swamp Thing: The Anatomy Lesson 39
Swamp Thing: The Anatomy Lesson 45
Detective Comics 34
Action Comics 36
Identity Crisis 28
Swamp Thing: The Anatomy Lesson 89
Grant Morrison's Animal Man 14
The Coyote Gospel 78
The Sinestro Corps War 13
Crisis On Infinite Earths 41
Batman: Year One 40
The Dark Knight Returns 28
Doom Patrol 34
Swamp Thing: The Anatomy Lesson 95
The New Frontier 23
For The Man Who Has Everything 96
Superman: Red Son 39
Kingdom Come 13
Crisis On Infinite Earths 0
Detective Comics 2
Batman: The Long Halloween 78
Batman: The Long Halloween 70
Kingdom Come 18
Identity Crisis 8
JLA: Earth 2 13
The Sinestro Corps War 19
Crisis On Infinite Earths 21
