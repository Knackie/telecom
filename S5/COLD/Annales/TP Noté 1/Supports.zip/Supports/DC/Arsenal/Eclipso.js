Arkham Asylum: A Serious House On Serious Earth 99
Kingdom Come 89
Teen Titans: The Judas Contract 17
Teen Titans: The Judas Contract 14
Identity Crisis 62
The Coyote Gospel 70
Swamp Thing: The Anatomy Lesson 95
The New Frontier 61
Identity Crisis 20
Swamp Thing: The Anatomy Lesson 76
The Coyote Gospel 75
Swamp Thing: The Anatomy Lesson 56
For The Man Who Has Everything 45
JLA: Tower Of Babel 18
Snowbirds Don't Fly 48
The New Frontier 51
Action Comics 16
Snowbirds Don't Fly 72
Grant Morrison's Animal Man 81
Snowbirds Don't Fly 7
Kingdom Come 19
Gotham Central 85
Gotham Central 58
Arkham Asylum: A Serious House On Serious Earth 10
Superman For All Seasons 44
Superman: Red Son 94
Detective Comics 66
JLA: Tower Of Babel 57
JLA: Tower Of Babel 57
The New Frontier 90
Action Comics 32
Jack Kirby's New Gods 7
Detective Comics 67
All Star Superman 86
Superman For All Seasons 16
Gotham Central 66
Green Arrow: The Longbow Hunters 21
Doom Patrol 10
The Dark Knight Returns 32
Detective Comics 39
Kingdom Come 46
Multiversity 13
Gotham Central 73
Action Comics 16
JLA: Earth 2 16
Snowbirds Don't Fly 78
Batman: Year One 27
Green Arrow: The Longbow Hunters 77
Gotham Central 66
Superman For All Seasons 97
Arkham Asylum: A Serious House On Serious Earth 41
Superman For All Seasons 95
Doom Patrol 73
The Killing Joke 96
Gotham Central 60
Green Arrow: The Longbow Hunters 77
The Dark Knight Returns 92
Jack Kirby's New Gods 62
Whatever Happened To The Man Of Tomorrow? 6
All Star Superman 36
Multiversity 30
Identity Crisis 34
Superman: Red Son 67
Jack Kirby's New Gods 74
Jack Kirby's New Gods 93
Multiversity 89
JLA: Earth 2 57
All Star Superman 83
Teen Titans: The Judas Contract 13
JLA: Tower Of Babel 89
JLA: Earth 2 17
Arkham Asylum: A Serious House On Serious Earth 53
Green Arrow: The Longbow Hunters 78
The Dark Knight Returns 19
JLA: Earth 2 61
Swamp Thing: The Anatomy Lesson 95
Detective Comics 58
Teen Titans: The Judas Contract 73
Teen Titans: The Judas Contract 72
The New Frontier 41
Whatever Happened To The Man Of Tomorrow? 46
For The Man Who Has Everything 18
The Dark Knight Returns 8
Multiversity 7
The Killing Joke 48
For The Man Who Has Everything 27
Detective Comics 23
The Coyote Gospel 48
Crisis On Infinite Earths 11
The Killing Joke 71
The Coyote Gospel 69
Superman: Red Son 35
Detective Comics 51
Action Comics 26
Teen Titans: The Judas Contract 14
Doom Patrol 57
Batman: The Long Halloween 35
