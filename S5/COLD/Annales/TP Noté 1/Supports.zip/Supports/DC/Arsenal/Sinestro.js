Detective Comics 79
Teen Titans: The Judas Contract 78
Action Comics 1
Kingdom Come 89
Doom Patrol 75
Jack Kirby's New Gods 23
For The Man Who Has Everything 75
Snowbirds Don't Fly 20
Crisis On Infinite Earths 71
All Star Superman 63
Whatever Happened To The Man Of Tomorrow? 39
All Star Superman 68
Batman: Year One 30
Teen Titans: The Judas Contract 23
The Killing Joke 48
Batman: Year One 1
JLA: Tower Of Babel 98
JLA: Tower Of Babel 61
JLA: Earth 2 59
Batman: The Long Halloween 49
Green Arrow: The Longbow Hunters 27
Batman: The Long Halloween 25
