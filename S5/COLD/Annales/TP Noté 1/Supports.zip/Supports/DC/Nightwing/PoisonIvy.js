Green Arrow: The Longbow Hunters 97
Gotham Central 76
Batman: Year One 80
Superman For All Seasons 85
Swamp Thing: The Anatomy Lesson 15
Superman: Red Son 11
Snowbirds Don't Fly 83
The Sinestro Corps War 31
Jack Kirby's New Gods 79
The Dark Knight Returns 32
Action Comics 59
Batman: The Long Halloween 0
Green Arrow: The Longbow Hunters 38
Green Arrow: The Longbow Hunters 76
Jack Kirby's New Gods 44
Whatever Happened To The Man Of Tomorrow? 37
The Coyote Gospel 75
JLA: Earth 2 47
The Dark Knight Returns 27
Swamp Thing: The Anatomy Lesson 65
