Batman: Year One 91
The Killing Joke 70
Action Comics 93
Multiversity 19
JLA: Tower Of Babel 90
For The Man Who Has Everything 93
Batman: Year One 9
Whatever Happened To The Man Of Tomorrow? 6
Superman: Red Son 52
Gotham Central 34
The Dark Knight Returns 3
The Dark Knight Returns 68
Doom Patrol 75
Green Arrow: The Longbow Hunters 39
For The Man Who Has Everything 10
Doom Patrol 3
JLA: Earth 2 93
The Sinestro Corps War 54
Snowbirds Don't Fly 20
The Dark Knight Returns 83
Batman: Year One 78
The Dark Knight Returns 20
Jack Kirby's New Gods 35
JLA: Tower Of Babel 13
Identity Crisis 43
Grant Morrison's Animal Man 78
Batman: The Long Halloween 0
For The Man Who Has Everything 14
Doom Patrol 26
JLA: Earth 2 86
Grant Morrison's Animal Man 19
Batman: The Long Halloween 38
All Star Superman 8
Superman For All Seasons 29
Identity Crisis 72
JLA: Tower Of Babel 17
Snowbirds Don't Fly 6
The Dark Knight Returns 38
The New Frontier 73
The Coyote Gospel 28
For The Man Who Has Everything 13
JLA: Tower Of Babel 5
Crisis On Infinite Earths 1
Teen Titans: The Judas Contract 99
Whatever Happened To The Man Of Tomorrow? 63
Arkham Asylum: A Serious House On Serious Earth 74
Doom Patrol 98
Green Arrow: The Longbow Hunters 19
Gotham Central 29
Grant Morrison's Animal Man 1
JLA: Tower Of Babel 51
Snowbirds Don't Fly 5
Green Arrow: The Longbow Hunters 79
The Dark Knight Returns 47
Green Arrow: The Longbow Hunters 45
Gotham Central 50
Superman For All Seasons 73
Green Arrow: The Longbow Hunters 58
Identity Crisis 70
All Star Superman 55
Crisis On Infinite Earths 66
Snowbirds Don't Fly 10
Jack Kirby's New Gods 43
JLA: Earth 2 34
Teen Titans: The Judas Contract 70
Batman: Year One 99
Multiversity 46
Multiversity 43
Doom Patrol 52
Multiversity 83
Teen Titans: The Judas Contract 66
Action Comics 47
JLA: Tower Of Babel 61
Snowbirds Don't Fly 55
All Star Superman 96
JLA: Earth 2 95
Gotham Central 2
Whatever Happened To The Man Of Tomorrow? 14
Swamp Thing: The Anatomy Lesson 27
Superman For All Seasons 15
Batman: Year One 28
The Coyote Gospel 90
Snowbirds Don't Fly 83
Arkham Asylum: A Serious House On Serious Earth 23
All Star Superman 2
Grant Morrison's Animal Man 77
Superman: Red Son 22
JLA: Earth 2 96
Action Comics 52
Doom Patrol 44
