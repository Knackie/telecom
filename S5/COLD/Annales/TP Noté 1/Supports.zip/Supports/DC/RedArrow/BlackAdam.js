Whatever Happened To The Man Of Tomorrow? 51
For The Man Who Has Everything 10
Multiversity 46
Teen Titans: The Judas Contract 11
JLA: Earth 2 49
Green Arrow: The Longbow Hunters 62
All Star Superman 46
The Dark Knight Returns 60
Green Arrow: The Longbow Hunters 53
Gotham Central 91
All Star Superman 0
Multiversity 32
Snowbirds Don't Fly 46
The New Frontier 10
The Dark Knight Returns 39
Gotham Central 64
Multiversity 56
The Coyote Gospel 13
The Coyote Gospel 74
Superman: Red Son 61
Grant Morrison's Animal Man 54
For The Man Who Has Everything 40
Green Arrow: The Longbow Hunters 59
Detective Comics 78
All Star Superman 30
Identity Crisis 39
Teen Titans: The Judas Contract 97
Crisis On Infinite Earths 14
Arkham Asylum: A Serious House On Serious Earth 36
Teen Titans: The Judas Contract 47
Teen Titans: The Judas Contract 27
Batman: The Long Halloween 34
Batman: The Long Halloween 66
Detective Comics 79
Swamp Thing: The Anatomy Lesson 55
JLA: Tower Of Babel 15
Swamp Thing: The Anatomy Lesson 11
Jack Kirby's New Gods 69
All Star Superman 50
Multiversity 4
The Killing Joke 60
The Dark Knight Returns 55
Multiversity 46
Snowbirds Don't Fly 75
The New Frontier 51
JLA: Tower Of Babel 33
Identity Crisis 90
Superman: Red Son 45
Identity Crisis 43
The Sinestro Corps War 15
Crisis On Infinite Earths 55
JLA: Earth 2 20
Swamp Thing: The Anatomy Lesson 6
Snowbirds Don't Fly 9
All Star Superman 24
The New Frontier 4
Whatever Happened To The Man Of Tomorrow? 96
