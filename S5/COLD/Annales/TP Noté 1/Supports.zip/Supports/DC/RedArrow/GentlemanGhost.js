Detective Comics 39
Grant Morrison's Animal Man 53
Swamp Thing: The Anatomy Lesson 20
