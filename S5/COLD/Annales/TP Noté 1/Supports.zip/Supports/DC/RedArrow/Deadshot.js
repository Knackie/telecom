All Star Superman 5
Whatever Happened To The Man Of Tomorrow? 28
Doom Patrol 75
JLA: Tower Of Babel 11
JLA: Tower Of Babel 76
Green Arrow: The Longbow Hunters 9
Doom Patrol 38
Batman: Year One 70
The Dark Knight Returns 47
Teen Titans: The Judas Contract 26
Superman For All Seasons 23
JLA: Tower Of Babel 73
The Coyote Gospel 90
Superman For All Seasons 89
Whatever Happened To The Man Of Tomorrow? 71
Grant Morrison's Animal Man 64
Superman For All Seasons 99
Snowbirds Don't Fly 1
Batman: The Long Halloween 58
Green Arrow: The Longbow Hunters 75
Grant Morrison's Animal Man 96
The Coyote Gospel 11
The Killing Joke 30
Multiversity 11
Kingdom Come 58
Jack Kirby's New Gods 43
Multiversity 52
Multiversity 14
Swamp Thing: The Anatomy Lesson 69
Kingdom Come 7
Gotham Central 33
Arkham Asylum: A Serious House On Serious Earth 93
Swamp Thing: The Anatomy Lesson 62
Snowbirds Don't Fly 89
Action Comics 50
The New Frontier 72
Identity Crisis 5
Arkham Asylum: A Serious House On Serious Earth 49
Teen Titans: The Judas Contract 47
For The Man Who Has Everything 68
The Killing Joke 47
Swamp Thing: The Anatomy Lesson 22
Teen Titans: The Judas Contract 56
Whatever Happened To The Man Of Tomorrow? 29
The New Frontier 56
The Sinestro Corps War 18
Superman: Red Son 68
Snowbirds Don't Fly 47
Whatever Happened To The Man Of Tomorrow? 54
The Killing Joke 52
The Sinestro Corps War 80
Gotham Central 27
Identity Crisis 84
