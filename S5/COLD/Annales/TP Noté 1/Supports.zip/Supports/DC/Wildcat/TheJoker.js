The Killing Joke 19
Teen Titans: The Judas Contract 27
The Killing Joke 73
The Coyote Gospel 26
For The Man Who Has Everything 46
Swamp Thing: The Anatomy Lesson 84
The Dark Knight Returns 68
For The Man Who Has Everything 89
Jack Kirby's New Gods 55
Arkham Asylum: A Serious House On Serious Earth 62
Green Arrow: The Longbow Hunters 29
Identity Crisis 16
For The Man Who Has Everything 97
The Killing Joke 68
Superman For All Seasons 89
Superman: Red Son 20
Whatever Happened To The Man Of Tomorrow? 92
Jack Kirby's New Gods 34
Arkham Asylum: A Serious House On Serious Earth 39
JLA: Earth 2 97
