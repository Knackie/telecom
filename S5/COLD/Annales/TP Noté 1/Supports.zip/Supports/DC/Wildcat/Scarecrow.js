Identity Crisis 28
Green Arrow: The Longbow Hunters 43
Doom Patrol 98
Batman: The Long Halloween 96
Batman: Year One 6
The Sinestro Corps War 75
The Sinestro Corps War 91
Teen Titans: The Judas Contract 62
JLA: Tower Of Babel 63
Arkham Asylum: A Serious House On Serious Earth 76
The Killing Joke 91
Arkham Asylum: A Serious House On Serious Earth 3
Teen Titans: The Judas Contract 75
The Sinestro Corps War 32
Whatever Happened To The Man Of Tomorrow? 93
Superman: Red Son 3
Batman: Year One 26
The Sinestro Corps War 47
JLA: Earth 2 98
Green Arrow: The Longbow Hunters 17
Detective Comics 14
Action Comics 1
Identity Crisis 98
The Coyote Gospel 73
Crisis On Infinite Earths 11
The New Frontier 24
JLA: Earth 2 67
Identity Crisis 92
Whatever Happened To The Man Of Tomorrow? 13
Batman: The Long Halloween 57
Kingdom Come 14
All Star Superman 45
Superman For All Seasons 45
The New Frontier 70
Crisis On Infinite Earths 99
Detective Comics 46
Batman: The Long Halloween 84
Batman: The Long Halloween 2
Superman For All Seasons 96
Doom Patrol 8
JLA: Earth 2 9
The Sinestro Corps War 80
Identity Crisis 31
JLA: Tower Of Babel 43
The New Frontier 3
Whatever Happened To The Man Of Tomorrow? 45
JLA: Earth 2 36
Superman: Red Son 81
Snowbirds Don't Fly 86
The Coyote Gospel 44
Green Arrow: The Longbow Hunters 96
Action Comics 52
Teen Titans: The Judas Contract 57
Snowbirds Don't Fly 68
Green Arrow: The Longbow Hunters 27
All Star Superman 17
The New Frontier 6
Swamp Thing: The Anatomy Lesson 21
Gotham Central 46
