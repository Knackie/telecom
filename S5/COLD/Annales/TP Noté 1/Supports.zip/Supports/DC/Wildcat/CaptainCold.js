The Coyote Gospel 2
Green Arrow: The Longbow Hunters 74
The Dark Knight Returns 82
JLA: Tower Of Babel 64
Jack Kirby's New Gods 54
Arkham Asylum: A Serious House On Serious Earth 60
Superman: Red Son 99
The Sinestro Corps War 2
Identity Crisis 99
Swamp Thing: The Anatomy Lesson 0
The Killing Joke 33
Kingdom Come 0
Kingdom Come 54
JLA: Earth 2 85
The New Frontier 81
Arkham Asylum: A Serious House On Serious Earth 29
The Killing Joke 86
The New Frontier 40
Whatever Happened To The Man Of Tomorrow? 78
Gotham Central 7
The Dark Knight Returns 82
Action Comics 73
For The Man Who Has Everything 81
Kingdom Come 16
Doom Patrol 30
The Coyote Gospel 26
The Dark Knight Returns 86
Teen Titans: The Judas Contract 69
All Star Superman 37
Action Comics 61
The Killing Joke 2
The Dark Knight Returns 14
All Star Superman 87
Arkham Asylum: A Serious House On Serious Earth 7
Batman: The Long Halloween 63
Batman: Year One 38
Identity Crisis 79
Superman For All Seasons 24
Gotham Central 26
Identity Crisis 20
Gotham Central 30
Doom Patrol 15
Superman: Red Son 93
Multiversity 59
Doom Patrol 81
Jack Kirby's New Gods 44
Teen Titans: The Judas Contract 19
The Killing Joke 28
All Star Superman 27
Crisis On Infinite Earths 22
Superman For All Seasons 60
Jack Kirby's New Gods 66
For The Man Who Has Everything 8
The Killing Joke 8
Jack Kirby's New Gods 79
Superman For All Seasons 18
Superman For All Seasons 16
For The Man Who Has Everything 13
Swamp Thing: The Anatomy Lesson 59
The Dark Knight Returns 39
Superman: Red Son 13
All Star Superman 61
The Sinestro Corps War 91
All Star Superman 78
All Star Superman 89
Gotham Central 32
Green Arrow: The Longbow Hunters 72
The Sinestro Corps War 45
Snowbirds Don't Fly 80
Teen Titans: The Judas Contract 15
Superman For All Seasons 98
Doom Patrol 69
Detective Comics 13
Identity Crisis 62
JLA: Tower Of Babel 45
Superman For All Seasons 28
JLA: Tower Of Babel 57
Batman: Year One 72
Swamp Thing: The Anatomy Lesson 77
JLA: Tower Of Babel 76
The Sinestro Corps War 33
Identity Crisis 42
Jack Kirby's New Gods 4
Snowbirds Don't Fly 21
Grant Morrison's Animal Man 91
Teen Titans: The Judas Contract 0
Arkham Asylum: A Serious House On Serious Earth 78
Batman: Year One 7
Superman: Red Son 96
Jack Kirby's New Gods 81
The New Frontier 85
The Dark Knight Returns 78
Kingdom Come 33
JLA: Tower Of Babel 48
