Superman: Red Son 25
Superman For All Seasons 52
Arkham Asylum: A Serious House On Serious Earth 50
Doom Patrol 71
For The Man Who Has Everything 34
Detective Comics 84
Arkham Asylum: A Serious House On Serious Earth 94
Identity Crisis 29
All Star Superman 41
The New Frontier 77
For The Man Who Has Everything 84
Superman For All Seasons 94
Jack Kirby's New Gods 0
Gotham Central 30
Green Arrow: The Longbow Hunters 96
Gotham Central 76
JLA: Earth 2 4
Swamp Thing: The Anatomy Lesson 37
JLA: Earth 2 74
JLA: Tower Of Babel 30
Superman For All Seasons 65
Batman: Year One 40
JLA: Earth 2 75
Swamp Thing: The Anatomy Lesson 49
The Killing Joke 2
Green Arrow: The Longbow Hunters 37
Batman: The Long Halloween 55
Green Arrow: The Longbow Hunters 62
Swamp Thing: The Anatomy Lesson 2
The New Frontier 30
Kingdom Come 49
All Star Superman 81
The Coyote Gospel 34
Gotham Central 99
JLA: Tower Of Babel 77
The Coyote Gospel 33
Identity Crisis 81
Batman: The Long Halloween 5
Whatever Happened To The Man Of Tomorrow? 72
Crisis On Infinite Earths 8
Gotham Central 8
Gotham Central 97
Detective Comics 85
JLA: Earth 2 47
The Killing Joke 63
Arkham Asylum: A Serious House On Serious Earth 96
JLA: Earth 2 63
Crisis On Infinite Earths 22
Batman: Year One 78
The Killing Joke 61
Jack Kirby's New Gods 27
JLA: Earth 2 79
Teen Titans: The Judas Contract 47
Teen Titans: The Judas Contract 7
Snowbirds Don't Fly 66
Whatever Happened To The Man Of Tomorrow? 47
Multiversity 56
Whatever Happened To The Man Of Tomorrow? 8
Swamp Thing: The Anatomy Lesson 92
Snowbirds Don't Fly 51
The Dark Knight Returns 62
Superman: Red Son 88
Crisis On Infinite Earths 10
Superman For All Seasons 97
Action Comics 90
Arkham Asylum: A Serious House On Serious Earth 79
Superman For All Seasons 39
Kingdom Come 82
Teen Titans: The Judas Contract 70
Arkham Asylum: A Serious House On Serious Earth 2
Arkham Asylum: A Serious House On Serious Earth 80
Superman: Red Son 44
Detective Comics 18
The Sinestro Corps War 77
Snowbirds Don't Fly 38
The New Frontier 46
All Star Superman 64
Kingdom Come 94
Doom Patrol 37
Batman: The Long Halloween 86
Swamp Thing: The Anatomy Lesson 17
Crisis On Infinite Earths 75
Grant Morrison's Animal Man 73
The Sinestro Corps War 6
Detective Comics 37
JLA: Tower Of Babel 2
Batman: The Long Halloween 35
Batman: The Long Halloween 77
Identity Crisis 8
For The Man Who Has Everything 89
Arkham Asylum: A Serious House On Serious Earth 85
The Dark Knight Returns 89
JLA: Tower Of Babel 94
