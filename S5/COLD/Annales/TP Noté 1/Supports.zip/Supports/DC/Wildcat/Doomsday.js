Identity Crisis 33
Superman: Red Son 16
Snowbirds Don't Fly 5
All Star Superman 49
Gotham Central 20
Whatever Happened To The Man Of Tomorrow? 40
Jack Kirby's New Gods 38
Grant Morrison's Animal Man 66
Action Comics 39
Multiversity 71
The New Frontier 36
The Sinestro Corps War 12
JLA: Earth 2 28
For The Man Who Has Everything 38
JLA: Earth 2 83
Green Arrow: The Longbow Hunters 16
Kingdom Come 16
Swamp Thing: The Anatomy Lesson 32
The New Frontier 24
Detective Comics 83
JLA: Tower Of Babel 29
Swamp Thing: The Anatomy Lesson 26
Green Arrow: The Longbow Hunters 11
JLA: Tower Of Babel 32
The Killing Joke 48
Gotham Central 60
Superman For All Seasons 7
For The Man Who Has Everything 33
All Star Superman 24
Jack Kirby's New Gods 0
The Dark Knight Returns 5
The Killing Joke 22
Green Arrow: The Longbow Hunters 78
For The Man Who Has Everything 53
Action Comics 98
Whatever Happened To The Man Of Tomorrow? 55
JLA: Earth 2 61
Gotham Central 83
Arkham Asylum: A Serious House On Serious Earth 64
Snowbirds Don't Fly 15
The New Frontier 37
Jack Kirby's New Gods 36
All Star Superman 88
