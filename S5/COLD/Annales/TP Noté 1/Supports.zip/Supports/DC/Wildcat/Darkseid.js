The Coyote Gospel 28
Gotham Central 2
The Dark Knight Returns 45
Whatever Happened To The Man Of Tomorrow? 45
Gotham Central 15
The New Frontier 57
The Sinestro Corps War 45
The Sinestro Corps War 73
The Sinestro Corps War 89
The Dark Knight Returns 53
The Sinestro Corps War 50
Action Comics 93
Batman: Year One 43
The Coyote Gospel 57
Swamp Thing: The Anatomy Lesson 73
Whatever Happened To The Man Of Tomorrow? 36
Green Arrow: The Longbow Hunters 86
The Coyote Gospel 90
Batman: Year One 57
Gotham Central 52
Superman: Red Son 98
Whatever Happened To The Man Of Tomorrow? 83
Arkham Asylum: A Serious House On Serious Earth 66
The Dark Knight Returns 56
Gotham Central 54
Doom Patrol 28
JLA: Tower Of Babel 18
The Dark Knight Returns 94
The Sinestro Corps War 74
JLA: Earth 2 97
The Coyote Gospel 22
Teen Titans: The Judas Contract 79
Green Arrow: The Longbow Hunters 12
Snowbirds Don't Fly 12
Multiversity 88
The Sinestro Corps War 77
Kingdom Come 10
Arkham Asylum: A Serious House On Serious Earth 63
JLA: Tower Of Babel 30
