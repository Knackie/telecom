Kingdom Come 94
Swamp Thing: The Anatomy Lesson 51
Detective Comics 58
Green Arrow: The Longbow Hunters 42
Swamp Thing: The Anatomy Lesson 9
The Killing Joke 15
Crisis On Infinite Earths 6
Batman: Year One 6
Whatever Happened To The Man Of Tomorrow? 59
The Dark Knight Returns 61
Swamp Thing: The Anatomy Lesson 35
Action Comics 57
JLA: Tower Of Babel 15
For The Man Who Has Everything 43
