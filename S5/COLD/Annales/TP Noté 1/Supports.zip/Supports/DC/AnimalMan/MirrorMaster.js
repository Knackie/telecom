Grant Morrison's Animal Man 20
The Killing Joke 5
The Coyote Gospel 46
The Dark Knight Returns 76
Detective Comics 72
The New Frontier 42
Crisis On Infinite Earths 43
Grant Morrison's Animal Man 51
JLA: Tower Of Babel 43
Batman: Year One 87
Teen Titans: The Judas Contract 7
Batman: Year One 1
Detective Comics 77
Gotham Central 78
Teen Titans: The Judas Contract 28
Jack Kirby's New Gods 77
Kingdom Come 32
The New Frontier 12
For The Man Who Has Everything 48
All Star Superman 30
Kingdom Come 83
Arkham Asylum: A Serious House On Serious Earth 23
The Killing Joke 46
Identity Crisis 9
Doom Patrol 24
Jack Kirby's New Gods 26
Action Comics 86
Identity Crisis 61
Teen Titans: The Judas Contract 59
Crisis On Infinite Earths 16
Batman: The Long Halloween 20
Jack Kirby's New Gods 73
Snowbirds Don't Fly 93
JLA: Earth 2 35
Teen Titans: The Judas Contract 7
Multiversity 60
Superman For All Seasons 99
Teen Titans: The Judas Contract 80
Gotham Central 47
Gotham Central 49
The Coyote Gospel 12
Batman: The Long Halloween 66
The Coyote Gospel 10
Teen Titans: The Judas Contract 88
