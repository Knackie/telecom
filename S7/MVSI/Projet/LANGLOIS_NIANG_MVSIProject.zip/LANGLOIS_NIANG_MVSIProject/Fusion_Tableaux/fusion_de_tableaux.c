#include <limits.h>
#include <stdio.h>

void merge(int[], int, int[], int, int[]);
/*@ensures \result ==0;
*/
int main() {
    int a[100], b[100], m, n, c, sorted[200];
    
    printf("Input number of elements in first array \n");
    scanf("%d", &m);
    /*@assert m >= INT_MIN; */
    /*@assert m <= INT_MAX; */
    
    printf("Input %d integers\n", m);
    /*@ loop invariant c >= 0 && c <= m;
	 @ loop assigns c;
	*/
    for (c = 0; c < m; c++) {
        scanf("%d", &a[c]);
        /*@assert a[c] >= INT_MIN; */
        /*@assert a[c] <= INT_MAX; */
    }
    
    printf("Input number of elements in second array \n");
    scanf("%d", &n);
    /*@assert n >= INT_MIN; */
    /*@assert n <= INT_MAX; */
    
    printf("Input %d integers\n", n);
    /*@ loop invariant c >= 0 && c <= n;
	 @ loop assigns c;
	*/
    for (c = 0; c < n; c++) {
        /*@assert c < n; */
        scanf("%d", &b[c]);
        /*@assert b[c] >= INT_MIN; */
        /*@assert b[c] <= INT_MAX; */
    }
    
    merge(a, m, b, n, sorted);
    printf("Sorted array :\n");
    /*@ loop invariant c >= 0 && c <= m+n;
	 @ loop assigns c;
	*/
    for (c=0; c < m + n ; c++) {
        /*@assert sorted[c] >= INT_MIN; */
        /*@assert sorted[c] <= INT_MAX; */
        printf("%d\n", sorted[c]);
    }
    
    return 0;
}

void merge(int a[], int m, int b[], int n, int sorted[]) {
    int i, j, k;
    
    j = k = 0;
    /* @assert j == 0;
       @assert k == 0;
    /* @ loop invariant i >= 0;
     @ loop assigns i; */
    for (i = 0; i<m+n;) {
        if (j<m && k <n) {
            /*@ assert j < m; */
            /*@ assert k < n; */
            if (a[j] < b[k]) {
                /*@ assert a[j] < b[k]; */
                sorted[i] = a[j];
                /*@ assert sorted[i] == a[j]; */
                j++;
            }
            else {
                sorted[i] = b[k];
                /*@ assert sorted[i] == b[k]; */
                k++;
            }
            i++;
       }
       else if (j == m) {
           /*@ assert j == m; */
           /*@ loop invariant i >= m + n; */
            for (; i< m + n;) {
                sorted[i] = b[k];
                /*@ assert sorted[i] < b[k]; */
                k++;
                i++;
            }
       }
       else {
            for(; i<m+n;) {
                sorted[i] = a[j];
                j++;
                i++;
            }
       }
   }
}   
    
