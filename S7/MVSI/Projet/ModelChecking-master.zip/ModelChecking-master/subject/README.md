# Subject

This folder contains the implementation of the programs to be checked.

Each of those small algorithms will be further checked using TLA+ in the
[tla_checking](../tla_checking/) folder.
