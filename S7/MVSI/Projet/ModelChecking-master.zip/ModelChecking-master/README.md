# TELECOM_MVSI

TELECOM Nancy's Model checking project

## Authors

- [Julien Dumas]()
- [Pierre Bouillon](https://pbouillon.github.io/)
- [Victor Varnier](https://github.com/VVarnier)
